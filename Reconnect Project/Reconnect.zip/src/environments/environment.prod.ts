export const environment = {
  production: true,
  url:'http://ncsdev.in/api/'
};
