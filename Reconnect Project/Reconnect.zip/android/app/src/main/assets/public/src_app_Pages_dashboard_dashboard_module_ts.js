(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_dashboard_dashboard_module_ts"],{

/***/ 7212:
/*!*************************************************************!*\
  !*** ./src/app/Pages/dashboard/dashboard-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardPageRoutingModule": () => (/* binding */ DashboardPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.component */ 6198);




const routes = [
    {
        path: '',
        component: _dashboard_component__WEBPACK_IMPORTED_MODULE_0__.DashboardComponent
    }
];
let DashboardPageRoutingModule = class DashboardPageRoutingModule {
};
DashboardPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], DashboardPageRoutingModule);



/***/ }),

/***/ 6198:
/*!********************************************************!*\
  !*** ./src/app/Pages/dashboard/dashboard.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardComponent": () => (/* binding */ DashboardComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_dashboard_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./dashboard.component.html */ 9507);
/* harmony import */ var _dashboard_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard.component.css */ 4245);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var src_app_app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/app.component */ 5041);
/* harmony import */ var _welcomepopup_welcomepopup_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./welcomepopup/welcomepopup.component */ 3456);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage-angular */ 1628);










let DashboardComponent = class DashboardComponent {
    constructor(storage, modalCtrl, myapp, menu, router) {
        this.storage = storage;
        this.modalCtrl = modalCtrl;
        this.myapp = myapp;
        this.menu = menu;
        this.router = router;
        this.placeHolder = './assets/preloader.gif';
        this.slideOptsOne = {
            initialSlide: 0,
            slidesPerView: 1,
            autoplay: true
        };
        this.condition = 2;
        this.list = new Array(5);
        this.slideOptsThumbs = {
            slidesPerView: 1.2,
        };
        this.sliderOne =
            {
                isBeginningSlide: true,
                isEndSlide: false,
            };
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.create();
            this.storage.get("userdata").then(data => {
                this.profileData = data;
                this.member_name = this.profileData.Name;
                this.exp_date = this.profileData.MembershipEndDate;
            });
        });
    }
    ngOnInit() {
        this.menu.enable(true);
        //this.initModal();
    }
    initModal() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _welcomepopup_welcomepopup_component__WEBPACK_IMPORTED_MODULE_3__.WelcomepopupComponent,
                cssClass: 'welcome_popup',
                showBackdrop: true,
                backdropDismiss: false,
            });
            return yield modal.present();
        });
    }
    slidePrev(object, slideView) {
        slideView.slidePrev(500).then(() => {
            this.checkIfNavDisabled(object, slideView);
        });
        ;
    }
    //Method called when slide is changed by drag or navigation
    SlideDidChange(object, slideView) {
        this.checkIfNavDisabled(object, slideView);
    }
    //Call methods to check if slide is first or last to enable disbale navigation  
    checkIfNavDisabled(object, slideView) {
        this.checkisBeginning(object, slideView);
        this.checkisEnd(object, slideView);
    }
    checkisBeginning(object, slideView) {
        slideView.isBeginning().then((istrue) => {
            object.isBeginningSlide = istrue;
        });
    }
    checkisEnd(object, slideView) {
        slideView.isEnd().then((istrue) => {
            object.isEndSlide = istrue;
        });
    }
    class_listing() {
        this.router.navigate(['/class_booking']);
    }
    booking() {
        this.router.navigate(['/details/1']);
    }
    profile() {
        this.router.navigate(['/tablinks/profile']);
    }
    pasess() {
        this.router.navigate(['/pasess']);
    }
    promotions() {
        this.router.navigate(['/promotions']);
    }
    offers() {
        this.router.navigate(['/vouchers']);
    }
    gym_booking() {
        this.router.navigate(['/gym-booking']);
    }
    partner_offers() {
        this.router.navigate(['/offers']);
    }
    bookings() {
        this.router.navigate(['/history']);
    }
    wallet() {
        this.router.navigate(['/digital-wallet']);
    }
};
DashboardComponent.ctorParameters = () => [
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_5__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: src_app_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router }
];
DashboardComponent.propDecorators = {
    slideWithNav: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_8__.ViewChild, args: ['slideWithNav', { static: false },] }]
};
DashboardComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-dashboard',
        template: _raw_loader_dashboard_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_dashboard_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DashboardComponent);



/***/ }),

/***/ 9702:
/*!*****************************************************!*\
  !*** ./src/app/Pages/dashboard/dashboard.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardPageModule": () => (/* binding */ DashboardPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _dashboard_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dashboard.component */ 6198);
/* harmony import */ var _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard-routing.module */ 7212);
/* harmony import */ var _welcomepopup_welcomepopup_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./welcomepopup/welcomepopup.component */ 3456);








let DashboardPageModule = class DashboardPageModule {
};
DashboardPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_1__.DashboardPageRoutingModule
        ],
        declarations: [_dashboard_component__WEBPACK_IMPORTED_MODULE_0__.DashboardComponent, _welcomepopup_welcomepopup_component__WEBPACK_IMPORTED_MODULE_2__.WelcomepopupComponent]
    })
], DashboardPageModule);



/***/ }),

/***/ 3456:
/*!************************************************************************!*\
  !*** ./src/app/Pages/dashboard/welcomepopup/welcomepopup.component.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WelcomepopupComponent": () => (/* binding */ WelcomepopupComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_welcomepopup_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./welcomepopup.component.html */ 1958);
/* harmony import */ var _welcomepopup_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./welcomepopup.component.css */ 7874);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 476);





let WelcomepopupComponent = class WelcomepopupComponent {
    constructor(modalController) {
        this.modalController = modalController;
    }
    ngOnInit() {
    }
    dismiss() {
        // using the injected ModalController this page
        // can "dismiss" itself and optionally pass back data
        this.modalController.dismiss({
            'dismissed': true
        });
    }
    checkout() {
        this.modalController.dismiss({
            'dismissed': true
        });
    }
    select_branch(id) {
        this.activaLayer = id;
    }
};
WelcomepopupComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController }
];
WelcomepopupComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-welcomepopup',
        template: _raw_loader_welcomepopup_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_welcomepopup_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], WelcomepopupComponent);



/***/ }),

/***/ 4245:
/*!*********************************************************!*\
  !*** ./src/app/Pages/dashboard/dashboard.component.css ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 230px; background:url('home_banner.jpg');--background-repeat: no-repeat;\r\n    --background-size: cover;  background-size: cover;}\r\n.header_overlay{background:#20978f69;height: 230px;}\r\n.icon_conatiner{padding-top: 10px;}\r\n.icon_conatiner ion-row {float: right;}\r\n._menu_icon{color: #fff;font-size: 30px;}\r\n._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;}\r\n.right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n.name_container {margin-top:57px;margin-left: 20px;;}\r\n.name_container ion-row > ion-label{color: #fff;font-family:Poppins-Light !important;font-size: 30px;line-height: 38px;}\r\n.membership_container{margin-top:10px;margin-left: 20px;;}\r\n.mem_title{color: #fff;font-family: Poppins-Mediam!important;font-size: 12px;}\r\n.mem_values{color: #fff;text-align: left; font-family:Poppins-Light !important;font-size: 12px;}\r\n.more_info{margin-left: 20px;margin-top: 10px;}\r\n._row{padding: 0px!important;margin: 0px!important;display: block;}\r\n.card_lable{    color: #fff;font-family: Poppins-Mediam!important;font-size: 18px;position: relative;font-weight: bolder;top: 20px;width: 100px;}\r\n.day_passess{ background: url('day_passess.jpg'); --background-size: cover;background-size: cover;height: 100px;padding: 0px;margin: 0px;}\r\n.gym_booking{ background: url('_-_-_-assets-dahsboard-gym_booking.jpg'); --background-size: cover;background-size: cover;height: 100px;padding: 0px;margin: 0px;}\r\n.class_booking{ background: url('class_booking.jpg'); --background-size: cover;background-size: cover;height: 100px;padding: 0px;margin: 0px;}\r\n.vouchers{ background: url('vouchers.jpg'); --background-size: cover;background-size: cover;height: 100px;padding: 0px;margin: 0px;}\r\n.partner_offers{ background: url('partner_offers.jpg'); --background-size: cover;background-size: cover;height: 100px;padding: 0px;margin: 0px;}\r\n.promotion{ background: url('promotion.jpg'); --background-size: cover;background-size: cover;height: 100px;padding: 0px;margin: 0px;}\r\n.black_layer{background: #00000085;height: 100px;}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhc2hib2FyZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGVBQWUsV0FBVyxDQUFDLGFBQWEsRUFBRSxpQ0FBK0MsQ0FBQyw4QkFBOEI7SUFDcEgsd0JBQXdCLEdBQUcsc0JBQXNCLENBQUM7QUFDdEQsZ0JBQWdCLG9CQUFvQixDQUFDLGFBQWEsQ0FBQztBQUNuRCxnQkFBZ0IsaUJBQWlCLENBQUM7QUFDbEMseUJBQXlCLFlBQVksQ0FBQztBQUN0QyxZQUFZLFdBQVcsQ0FBQyxlQUFlLENBQUM7QUFDeEMsWUFBWSxXQUFXLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQztBQUN4RCxZQUFZLFdBQVcsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDO0FBQ3ZGLGlCQUFpQixlQUFlLENBQUMsaUJBQWlCLEVBQUU7QUFDcEQsb0NBQW9DLFdBQVcsQ0FBQyxvQ0FBb0MsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUM7QUFDdkgsc0JBQXNCLGVBQWUsQ0FBQyxpQkFBaUIsRUFBRTtBQUN6RCxXQUFXLFdBQVcsQ0FBQyxxQ0FBcUMsQ0FBQyxlQUFlLENBQUM7QUFDN0UsWUFBWSxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsb0NBQW9DLENBQUMsZUFBZSxDQUFDO0FBQy9GLFdBQVcsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUM7QUFDOUMsTUFBTSxzQkFBc0IsQ0FBQyxxQkFBcUIsQ0FBQyxjQUFjLENBQUM7QUFDbEUsZ0JBQWdCLFdBQVcsQ0FBQyxxQ0FBcUMsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQztBQUNoSixjQUFjLGtDQUEwRCxFQUFFLHdCQUF3QixDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDO0FBQ2pLLGNBQWMseURBQTBELEVBQUUsd0JBQXdCLENBQUMsc0JBQXNCLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUM7QUFDakssZ0JBQWdCLG9DQUE0RCxFQUFFLHdCQUF3QixDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDO0FBQ3JLLFdBQVcsK0JBQXVELEVBQUUsd0JBQXdCLENBQUMsc0JBQXNCLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUM7QUFDM0osaUJBQWlCLHFDQUE2RCxFQUFFLHdCQUF3QixDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDO0FBQ3ZLLFlBQVksZ0NBQXdELEVBQUUsd0JBQXdCLENBQUMsc0JBQXNCLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUM7QUFDN0osYUFBYSxxQkFBcUIsQ0FBQyxhQUFhLENBQUMiLCJmaWxlIjoiZGFzaGJvYXJkLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyX2Jhbm5lcnt3aWR0aDogMTAwJTtoZWlnaHQ6IDIzMHB4OyBiYWNrZ3JvdW5kOnVybCguLi8uLi8uLi9hc3NldHMvaG9tZV9iYW5uZXIuanBnKTstLWJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAtLWJhY2tncm91bmQtc2l6ZTogY292ZXI7ICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO31cclxuLmhlYWRlcl9vdmVybGF5e2JhY2tncm91bmQ6IzIwOTc4ZjY5O2hlaWdodDogMjMwcHg7fVxyXG4uaWNvbl9jb25hdGluZXJ7cGFkZGluZy10b3A6IDEwcHg7fVxyXG4uaWNvbl9jb25hdGluZXIgaW9uLXJvdyB7ZmxvYXQ6IHJpZ2h0O31cclxuLl9tZW51X2ljb257Y29sb3I6ICNmZmY7Zm9udC1zaXplOiAzMHB4O31cclxuLl9jYXJ0X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiA4cHggMHB4O2ZvbnQtc2l6ZTogMjZweDt9XHJcbi5yaWdodF9sb2dve3dpZHRoOiAzMHB4O2hlaWdodDogMzVweDtmbG9hdDogcmlnaHQ7bWFyZ2luLXRvcDogLTE5cHg7bWFyZ2luLXJpZ2h0OiAxNXB4O31cclxuLm5hbWVfY29udGFpbmVyIHttYXJnaW4tdG9wOjU3cHg7bWFyZ2luLWxlZnQ6IDIwcHg7O31cclxuLm5hbWVfY29udGFpbmVyIGlvbi1yb3cgPiBpb24tbGFiZWx7Y29sb3I6ICNmZmY7Zm9udC1mYW1pbHk6UG9wcGlucy1MaWdodCAhaW1wb3J0YW50O2ZvbnQtc2l6ZTogMzBweDtsaW5lLWhlaWdodDogMzhweDt9XHJcbi5tZW1iZXJzaGlwX2NvbnRhaW5lcnttYXJnaW4tdG9wOjEwcHg7bWFyZ2luLWxlZnQ6IDIwcHg7O31cclxuLm1lbV90aXRsZXtjb2xvcjogI2ZmZjtmb250LWZhbWlseTogUG9wcGlucy1NZWRpYW0haW1wb3J0YW50O2ZvbnQtc2l6ZTogMTJweDt9XHJcbi5tZW1fdmFsdWVze2NvbG9yOiAjZmZmO3RleHQtYWxpZ246IGxlZnQ7IGZvbnQtZmFtaWx5OlBvcHBpbnMtTGlnaHQgIWltcG9ydGFudDtmb250LXNpemU6IDEycHg7fVxyXG4ubW9yZV9pbmZve21hcmdpbi1sZWZ0OiAyMHB4O21hcmdpbi10b3A6IDEwcHg7fVxyXG4uX3Jvd3twYWRkaW5nOiAwcHghaW1wb3J0YW50O21hcmdpbjogMHB4IWltcG9ydGFudDtkaXNwbGF5OiBibG9jazt9XHJcbi5jYXJkX2xhYmxleyAgICBjb2xvcjogI2ZmZjtmb250LWZhbWlseTogUG9wcGlucy1NZWRpYW0haW1wb3J0YW50O2ZvbnQtc2l6ZTogMThweDtwb3NpdGlvbjogcmVsYXRpdmU7Zm9udC13ZWlnaHQ6IGJvbGRlcjt0b3A6IDIwcHg7d2lkdGg6IDEwMHB4O30gXHJcbi5kYXlfcGFzc2Vzc3sgYmFja2dyb3VuZDogdXJsKC4uLy4uLy4uL2Fzc2V0cy9kYWhzYm9hcmQvZGF5X3Bhc3Nlc3MuanBnKTsgLS1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyO2JhY2tncm91bmQtc2l6ZTogY292ZXI7aGVpZ2h0OiAxMDBweDtwYWRkaW5nOiAwcHg7bWFyZ2luOiAwcHg7fVxyXG4uZ3ltX2Jvb2tpbmd7IGJhY2tncm91bmQ6IHVybCguLi8uLi8uLi9hc3NldHMvZGFoc2JvYXJkL2d5bV9ib29raW5nLmpwZyk7IC0tYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO2hlaWdodDogMTAwcHg7cGFkZGluZzogMHB4O21hcmdpbjogMHB4O30gIFxyXG4uY2xhc3NfYm9va2luZ3sgYmFja2dyb3VuZDogdXJsKC4uLy4uLy4uL2Fzc2V0cy9kYWhzYm9hcmQvY2xhc3NfYm9va2luZy5qcGcpOyAtLWJhY2tncm91bmQtc2l6ZTogY292ZXI7YmFja2dyb3VuZC1zaXplOiBjb3ZlcjtoZWlnaHQ6IDEwMHB4O3BhZGRpbmc6IDBweDttYXJnaW46IDBweDt9ICBcclxuLnZvdWNoZXJzeyBiYWNrZ3JvdW5kOiB1cmwoLi4vLi4vLi4vYXNzZXRzL2RhaHNib2FyZC92b3VjaGVycy5qcGcpOyAtLWJhY2tncm91bmQtc2l6ZTogY292ZXI7YmFja2dyb3VuZC1zaXplOiBjb3ZlcjtoZWlnaHQ6IDEwMHB4O3BhZGRpbmc6IDBweDttYXJnaW46IDBweDt9XHJcbi5wYXJ0bmVyX29mZmVyc3sgYmFja2dyb3VuZDogdXJsKC4uLy4uLy4uL2Fzc2V0cy9kYWhzYm9hcmQvcGFydG5lcl9vZmZlcnMuanBnKTsgLS1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyO2JhY2tncm91bmQtc2l6ZTogY292ZXI7aGVpZ2h0OiAxMDBweDtwYWRkaW5nOiAwcHg7bWFyZ2luOiAwcHg7fVxyXG4ucHJvbW90aW9ueyBiYWNrZ3JvdW5kOiB1cmwoLi4vLi4vLi4vYXNzZXRzL2RhaHNib2FyZC9wcm9tb3Rpb24uanBnKTsgLS1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyO2JhY2tncm91bmQtc2l6ZTogY292ZXI7aGVpZ2h0OiAxMDBweDtwYWRkaW5nOiAwcHg7bWFyZ2luOiAwcHg7fVxyXG4uYmxhY2tfbGF5ZXJ7YmFja2dyb3VuZDogIzAwMDAwMDg1O2hlaWdodDogMTAwcHg7fVxyXG4iXX0= */");

/***/ }),

/***/ 7874:
/*!*************************************************************************!*\
  !*** ./src/app/Pages/dashboard/welcomepopup/welcomepopup.component.css ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".black_layer{background: #20978f6b;height: 100px;}\r\n.active_layer{background: #20978fbf;height: 100px;}\r\n.card_lable{  text-align: center;  color: #fff;font-family: Poppins-Mediam!important;font-size: 18px;position: relative;font-weight: bolder;top: 20px;width: 100px;}\r\n.button_container{\r\n    width: 80%;\r\n    margin: 0px auto;\r\n}\r\n.action_button_no{ color: #000; --background: #ddd;font-size: 18px;--border-radius: 6px;width: 200px; height:30px}\r\n.action_button_no:hover{color: #000; --background-hover: #ddd;}\r\n.action_button_yes{ color: #fff; --background: #28aebb;font-size: 18px;--border-radius: 6px;width: 200px; height:30px}\r\n.action_button_yes:hover{color: #fff; --background-hover: #28aebb;}\r\n.p_title{width: 100%; text-align: center; display: block;color: rgb(85, 83, 83); margin: 5px 0px; font-weight: 600;font-family: Georgia, 'Times New Roman', Times, serif;}\r\n.p_sub{width: 100%; text-align: center; display: block;color: rgb(85, 83, 83);font-size: 14px; margin-bottom: 10px;font-family: Georgia, 'Times New Roman', Times, serif;}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlbGNvbWVwb3B1cC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGFBQWEscUJBQXFCLENBQUMsYUFBYSxDQUFDO0FBQ2pELGNBQWMscUJBQXFCLENBQUMsYUFBYSxDQUFDO0FBQ2xELGNBQWMsa0JBQWtCLEdBQUcsV0FBVyxDQUFDLHFDQUFxQyxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDO0FBQ25LO0lBQ0ksVUFBVTtJQUNWLGdCQUFnQjtBQUNwQjtBQUVBLG1CQUFtQixXQUFXLEVBQUUsa0JBQWtCLENBQUMsZUFBZSxDQUFDLG9CQUFvQixDQUFDLFlBQVksRUFBRSxXQUFXO0FBQ2pILHdCQUF3QixXQUFXLEVBQUUsd0JBQXdCLENBQUM7QUFFOUQsb0JBQW9CLFdBQVcsRUFBRSxxQkFBcUIsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsWUFBWSxFQUFFLFdBQVc7QUFDckgseUJBQXlCLFdBQVcsRUFBRSwyQkFBMkIsQ0FBQztBQUNsRSxTQUFTLFdBQVcsRUFBRSxrQkFBa0IsRUFBRSxjQUFjLENBQUMsc0JBQXNCLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixDQUFDLHFEQUFxRCxDQUFDO0FBQ3pLLE9BQU8sV0FBVyxFQUFFLGtCQUFrQixFQUFFLGNBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxlQUFlLEVBQUUsbUJBQW1CLENBQUMscURBQXFELENBQUMiLCJmaWxlIjoid2VsY29tZXBvcHVwLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmxhY2tfbGF5ZXJ7YmFja2dyb3VuZDogIzIwOTc4ZjZiO2hlaWdodDogMTAwcHg7fVxyXG4uYWN0aXZlX2xheWVye2JhY2tncm91bmQ6ICMyMDk3OGZiZjtoZWlnaHQ6IDEwMHB4O31cclxuLmNhcmRfbGFibGV7ICB0ZXh0LWFsaWduOiBjZW50ZXI7ICBjb2xvcjogI2ZmZjtmb250LWZhbWlseTogUG9wcGlucy1NZWRpYW0haW1wb3J0YW50O2ZvbnQtc2l6ZTogMThweDtwb3NpdGlvbjogcmVsYXRpdmU7Zm9udC13ZWlnaHQ6IGJvbGRlcjt0b3A6IDIwcHg7d2lkdGg6IDEwMHB4O30gXHJcbi5idXR0b25fY29udGFpbmVye1xyXG4gICAgd2lkdGg6IDgwJTtcclxuICAgIG1hcmdpbjogMHB4IGF1dG87XHJcbn1cclxuXHJcbi5hY3Rpb25fYnV0dG9uX25veyBjb2xvcjogIzAwMDsgLS1iYWNrZ3JvdW5kOiAjZGRkO2ZvbnQtc2l6ZTogMThweDstLWJvcmRlci1yYWRpdXM6IDZweDt3aWR0aDogMjAwcHg7IGhlaWdodDozMHB4fVxyXG4uYWN0aW9uX2J1dHRvbl9ubzpob3Zlcntjb2xvcjogIzAwMDsgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjZGRkO31cclxuXHJcbi5hY3Rpb25fYnV0dG9uX3llc3sgY29sb3I6ICNmZmY7IC0tYmFja2dyb3VuZDogIzI4YWViYjtmb250LXNpemU6IDE4cHg7LS1ib3JkZXItcmFkaXVzOiA2cHg7d2lkdGg6IDIwMHB4OyBoZWlnaHQ6MzBweH1cclxuLmFjdGlvbl9idXR0b25feWVzOmhvdmVye2NvbG9yOiAjZmZmOyAtLWJhY2tncm91bmQtaG92ZXI6ICMyOGFlYmI7fVxyXG4ucF90aXRsZXt3aWR0aDogMTAwJTsgdGV4dC1hbGlnbjogY2VudGVyOyBkaXNwbGF5OiBibG9jaztjb2xvcjogcmdiKDg1LCA4MywgODMpOyBtYXJnaW46IDVweCAwcHg7IGZvbnQtd2VpZ2h0OiA2MDA7Zm9udC1mYW1pbHk6IEdlb3JnaWEsICdUaW1lcyBOZXcgUm9tYW4nLCBUaW1lcywgc2VyaWY7fVxyXG4ucF9zdWJ7d2lkdGg6IDEwMCU7IHRleHQtYWxpZ246IGNlbnRlcjsgZGlzcGxheTogYmxvY2s7Y29sb3I6IHJnYig4NSwgODMsIDgzKTtmb250LXNpemU6IDE0cHg7IG1hcmdpbi1ib3R0b206IDEwcHg7Zm9udC1mYW1pbHk6IEdlb3JnaWEsICdUaW1lcyBOZXcgUm9tYW4nLCBUaW1lcywgc2VyaWY7fSJdfQ== */");

/***/ }),

/***/ 9507:
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/dashboard/dashboard.component.html ***!
  \************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n<ion-content [fullscreen]=\"true\" >\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n        \n         <div class=\"icon_conatiner\" slot=\"end\">\n           <ion-row>  \n            <ion-icon  class=\"_cart_icon\" (click)=\"this.myapp.cart()\"  name=\"bag-handle-outline\"></ion-icon>\n             <ion-menu-button  class=\"_menu_icon\"></ion-menu-button>\n           </ion-row>\n        \n         </div>\n       <div class=\"name_container\" (click)=\"profile()\">\n         <ion-row><ion-label>Hello</ion-label></ion-row>\n         <ion-row><ion-label style=\"font-weight: bolder;\">{{member_name}}!</ion-label></ion-row>\n       </div>\n\n       <div class=\"membership_container\">\n        <ion-row class=\"_row\">\n            <ion-col size=\"2.5\"><ion-label class=\"mem_title\">Membership</ion-label></ion-col>\n            <ion-col size=\"5\"><ion-label class=\"mem_values\">Diamand</ion-label></ion-col>\n          </ion-row>\n        <ion-row class=\"_row\"> \n          <ion-col size=\"2\"><ion-label class=\"mem_title\">Valid Until</ion-label></ion-col>\n          <ion-col size=\"5\"><ion-label class=\"mem_values\"><ion-datetime style=\"display: table-row-group;\" value=\"{{exp_date}}\" display-timezone=\"utc\"></ion-datetime></ion-label></ion-col>\n        </ion-row>\n      </div>\n\n      <div class=\"more_info\">\n        <div>\n          <ion-col size=\"1\"><ion-label class=\"mem_title\">Tap to see more information about membership</ion-label></ion-col>\n          <ion-col size=\"7\" ><img class=\"right_logo\" src=\"../../../assets/second_logo.png\"/></ion-col>\n        </div>\n      </div>\n          \n   \n      </div>\n    </div>\n        \n    <ion-grid>\n      \n       <ion-row>\n        <ion-col>\n          <ion-card class=\"day_passess\" (click)=\"pasess()\">\n              <ion-card-content class=\"black_layer\">\n                <h1 class=\"card_lable\" >Day</h1>\n                <h1 class=\"card_lable\" >Pasees</h1>\n              </ion-card-content>\n          </ion-card>\n        </ion-col>\n        <ion-col>  \n          <ion-card class=\"gym_booking\" (click)=\"gym_booking()\">\n            <ion-card-content class=\"black_layer\">\n              <h1 class=\"card_lable\" >Gym</h1>\n              <h1 class=\"card_lable\" >Booking</h1>\n            </ion-card-content>\n        </ion-card></ion-col>\n       </ion-row>\n\n       <ion-row>\n        <ion-col>\n          <ion-card class=\"class_booking\" (click)=\"class_listing() \" >\n              <ion-card-content class=\"black_layer\">\n                <h1 class=\"card_lable\" >Class</h1>\n                <h1 class=\"card_lable\" >Booking</h1>\n              </ion-card-content>\n          </ion-card>\n        </ion-col>\n        <ion-col>  \n          <ion-card class=\"vouchers\" (click)=\"offers() \" >\n            <ion-card-content class=\"black_layer\" >\n              <h1 class=\"card_lable\" >My</h1>\n              <h1 class=\"card_lable\" >Vouchers</h1>\n            </ion-card-content>\n        </ion-card></ion-col>\n       </ion-row>\n\n       <ion-row>\n        <ion-col>\n          <ion-card class=\"partner_offers\" (click)=\"partner_offers()\">\n              <ion-card-content class=\"black_layer\"> \n                <h1 class=\"card_lable\" >Partner </h1>\n                <h1 class=\"card_lable\" >Offers</h1>\n              </ion-card-content>\n          </ion-card>\n        </ion-col>\n        <ion-col>  \n          <ion-card class=\"promotion\" (click)=\"promotions()\">\n            <ion-card-content class=\"black_layer\"> \n              <h1 class=\"card_lable\" >Hotel </h1>\n              <h1 class=\"card_lable\">Promotions</h1>\n            </ion-card-content>\n        </ion-card></ion-col>\n       </ion-row>\n\n       <ion-row>\n       \n        <ion-col>  \n          <ion-card class=\"class_booking\">\n            <ion-card-content class=\"black_layer\" (click)=\"bookings()\"> \n              <h1 class=\"card_lable\" >My </h1>\n              <h1 class=\"card_lable\" >Schedule</h1>\n            </ion-card-content>\n        </ion-card></ion-col>\n       </ion-row>\n    \n      </ion-grid>  \n        \n    <div style=\"padding-bottom: 100px;\" ></div>\n</ion-content>\n");

/***/ }),

/***/ 1958:
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/dashboard/welcomepopup/welcomepopup.component.html ***!
  \****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content >\n\n\n   \n        <ion-grid>\n    \n          <ion-row>\n           <ion-col size=\"6\" >\n             <ion-card class=\"day_passess\" (click)=\"select_branch(1)\" >\n                 <ion-card-content [ngClass]=\"this.activaLayer == 1 ? 'active_layer' : 'black_layer'\">\n                   <h1 class=\"card_lable\"   >Towel</h1>\n    \n                 </ion-card-content>\n             </ion-card>\n           </ion-col>\n           <ion-col size=\"6\">  \n             <ion-card class=\"gym_booking\" (click)=\"select_branch(2)\" >\n               <ion-card-content [ngClass]=\"this.activaLayer == 2 ? 'active_layer' : 'black_layer'\">\n                 <h1 class=\"card_lable\"   >Water Bottle</h1>\n               \n               </ion-card-content>\n           </ion-card></ion-col>\n          </ion-row>\n\n          <ion-row>\n            <ion-col size=\"6\" >\n              <ion-card class=\"day_passess\" (click)=\"select_branch(3)\" >\n                  <ion-card-content [ngClass]=\"this.activaLayer == 3 ? 'active_layer' : 'black_layer'\">\n                    <h1 class=\"card_lable\"   >Towel</h1>\n     \n                  </ion-card-content>\n              </ion-card>\n            </ion-col>\n            <ion-col size=\"6\">  \n              <ion-card class=\"gym_booking\" (click)=\"select_branch(4)\" >\n                <ion-card-content [ngClass]=\"this.activaLayer == 4 ? 'active_layer' : 'black_layer'\">\n                  <h1 class=\"card_lable\"   >Water Bottle</h1>\n                \n                </ion-card-content>\n            </ion-card></ion-col>\n           </ion-row>\n   \n          \n   \n          \n       \n         </ion-grid>  \n \n     \n      <ion-row><ion-label class=\"p_sub\">Would you like to pick this ?</ion-label></ion-row>\n      <ion-row class=\"button_container\">\n        <ion-buttons style=\"width: 80%;margin: 0px auto;\">\n          <ion-button class=\"action_button_yes\"(click)=\"checkout()\" >Yes</ion-button>\n          <ion-button class=\"action_button_no\" (click)=\"dismiss()\" >No</ion-button>\n        </ion-buttons>\n     \n      </ion-row>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_dashboard_dashboard_module_ts.js.map