(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_login_login_module_ts"],{

/***/ 6875:
/*!*****************************************************!*\
  !*** ./src/app/Pages/login/login-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _login_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.component */ 9203);




const routes = [
    {
        path: '',
        component: _login_component__WEBPACK_IMPORTED_MODULE_0__.LoginComponent,
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 9203:
/*!************************************************!*\
  !*** ./src/app/Pages/login/login.component.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginComponent": () => (/* binding */ LoginComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_login_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./login.component.html */ 3758);
/* harmony import */ var _login_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.component.css */ 1249);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _login_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.service */ 9157);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage-angular */ 1628);









let LoginComponent = class LoginComponent {
    constructor(router, menu, api, alertController, storage, loadingController) {
        this.router = router;
        this.menu = menu;
        this.api = api;
        this.alertController = alertController;
        this.storage = storage;
        this.loadingController = loadingController;
        this.password_type = 'password';
        this.email_type = 'text';
        this.email_user = 'akash.rekalwar92@gmail.com';
        this.user_pass = 'akas234';
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.create();
            this.storage.get("userdata").then(data => {
                console.log(data);
            });
            this.loading = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: 'Please wait...',
                duration: 2000
            });
        });
    }
    togglePasswordMode() {
        this.password_type = this.password_type === 'text' ? 'password' : 'text';
    }
    ionViewWillEnter() {
        this.menu.enable(false);
    }
    resetpassword() {
        this.router.navigate(['/reset-password']);
    }
    terms() {
        this.router.navigate(['/policy']);
    }
    login() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            /*let post_data = {
              "userName":"akash.rekalwar92@gmail.com",
              "password":"akas234"
          };*/
            if (this.email_user == null) {
                let alert = yield this.alertController.create({
                    cssClass: 'my-custom-class',
                    message: 'Please enter email / mobile number',
                    buttons: ['OK']
                });
                yield alert.present();
            }
            else if (this.mailValidation(this.email_user)) {
                let alert = yield this.alertController.create({
                    cssClass: 'my-custom-class',
                    message: 'Please Valid Email',
                    buttons: ['OK']
                });
                yield alert.present();
            }
            else if (this.user_pass == null) {
                let alert = yield this.alertController.create({
                    cssClass: 'my-custom-class',
                    message: 'Please enter password',
                    buttons: ['OK']
                });
                yield alert.present();
            }
            else {
                this.loading.present();
                let post_data = {
                    "userName": this.email_user,
                    "password": this.user_pass
                };
                this.api._auth(post_data).subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                    if (data == "Invalid") {
                        this.loading.dismiss();
                        let alert = yield this.alertController.create({
                            cssClass: 'my-custom-class',
                            message: 'Invalid Credentials',
                            buttons: ['OK']
                        });
                        yield alert.present();
                    }
                    else {
                        this.loading.dismiss();
                        this.storage.set("userdata", data);
                        this.router.navigate(['/tablinks']);
                    }
                }));
            }
        });
    }
    mailValidation(val) {
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (!expr.test(val)) {
            return true;
        }
    }
};
LoginComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: _login_service__WEBPACK_IMPORTED_MODULE_2__.LoginService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_6__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController }
];
LoginComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-login',
        template: _raw_loader_login_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_login_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], LoginComponent);



/***/ }),

/***/ 5342:
/*!*********************************************!*\
  !*** ./src/app/Pages/login/login.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _login_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.component */ 9203);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login-routing.module */ 6875);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_1__.LoginPageRoutingModule
        ],
        declarations: [_login_component__WEBPACK_IMPORTED_MODULE_0__.LoginComponent]
    })
], LoginPageModule);



/***/ }),

/***/ 9157:
/*!**********************************************!*\
  !*** ./src/app/Pages/login/login.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginService": () => (/* binding */ LoginService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 205);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 5304);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);






let LoginService = class LoginService {
    constructor(httpClient) {
        this.httpClient = httpClient;
        this.LOGIN_URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url + "usermasterapi/userLogin";
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({ 'Content-Type': 'application/json' })
        };
    }
    _auth(param) {
        return this.httpClient.post(`${this.LOGIN_URL}`, param).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.handleError));
        ;
    }
    handleError(error) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Error: ${error.error.message}`;
        }
        else {
            // server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.log(errorMessage);
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(errorMessage);
    }
};
LoginService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
LoginService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], LoginService);



/***/ }),

/***/ 1249:
/*!*************************************************!*\
  !*** ./src/app/Pages/login/login.component.css ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".body_container{width: 100%; background:url('login-bg.png');height:  100%;--background-repeat: no-repeat ;--background-size: cover; }\r\n.logo{margin-top: 50px;}\r\n.logo_container{width: auto;margin: 0px auto;display: table;margin-top: 50px;}\r\n.body_overlay{background:#4c919c73;height: 100%;}\r\n.login_container{margin:40px 20px 10px 20px;;}\r\n.input_box{color: #20978F; background-color: white; margin-top: 5px; margin-bottom: 15px;box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);border-radius: 5px;}\r\n.input_lable{margin-top: 10px; color: #fff;font-family:Poppins-Light !important;}\r\n.input_icon{color: #20978F;font-size: 20px;padding: 8px 0px 5px 5px ;}\r\n.input_text{text-indent: 5px;}\r\n._button{ --background-activated:#20978F; width: 100%;margin: 0px auto;  --border-radius: 5px!important; box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);font-family:Poppins-Medium !important; margin-top: 29px; color: #fff; --background: #20978F;font-size: 18px;--border-radius: 6px;display: block;height: 50px;}\r\n._button:hover{--background-hover: #20978F;--background: #20978F;outline: none;}\r\n.forget_lable{font-family:Poppins-Light !important;color: #fff;margin-top: 15px;float: right;text-decoration: none;text-align: center;}\r\n.lower_content {font-family:Poppins-Light !important; padding-bottom: 0 !important;bottom:0px; padding: 5px;margin-top: 30px;  color: #fff;font-size: 14px;float: right;text-decoration: none;text-align: center;}\r\n.footer_pre{font-family:Poppins-Light !important;}\r\n.footer_text{ width: 100%;padding-bottom: 0 !important;position: absolute;bottom:0px; padding: 5px;margin-bottom: 30px; margin-top: 20px; font-family:Poppins-Light !important;color: #fff;font-weight: 500;font-size: 10px;text-align: center;float: right;}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCLFdBQVcsRUFBRSw4QkFBNEMsQ0FBQyxhQUFhLENBQUMsK0JBQStCLENBQUMsd0JBQXdCLEVBQUU7QUFDbEosTUFBTSxnQkFBZ0IsQ0FBQztBQUN2QixnQkFBZ0IsV0FBVyxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUM3RSxjQUFjLG9CQUFvQixDQUFDLFlBQVksQ0FBQztBQUNoRCxpQkFBaUIsMEJBQTBCLEVBQUU7QUFDN0MsV0FBVyxjQUFjLEVBQUUsdUJBQXVCLEVBQUUsZUFBZSxFQUFFLG1CQUFtQixDQUFDLHVDQUF1QyxDQUFDLGtCQUFrQixDQUFDO0FBQ3BKLGFBQWEsZ0JBQWdCLEVBQUUsV0FBVyxDQUFDLG9DQUFvQyxDQUFDO0FBQ2hGLFlBQVksY0FBYyxDQUFDLGVBQWUsQ0FBQyx5QkFBeUIsQ0FBQztBQUNyRSxZQUFZLGdCQUFnQixDQUFDO0FBQzdCLFVBQVUsOEJBQThCLEVBQUUsV0FBVyxDQUFDLGdCQUFnQixHQUFHLDhCQUE4QixFQUFFLHVDQUF1QyxDQUFDLHFDQUFxQyxFQUFFLGdCQUFnQixFQUFFLFdBQVcsRUFBRSxxQkFBcUIsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQztBQUM5UyxlQUFlLDJCQUEyQixDQUFDLHFCQUFxQixDQUFDLGFBQWEsQ0FBQztBQUMvRSxjQUFjLG9DQUFvQyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLENBQUM7QUFDdEksZ0JBQWdCLG9DQUFvQyxFQUFFLDRCQUE0QixDQUFDLFVBQVUsRUFBRSxZQUFZLENBQUMsZ0JBQWdCLEdBQUcsV0FBVyxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLENBQUM7QUFDak4sWUFBWSxvQ0FBb0MsQ0FBQztBQUNqRCxjQUFjLFdBQVcsQ0FBQyw0QkFBNEIsQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLEVBQUUsWUFBWSxDQUFDLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLG9DQUFvQyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDIiwiZmlsZSI6ImxvZ2luLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYm9keV9jb250YWluZXJ7d2lkdGg6IDEwMCU7IGJhY2tncm91bmQ6dXJsKC4uLy4uLy4uL2Fzc2V0cy9sb2dpbi1iZy5wbmcpO2hlaWdodDogIDEwMCU7LS1iYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0IDstLWJhY2tncm91bmQtc2l6ZTogY292ZXI7IH1cclxuLmxvZ297bWFyZ2luLXRvcDogNTBweDt9XHJcbi5sb2dvX2NvbnRhaW5lcnt3aWR0aDogYXV0bzttYXJnaW46IDBweCBhdXRvO2Rpc3BsYXk6IHRhYmxlO21hcmdpbi10b3A6IDUwcHg7fVxyXG4uYm9keV9vdmVybGF5e2JhY2tncm91bmQ6IzRjOTE5YzczO2hlaWdodDogMTAwJTt9XHJcbi5sb2dpbl9jb250YWluZXJ7bWFyZ2luOjQwcHggMjBweCAxMHB4IDIwcHg7O31cclxuLmlucHV0X2JveHtjb2xvcjogIzIwOTc4RjsgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7IG1hcmdpbi10b3A6IDVweDsgbWFyZ2luLWJvdHRvbTogMTVweDtib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDAsMCwwLDAuMik7Ym9yZGVyLXJhZGl1czogNXB4O31cclxuLmlucHV0X2xhYmxle21hcmdpbi10b3A6IDEwcHg7IGNvbG9yOiAjZmZmO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTGlnaHQgIWltcG9ydGFudDt9XHJcbi5pbnB1dF9pY29ue2NvbG9yOiAjMjA5NzhGO2ZvbnQtc2l6ZTogMjBweDtwYWRkaW5nOiA4cHggMHB4IDVweCA1cHggO31cclxuLmlucHV0X3RleHR7dGV4dC1pbmRlbnQ6IDVweDt9XHJcbi5fYnV0dG9ueyAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiMyMDk3OEY7IHdpZHRoOiAxMDAlO21hcmdpbjogMHB4IGF1dG87ICAtLWJvcmRlci1yYWRpdXM6IDVweCFpbXBvcnRhbnQ7IGJveC1zaGFkb3c6IDAgNHB4IDhweCAwIHJnYmEoMCwwLDAsMC4yKTtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50OyBtYXJnaW4tdG9wOiAyOXB4OyBjb2xvcjogI2ZmZjsgLS1iYWNrZ3JvdW5kOiAjMjA5NzhGO2ZvbnQtc2l6ZTogMThweDstLWJvcmRlci1yYWRpdXM6IDZweDtkaXNwbGF5OiBibG9jaztoZWlnaHQ6IDUwcHg7fVxyXG4uX2J1dHRvbjpob3ZlcnstLWJhY2tncm91bmQtaG92ZXI6ICMyMDk3OEY7LS1iYWNrZ3JvdW5kOiAjMjA5NzhGO291dGxpbmU6IG5vbmU7fVxyXG4uZm9yZ2V0X2xhYmxle2ZvbnQtZmFtaWx5OlBvcHBpbnMtTGlnaHQgIWltcG9ydGFudDtjb2xvcjogI2ZmZjttYXJnaW4tdG9wOiAxNXB4O2Zsb2F0OiByaWdodDt0ZXh0LWRlY29yYXRpb246IG5vbmU7dGV4dC1hbGlnbjogY2VudGVyO31cclxuLmxvd2VyX2NvbnRlbnQge2ZvbnQtZmFtaWx5OlBvcHBpbnMtTGlnaHQgIWltcG9ydGFudDsgcGFkZGluZy1ib3R0b206IDAgIWltcG9ydGFudDtib3R0b206MHB4OyBwYWRkaW5nOiA1cHg7bWFyZ2luLXRvcDogMzBweDsgIGNvbG9yOiAjZmZmO2ZvbnQtc2l6ZTogMTRweDtmbG9hdDogcmlnaHQ7dGV4dC1kZWNvcmF0aW9uOiBub25lO3RleHQtYWxpZ246IGNlbnRlcjt9XHJcbi5mb290ZXJfcHJle2ZvbnQtZmFtaWx5OlBvcHBpbnMtTGlnaHQgIWltcG9ydGFudDt9XHJcbi5mb290ZXJfdGV4dHsgd2lkdGg6IDEwMCU7cGFkZGluZy1ib3R0b206IDAgIWltcG9ydGFudDtwb3NpdGlvbjogYWJzb2x1dGU7Ym90dG9tOjBweDsgcGFkZGluZzogNXB4O21hcmdpbi1ib3R0b206IDMwcHg7IG1hcmdpbi10b3A6IDIwcHg7IGZvbnQtZmFtaWx5OlBvcHBpbnMtTGlnaHQgIWltcG9ydGFudDtjb2xvcjogI2ZmZjtmb250LXdlaWdodDogNTAwO2ZvbnQtc2l6ZTogMTBweDt0ZXh0LWFsaWduOiBjZW50ZXI7ZmxvYXQ6IHJpZ2h0O31cclxuIl19 */");

/***/ }),

/***/ 3758:
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/login/login.component.html ***!
  \****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content [fullscreen]=\"true\" >\n   <div class=\"body_container\">\n    <div class=\"body_overlay\">\n        <ion-row>\n            <ion-col size=\"4\" offset=\"4\">\n              <img class=\"logo_container\" src=\"../../../assets/second_logo.png\" alt=\"logo-image\"/>\n            </ion-col>\n       </ion-row>\n       <ion-grid class=\"login_container\">\n       <label class=\"input_lable\">Email / Mobile No</label>\n       <ion-row class=\"input_box\">\n        <ion-col  size=\"1\">\n            <ion-icon class=\"input_icon\" name=\"mail-outline\"></ion-icon>\n        </ion-col>\n        <ion-col size=\"9\">\n           <ion-input class=\"input_text\"  [type]=\"email_type\"  [(ngModel)]=\"email_user\"  ></ion-input>\n          </ion-col>\n   </ion-row>\n\n   <label class=\"input_lable\">Password</label>\n       <ion-row class=\"input_box\">\n        <ion-col  size=\"1\">\n            <ion-icon  class=\"input_icon\" name=\"lock-closed-outline\"></ion-icon>\n        </ion-col>\n        <ion-col size=\"8.9\">\n           <ion-input class=\"input_text\"  [type]=\"password_type\" [(ngModel)]=\"user_pass\"></ion-input>\n          </ion-col>\n          <ion-col  size=\"1\">\n            <ion-icon name=\"eye\" class=\"input_icon\" item-right (click)=\"togglePasswordMode()\"></ion-icon>\n        </ion-col>\n         \n   </ion-row>\n \n\n   <ion-button class=\"_button\" (click)=\"login()\" >LOGIN</ion-button>\n\n   <ion-row >\n    <ion-col>\n    <a class=\"forget_lable\"  item-right (click)=\"resetpassword()\">Forget Password?</a></ion-col>\n    </ion-row>\n\n    <ion-row>\n        <a  class=\"lower_content\" item-right (click)=\"terms()\">  By clicking on <b>\"sign in\"</b> you agree with out term of user and policy</a>\n    </ion-row>\n    \n    </ion-grid>\n  </div>\n\n</div>\n\n<div class=\"footer_text\"><span class=\"footer_pre\">ReConnect</span>@ is part of IFA Group.All Rights Reserved.</div>\n</ion-content>\n\n ");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_login_login_module_ts.js.map