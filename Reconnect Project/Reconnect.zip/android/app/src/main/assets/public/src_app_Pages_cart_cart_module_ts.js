(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_cart_cart_module_ts"],{

/***/ 6477:
/*!***************************************************!*\
  !*** ./src/app/Pages/cart/cart-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartPageRoutingModule": () => (/* binding */ CartPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _cart_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cart.component */ 6645);




const routes = [
    {
        path: '',
        component: _cart_component__WEBPACK_IMPORTED_MODULE_0__.CartComponent,
    }
];
let CartPageRoutingModule = class CartPageRoutingModule {
};
CartPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], CartPageRoutingModule);



/***/ }),

/***/ 6645:
/*!**********************************************!*\
  !*** ./src/app/Pages/cart/cart.component.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartComponent": () => (/* binding */ CartComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_cart_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./cart.component.html */ 5185);
/* harmony import */ var _cart_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cart.component.css */ 5230);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let CartComponent = class CartComponent {
    constructor() { }
    ngOnInit() {
    }
};
CartComponent.ctorParameters = () => [];
CartComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-cart',
        template: _raw_loader_cart_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_cart_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CartComponent);



/***/ }),

/***/ 134:
/*!*******************************************!*\
  !*** ./src/app/Pages/cart/cart.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartPageModule": () => (/* binding */ CartPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _cart_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cart.component */ 6645);
/* harmony import */ var _cart_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cart-routing.module */ 6477);







let CartPageModule = class CartPageModule {
};
CartPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _cart_routing_module__WEBPACK_IMPORTED_MODULE_1__.CartPageRoutingModule
        ],
        declarations: [_cart_component__WEBPACK_IMPORTED_MODULE_0__.CartComponent]
    })
], CartPageModule);



/***/ }),

/***/ 5230:
/*!***********************************************!*\
  !*** ./src/app/Pages/cart/cart.component.css ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 130px; background:url('banner-bg.jpg');--background-repeat: no-repeat;\r\n    --background-size: cover;  background-size: cover;}\r\n  .header_overlay{background:#20978f69;height: 130px;}\r\n  .icon_conatiner{padding-top: 10px;}\r\n  ion-back-button{\r\n    --color: white;\r\n  }\r\n  .header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n  ._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n  ._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n  .right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n  .container_view{margin: 10px;}\r\n  .expandable_container{background: #fff;}\r\n  .exapandable_view{background-color: #75b1b9;padding: 10px;width: 100%;color:#fff;font-family:Poppins-Medium !important;}\r\n  .card_view{height: 100px;padding: 0px;margin: 0px;color: #fff;font-family:Poppins-Medium !important;}\r\n  .card_lable_number{font-size: 22px;font-weight: bolder;}\r\n  .card_lable_text{font-size: 15px;}\r\n  .black_layer{padding: 0px;margin: 10px;}\r\n  .card_lable_view{text-align: center;font-size: 9px;width: 100%;}\r\n  .total_item{font-family:Poppins-Medium !important;margin: 10px;font-weight: bold;color: #545252;}\r\n  .list_container{margin: 5px;}\r\n  .list_row{margin: 10px 5px 10px 5px}\r\n  .img_icon{width: 50px;height: 50px;}\r\n  .p_title{margin-left: 10px;width: 100%; font-size: 13px; color: rgb(85, 83, 83);font-weight: 600;font-family:Poppins-Medium !important;}\r\n  .p_sub_title{margin-left: 10px; width: 100%; font-size: 13px; color: rgb(112, 111, 111);font-family:Poppins-Medium !important;}\r\n  .p_price{margin-left: 10px;font-size: 13px;margin-top: 3px;font-family:Poppins-Medium !important;}\r\n  .save_{\r\n  width: 120px;\r\n  --background-activated: #2fc3e4;\r\n  background: #2fc3e4;\r\n  height: 32px;\r\n  /* font-size: 14px; */\r\n  border-radius: 4px;\r\n  color: #fff;\r\n    }\r\n  ._remove\r\n    {\r\n      \r\n      --background-activated: #2fc3e4;\r\n      background: #f44336;\r\n      height: 32px;\r\n      width: 32px;\r\n      margin-left: 20px;\r\n      /* font-size: 14px; */\r\n      border-radius: 4px;\r\n      color: #fff;\r\n    }\r\n  .bottom_container {\r\n    position: fixed;\r\n    left: 0;\r\n    bottom: 10px;\r\n    right: 0;\r\n}\r\n  ._button{margin: 0px auto;\r\n  width: 90%;\r\n    margin-top: 10px;\r\n    margin-bottom: 10px;\r\n    --background-activated:#20978F;\r\n    display: block;\r\n    --background: #75b1b9;\r\n    font-size: 18px;\r\n    --border-radius: 5px;\r\n    height: 40px;}\r\n  .total_{width: 100%;border-top:1px solid #cccccc ;padding: 10px;}\r\n  .price_title_bottom{font-family:Poppins-Medium !important;}\r\n  .price_title_bottom_value  {font-family:Poppins-Medium !important;color: #47bfd8;} \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcnQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxlQUFlLFdBQVcsQ0FBQyxhQUFhLEVBQUUsK0JBQTZDLENBQUMsOEJBQThCO0lBQ2xILHdCQUF3QixHQUFHLHNCQUFzQixDQUFDO0VBQ3BELGdCQUFnQixvQkFBb0IsQ0FBQyxhQUFhLENBQUM7RUFDbkQsZ0JBQWdCLGlCQUFpQixDQUFDO0VBQ2xDO0lBQ0UsY0FBYztFQUNoQjtFQUNBLGNBQWMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxxQ0FBcUMsQ0FBQyxlQUFlLEVBQUU7RUFDaEgsWUFBWSxXQUFXLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQztFQUN4RCxZQUFZLFdBQVcsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDO0VBQzFFLFlBQVksV0FBVyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUM7RUFDdkYsZ0JBQWdCLFlBQVksQ0FBQztFQUM3QixzQkFBc0IsZ0JBQWdCLENBQUM7RUFDdkMsa0JBQWtCLHlCQUF5QixDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLHFDQUFxQyxDQUFDO0VBQ3ZILFdBQVcsYUFBYSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLHFDQUFxQyxDQUFDO0VBQ3BHLG1CQUFtQixlQUFlLENBQUMsbUJBQW1CLENBQUM7RUFDdkQsaUJBQWlCLGVBQWUsQ0FBQztFQUNqQyxhQUFhLFlBQVksQ0FBQyxZQUFZLENBQUM7RUFDdkMsaUJBQWlCLGtCQUFrQixDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUM7RUFDL0QsWUFBWSxxQ0FBcUMsQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsY0FBYyxDQUFDO0VBQ2hHLGdCQUFnQixXQUFXLENBQUM7RUFDOUIsVUFBVSx5QkFBeUI7RUFDbkMsVUFBVSxXQUFXLENBQUMsWUFBWSxDQUFDO0VBQ25DLFNBQVMsaUJBQWlCLENBQUMsV0FBVyxFQUFFLGVBQWUsRUFBRSxzQkFBc0IsQ0FBQyxnQkFBZ0IsQ0FBQyxxQ0FBcUMsQ0FBQztFQUN2SSxhQUFhLGlCQUFpQixFQUFFLFdBQVcsRUFBRSxlQUFlLEVBQUUseUJBQXlCLENBQUMscUNBQXFDLENBQUM7RUFDOUgsU0FBUyxpQkFBaUIsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLHFDQUFxQyxDQUFDO0VBQ2pHO0VBQ0UsWUFBWTtFQUNaLCtCQUErQjtFQUMvQixtQkFBbUI7RUFDbkIsWUFBWTtFQUNaLHFCQUFxQjtFQUNyQixrQkFBa0I7RUFDbEIsV0FBVztJQUNUO0VBQ0E7OztNQUdFLCtCQUErQjtNQUMvQixtQkFBbUI7TUFDbkIsWUFBWTtNQUNaLFdBQVc7TUFDWCxpQkFBaUI7TUFDakIscUJBQXFCO01BQ3JCLGtCQUFrQjtNQUNsQixXQUFXO0lBQ2I7RUFDSjtJQUNJLGVBQWU7SUFDZixPQUFPO0lBQ1AsWUFBWTtJQUNaLFFBQVE7QUFDWjtFQUNBLFNBQVMsZ0JBQWdCO0VBQ3ZCLFVBQVU7SUFDUixnQkFBZ0I7SUFDaEIsbUJBQW1CO0lBQ25CLDhCQUE4QjtJQUM5QixjQUFjO0lBQ2QscUJBQXFCO0lBQ3JCLGVBQWU7SUFDZixvQkFBb0I7SUFDcEIsWUFBWSxDQUFDO0VBQ2hCLFFBQVEsV0FBVyxDQUFDLDZCQUE2QixDQUFDLGFBQWEsQ0FBQztFQUNoRSxvQkFBb0IscUNBQXFDLENBQUM7RUFDMUQsNEJBQTRCLHFDQUFxQyxDQUFDLGNBQWMsQ0FBQyIsImZpbGUiOiJjYXJ0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyX2Jhbm5lcnt3aWR0aDogMTAwJTtoZWlnaHQ6IDEzMHB4OyBiYWNrZ3JvdW5kOnVybCguLi8uLi8uLi9hc3NldHMvYmFubmVyLWJnLmpwZyk7LS1iYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgLS1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyOyAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjt9XHJcbiAgLmhlYWRlcl9vdmVybGF5e2JhY2tncm91bmQ6IzIwOTc4ZjY5O2hlaWdodDogMTMwcHg7fVxyXG4gIC5pY29uX2NvbmF0aW5lcntwYWRkaW5nLXRvcDogMTBweDt9XHJcbiAgaW9uLWJhY2stYnV0dG9ue1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgfVxyXG4gIC5oZWFkZXJfdGl0bGV7Y29sb3I6ICNmZmY7dGV4dC1hbGlnbjogY2VudGVyO3dpZHRoOiAxMDAlO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7Zm9udC1zaXplOiAxOHB4Ozt9XHJcbiAgLl9tZW51X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiAwcHggMHB4O2ZvbnQtc2l6ZTogMzBweDt9ICAgXHJcbiAgLl9jYXJ0X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiA4cHggMHB4O2ZvbnQtc2l6ZTogMjZweDttYXJnaW4tbGVmdDogMTBweDt9XHJcbiAgLnJpZ2h0X2xvZ297d2lkdGg6IDMwcHg7aGVpZ2h0OiAzNXB4O2Zsb2F0OiByaWdodDttYXJnaW4tdG9wOiAtMTlweDttYXJnaW4tcmlnaHQ6IDE1cHg7fVxyXG4gIC5jb250YWluZXJfdmlld3ttYXJnaW46IDEwcHg7fVxyXG4gIC5leHBhbmRhYmxlX2NvbnRhaW5lcntiYWNrZ3JvdW5kOiAjZmZmO31cclxuICAuZXhhcGFuZGFibGVfdmlld3tiYWNrZ3JvdW5kLWNvbG9yOiAjNzViMWI5O3BhZGRpbmc6IDEwcHg7d2lkdGg6IDEwMCU7Y29sb3I6I2ZmZjtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O31cclxuICAuY2FyZF92aWV3e2hlaWdodDogMTAwcHg7cGFkZGluZzogMHB4O21hcmdpbjogMHB4O2NvbG9yOiAjZmZmO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7fVxyXG4gIC5jYXJkX2xhYmxlX251bWJlcntmb250LXNpemU6IDIycHg7Zm9udC13ZWlnaHQ6IGJvbGRlcjt9XHJcbiAgLmNhcmRfbGFibGVfdGV4dHtmb250LXNpemU6IDE1cHg7fVxyXG4gIC5ibGFja19sYXllcntwYWRkaW5nOiAwcHg7bWFyZ2luOiAxMHB4O31cclxuICAuY2FyZF9sYWJsZV92aWV3e3RleHQtYWxpZ246IGNlbnRlcjtmb250LXNpemU6IDlweDt3aWR0aDogMTAwJTt9XHJcbiAgLnRvdGFsX2l0ZW17Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDttYXJnaW46IDEwcHg7Zm9udC13ZWlnaHQ6IGJvbGQ7Y29sb3I6ICM1NDUyNTI7fVxyXG4gIC5saXN0X2NvbnRhaW5lcnttYXJnaW46IDVweDt9XHJcbi5saXN0X3Jvd3ttYXJnaW46IDEwcHggNXB4IDEwcHggNXB4fVxyXG4uaW1nX2ljb257d2lkdGg6IDUwcHg7aGVpZ2h0OiA1MHB4O31cclxuLnBfdGl0bGV7bWFyZ2luLWxlZnQ6IDEwcHg7d2lkdGg6IDEwMCU7IGZvbnQtc2l6ZTogMTNweDsgY29sb3I6IHJnYig4NSwgODMsIDgzKTtmb250LXdlaWdodDogNjAwO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7fVxyXG4ucF9zdWJfdGl0bGV7bWFyZ2luLWxlZnQ6IDEwcHg7IHdpZHRoOiAxMDAlOyBmb250LXNpemU6IDEzcHg7IGNvbG9yOiByZ2IoMTEyLCAxMTEsIDExMSk7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbi5wX3ByaWNle21hcmdpbi1sZWZ0OiAxMHB4O2ZvbnQtc2l6ZTogMTNweDttYXJnaW4tdG9wOiAzcHg7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbi5zYXZlX3tcclxuICB3aWR0aDogMTIwcHg7XHJcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzJmYzNlNDtcclxuICBiYWNrZ3JvdW5kOiAjMmZjM2U0O1xyXG4gIGhlaWdodDogMzJweDtcclxuICAvKiBmb250LXNpemU6IDE0cHg7ICovXHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gICAgfVxyXG4gICAgLl9yZW1vdmVcclxuICAgIHtcclxuICAgICAgXHJcbiAgICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICMyZmMzZTQ7XHJcbiAgICAgIGJhY2tncm91bmQ6ICNmNDQzMzY7XHJcbiAgICAgIGhlaWdodDogMzJweDtcclxuICAgICAgd2lkdGg6IDMycHg7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgICAvKiBmb250LXNpemU6IDE0cHg7ICovXHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICB9XHJcbi5ib3R0b21fY29udGFpbmVyIHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICBib3R0b206IDEwcHg7XHJcbiAgICByaWdodDogMDtcclxufVxyXG4uX2J1dHRvbnttYXJnaW46IDBweCBhdXRvO1xyXG4gIHdpZHRoOiA5MCU7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IzIwOTc4RjtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjNzViMWI5O1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7fVxyXG4gLnRvdGFsX3t3aWR0aDogMTAwJTtib3JkZXItdG9wOjFweCBzb2xpZCAjY2NjY2NjIDtwYWRkaW5nOiAxMHB4O31cclxuIC5wcmljZV90aXRsZV9ib3R0b217Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbiAucHJpY2VfdGl0bGVfYm90dG9tX3ZhbHVlICB7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtjb2xvcjogIzQ3YmZkODt9ICJdfQ== */");

/***/ }),

/***/ 5185:
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/cart/cart.component.html ***!
  \**************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">My Cart</ion-label></ion-row>\n         </div>\n   \n      </div>\n    </div>\n    <ion-row>\n        <label class=\"total_item\">2 Items</label>\n        \n    </ion-row>\n    <ion-list class=\"list_container\">\n        <ion-row class=\"list_row\"  *ngFor=\"let card of [0,1] \">\n        \n           <ion-col size=4>\n           \n              <img style=\" width: 108px; height: 108px;border-radius: 5px;\" src=\"../../../assets/sample.jpg\">\n      \n           </ion-col>\n  \n           <ion-col size=7>\n            <ion-row><label class=\"p_title\">Fit and Lift Gym Center</label></ion-row>\n            <ion-row> <label class=\"p_sub_title\">Marcus</label></ion-row>\n            <ion-row> <label class=\"p_price\">$4000.00</label></ion-row>\n            <ion-row>\n                <ion-col size=7><button class=\"save_\">Save For Later</button></ion-col>\n                <ion-col size=3 offset=\"1\"><button class=\"_remove\" color=\"danger\" ><ion-icon name=\"trash\"></ion-icon></button></ion-col>\n            </ion-row>\n           \n          </ion-col>\n  \n        </ion-row>\n       \n      </ion-list>\n      <div class=\"bottom_container\">\n         <ion-row class=\"total_\">\n          <ion-col size=7><label class=\"price_title_bottom\">Total Price</label> </ion-col>\n          <ion-col size=3 offset=\"2\"><label class=\"price_title_bottom_value\">$80000</label> </ion-col>\n         </ion-row>\n        <ion-button class=\"_button\"  >Make Payment</ion-button>\n      </div>\n  \n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_cart_cart_module_ts.js.map