(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_checkout_checkout_module_ts"],{

/***/ 2709:
/*!***********************************************************!*\
  !*** ./src/app/Pages/checkout/checkout-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CheckoutPageRoutingModule": () => (/* binding */ CheckoutPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _checkout_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./checkout.component */ 9667);




const routes = [
    {
        path: '',
        component: _checkout_component__WEBPACK_IMPORTED_MODULE_0__.CheckoutComponent,
    }
];
let CheckoutPageRoutingModule = class CheckoutPageRoutingModule {
};
CheckoutPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], CheckoutPageRoutingModule);



/***/ }),

/***/ 9667:
/*!******************************************************!*\
  !*** ./src/app/Pages/checkout/checkout.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CheckoutComponent": () => (/* binding */ CheckoutComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_checkout_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./checkout.component.html */ 4162);
/* harmony import */ var _checkout_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./checkout.component.css */ 7733);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let CheckoutComponent = class CheckoutComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    success() {
        this.router.navigate(['/success']);
    }
};
CheckoutComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
CheckoutComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-checkout',
        template: _raw_loader_checkout_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_checkout_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CheckoutComponent);



/***/ }),

/***/ 9780:
/*!***************************************************!*\
  !*** ./src/app/Pages/checkout/checkout.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CheckoutPageModule": () => (/* binding */ CheckoutPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _checkout_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./checkout.component */ 9667);
/* harmony import */ var _checkout_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./checkout-routing.module */ 2709);







let CheckoutPageModule = class CheckoutPageModule {
};
CheckoutPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _checkout_routing_module__WEBPACK_IMPORTED_MODULE_1__.CheckoutPageRoutingModule
        ],
        declarations: [_checkout_component__WEBPACK_IMPORTED_MODULE_0__.CheckoutComponent]
    })
], CheckoutPageModule);



/***/ }),

/***/ 7733:
/*!*******************************************************!*\
  !*** ./src/app/Pages/checkout/checkout.component.css ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 130px; background:url('banner-bg.jpg');--background-repeat: no-repeat;\r\n    --background-size: cover;  background-size: cover;}\r\n  .header_overlay{background:#20978f69;height: 130px;}\r\n  .icon_conatiner{padding-top: 10px;}\r\n  ion-back-button{\r\n    --color: white;\r\n  }\r\n  .header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n  ._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n  ._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n  .right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n  .checkout_container{margin: 10px;}\r\n  .input_container{width: 100%;\r\n    border: 2px solid #ddd;\r\n    margin: 0px auto;\r\n    border-radius: 5px;\r\n    padding: 5px;\r\n    margin-top: 13px;}\r\n  .input_title{margin-left: 4px;font-family:Poppins-Medium !important;color: gray;font-size: 10px;width: 100%;display: block;}\r\n  .custome_dp{\r\n        width: 100%;\r\n        display: block;\r\n        background: transparent;\r\n        margin: 3px;\r\n        border: none;outline: none;font-family:Poppins-Medium !important; -webkit-appearance: none;\r\n        -moz-appearance: none;\r\n        text-indent: 1px;\r\n        text-overflow: '';}\r\n  .radio_btn{margin-right: 10px; background: transparent!important;}\r\n  .or_dt{font-family:Poppins-Medium !important;}\r\n  .list_row{margin: 10px 5px 10px 5px}\r\n  .img_icon{width: 50px;height: 50px;}\r\n  .p_title{margin-left: 10px;width: 100%; font-size: 13px; color: rgb(85, 83, 83);font-weight: 600;font-family:Poppins-Medium !important;}\r\n  .p_sub_title{margin-left: 10px; width: 100%; font-size: 13px; color: rgb(112, 111, 111);font-family:Poppins-Medium !important;}\r\n  .p_price{margin-left: 10px;font-size: 13px;margin-top: 3px;font-family:Poppins-Medium !important;}\r\n  .bottom_container {\r\n    position: fixed;\r\n    left: 0;\r\n    bottom: 0;\r\n    background: #f5f5f5;\r\n    right: 0;\r\n}\r\n  .total_{width: 100%;border-top:1px solid #cccccc ;padding: 10px;}\r\n  .price_title_bottom{font-family:Poppins-Medium !important;font-size: 9px;}\r\n  .price_title_bottom_value  {font-family:Poppins-Medium !important;color: #47bfd8;}\r\n  ._button{margin: 0px auto;\r\n    width: 90%;\r\n      margin-bottom: 10px;\r\n      --background-activated:#20978F;\r\n      display: block;\r\n      --background: #75b1b9;\r\n      font-size: 18px;\r\n      --border-radius: 5px;\r\n      height: 40px;}\r\n  .list_container{padding-bottom: 150px;}    \r\n       \r\n   \r\n   \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoZWNrb3V0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZUFBZSxXQUFXLENBQUMsYUFBYSxFQUFFLCtCQUE2QyxDQUFDLDhCQUE4QjtJQUNsSCx3QkFBd0IsR0FBRyxzQkFBc0IsQ0FBQztFQUNwRCxnQkFBZ0Isb0JBQW9CLENBQUMsYUFBYSxDQUFDO0VBQ25ELGdCQUFnQixpQkFBaUIsQ0FBQztFQUNsQztJQUNFLGNBQWM7RUFDaEI7RUFDQSxjQUFjLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMscUNBQXFDLENBQUMsZUFBZSxFQUFFO0VBQ2hILFlBQVksV0FBVyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUM7RUFDeEQsWUFBWSxXQUFXLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQztFQUMxRSxZQUFZLFdBQVcsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDO0VBRXZGLG9CQUFvQixZQUFZLENBQUM7RUFDakMsaUJBQWlCLFdBQVc7SUFDMUIsc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLGdCQUFnQixDQUFDO0VBQ2pCLGFBQWEsZ0JBQWdCLENBQUMscUNBQXFDLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDO0VBQzNIO1FBQ0ksV0FBVztRQUNYLGNBQWM7UUFDZCx1QkFBdUI7UUFDdkIsV0FBVztRQUNYLFlBQVksQ0FBQyxhQUFhLENBQUMscUNBQXFDLEVBQUUsd0JBQXdCO1FBQzFGLHFCQUFxQjtRQUNyQixnQkFBZ0I7UUFDaEIsaUJBQWlCLENBQUM7RUFDdEIsV0FBVyxrQkFBa0IsRUFBRSxpQ0FBaUMsQ0FBQztFQUNqRSxPQUFPLHFDQUFxQyxDQUFDO0VBQ2pELFVBQVUseUJBQXlCO0VBQ25DLFVBQVUsV0FBVyxDQUFDLFlBQVksQ0FBQztFQUNuQyxTQUFTLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxlQUFlLEVBQUUsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUMscUNBQXFDLENBQUM7RUFDdkksYUFBYSxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLHlCQUF5QixDQUFDLHFDQUFxQyxDQUFDO0VBQzlILFNBQVMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxxQ0FBcUMsQ0FBQztFQUNqRztJQUNJLGVBQWU7SUFDZixPQUFPO0lBQ1AsU0FBUztJQUNULG1CQUFtQjtJQUNuQixRQUFRO0FBQ1o7RUFDQSxRQUFRLFdBQVcsQ0FBQyw2QkFBNkIsQ0FBQyxhQUFhLENBQUM7RUFDL0Qsb0JBQW9CLHFDQUFxQyxDQUFDLGNBQWMsQ0FBQztFQUN6RSw0QkFBNEIscUNBQXFDLENBQUMsY0FBYyxDQUFDO0VBQ2pGLFNBQVMsZ0JBQWdCO0lBQ3RCLFVBQVU7TUFDUixtQkFBbUI7TUFDbkIsOEJBQThCO01BQzlCLGNBQWM7TUFDZCxxQkFBcUI7TUFDckIsZUFBZTtNQUNmLG9CQUFvQjtNQUNwQixZQUFZLENBQUM7RUFDYixnQkFBZ0IscUJBQXFCLENBQUMiLCJmaWxlIjoiY2hlY2tvdXQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJfYmFubmVye3dpZHRoOiAxMDAlO2hlaWdodDogMTMwcHg7IGJhY2tncm91bmQ6dXJsKC4uLy4uLy4uL2Fzc2V0cy9iYW5uZXItYmcuanBnKTstLWJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAtLWJhY2tncm91bmQtc2l6ZTogY292ZXI7ICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO31cclxuICAuaGVhZGVyX292ZXJsYXl7YmFja2dyb3VuZDojMjA5NzhmNjk7aGVpZ2h0OiAxMzBweDt9XHJcbiAgLmljb25fY29uYXRpbmVye3BhZGRpbmctdG9wOiAxMHB4O31cclxuICBpb24tYmFjay1idXR0b257XHJcbiAgICAtLWNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiAgLmhlYWRlcl90aXRsZXtjb2xvcjogI2ZmZjt0ZXh0LWFsaWduOiBjZW50ZXI7d2lkdGg6IDEwMCU7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtmb250LXNpemU6IDE4cHg7O31cclxuICAuX21lbnVfaWNvbntjb2xvcjogI2ZmZjttYXJnaW46IDBweCAwcHg7Zm9udC1zaXplOiAzMHB4O30gICBcclxuICAuX2NhcnRfaWNvbntjb2xvcjogI2ZmZjttYXJnaW46IDhweCAwcHg7Zm9udC1zaXplOiAyNnB4O21hcmdpbi1sZWZ0OiAxMHB4O31cclxuICAucmlnaHRfbG9nb3t3aWR0aDogMzBweDtoZWlnaHQ6IDM1cHg7ZmxvYXQ6IHJpZ2h0O21hcmdpbi10b3A6IC0xOXB4O21hcmdpbi1yaWdodDogMTVweDt9XHJcblxyXG4gIC5jaGVja291dF9jb250YWluZXJ7bWFyZ2luOiAxMHB4O31cclxuICAuaW5wdXRfY29udGFpbmVye3dpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgI2RkZDtcclxuICAgIG1hcmdpbjogMHB4IGF1dG87XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxM3B4O31cclxuICAgIC5pbnB1dF90aXRsZXttYXJnaW4tbGVmdDogNHB4O2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7Y29sb3I6IGdyYXk7Zm9udC1zaXplOiAxMHB4O3dpZHRoOiAxMDAlO2Rpc3BsYXk6IGJsb2NrO31cclxuICAgIC5jdXN0b21lX2Rwe1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIG1hcmdpbjogM3B4O1xyXG4gICAgICAgIGJvcmRlcjogbm9uZTtvdXRsaW5lOiBub25lO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7IC13ZWJraXQtYXBwZWFyYW5jZTogbm9uZTtcclxuICAgICAgICAtbW96LWFwcGVhcmFuY2U6IG5vbmU7XHJcbiAgICAgICAgdGV4dC1pbmRlbnQ6IDFweDtcclxuICAgICAgICB0ZXh0LW92ZXJmbG93OiAnJzt9XHJcbiAgICAucmFkaW9fYnRue21hcmdpbi1yaWdodDogMTBweDsgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQhaW1wb3J0YW50O31cclxuICAgIC5vcl9kdHtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O31cclxuLmxpc3Rfcm93e21hcmdpbjogMTBweCA1cHggMTBweCA1cHh9XHJcbi5pbWdfaWNvbnt3aWR0aDogNTBweDtoZWlnaHQ6IDUwcHg7fVxyXG4ucF90aXRsZXttYXJnaW4tbGVmdDogMTBweDt3aWR0aDogMTAwJTsgZm9udC1zaXplOiAxM3B4OyBjb2xvcjogcmdiKDg1LCA4MywgODMpO2ZvbnQtd2VpZ2h0OiA2MDA7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbi5wX3N1Yl90aXRsZXttYXJnaW4tbGVmdDogMTBweDsgd2lkdGg6IDEwMCU7IGZvbnQtc2l6ZTogMTNweDsgY29sb3I6IHJnYigxMTIsIDExMSwgMTExKTtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O31cclxuLnBfcHJpY2V7bWFyZ2luLWxlZnQ6IDEwcHg7Zm9udC1zaXplOiAxM3B4O21hcmdpbi10b3A6IDNweDtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O30gXHJcbi5ib3R0b21fY29udGFpbmVyIHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZjVmNWY1O1xyXG4gICAgcmlnaHQ6IDA7XHJcbn1cclxuLnRvdGFsX3t3aWR0aDogMTAwJTtib3JkZXItdG9wOjFweCBzb2xpZCAjY2NjY2NjIDtwYWRkaW5nOiAxMHB4O31cclxuIC5wcmljZV90aXRsZV9ib3R0b217Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtmb250LXNpemU6IDlweDt9XHJcbiAucHJpY2VfdGl0bGVfYm90dG9tX3ZhbHVlICB7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtjb2xvcjogIzQ3YmZkODt9XHJcbiAuX2J1dHRvbnttYXJnaW46IDBweCBhdXRvO1xyXG4gICAgd2lkdGg6IDkwJTtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICAgICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDojMjA5NzhGO1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgLS1iYWNrZ3JvdW5kOiAjNzViMWI5O1xyXG4gICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgIC0tYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICBoZWlnaHQ6IDQwcHg7fVxyXG4gICAgICAubGlzdF9jb250YWluZXJ7cGFkZGluZy1ib3R0b206IDE1MHB4O30gICAgXHJcbiAgICAgICBcclxuICAgXHJcbiAgICJdfQ== */");

/***/ }),

/***/ 4162:
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/checkout/checkout.component.html ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">Checkout</ion-label></ion-row>\n         </div>\n   \n      </div>\n   <div class=\"checkout_container\">\n   <div class=\"input_container\">\n    <label class=\"input_title\">Country</label>\n    <select class=\"custome_dp\">\n        <option class=\"select_option\" >Select</option>\n        <option class=\"select_option\" >India</option>\n    </select>\n   </div>\n\n   <div class=\"input_container\">\n    <label class=\"input_title\">State / Union Territory</label>\n    <select class=\"custome_dp\">\n        <option class=\"select_option\" >Select</option>\n        <option class=\"select_option\" >India</option>\n    </select>\n   </div>\n\n   <ion-list>\n  <ion-radio-group>\n    <ion-item lines=\"none\">\n      <ion-radio class=\"radio_btn\" value=\"card\"></ion-radio>\n      <ion-label>Credit/Debit card</ion-label>\n    </ion-item>\n    <ion-item lines=\"none\">\n        <ion-radio class=\"radio_btn\" value=\"net\"></ion-radio>\n        <ion-label>Net Banking</ion-label>\n      </ion-item>\n\n      <ion-item lines=\"none\">\n        <ion-radio class=\"radio_btn\" value=\"upi\"></ion-radio>\n        <ion-label>Pay With UPI</ion-label>\n      </ion-item>  \n      <ion-item lines=\"none\">\n        <ion-radio class=\"radio_btn\" value=\"pytm\"></ion-radio>\n        <ion-label>Pay With Paytm</ion-label>\n      </ion-item>  \n  </ion-radio-group>\n</ion-list>\n<ion-label class=\"or_dt\">\n    Order Details\n  </ion-label>\n  <ion-list class=\"list_container\">\n    <ion-row class=\"list_row\"  *ngFor=\"let card of [0,1] \">\n    \n       <ion-col size=2>\n       \n          <img style=\" width: 50px; height: 50px;border-radius: 5px;\" src=\"../../../assets/sample.jpg\">\n  \n       </ion-col>\n\n       <ion-col size=7>\n        <ion-row><label class=\"p_title\">Fit and Lift Gym Center</label></ion-row>\n        <ion-row> <label class=\"p_price\">$4000.00</label></ion-row>\n      \n       \n      </ion-col>\n\n    </ion-row>\n   \n  </ion-list>\n\n  <div class=\"bottom_container\">\n    <ion-row class=\"total_\">\n     <ion-col ><label class=\"price_title_bottom\">By completing your purchase you agree with there\n         Terms Of Service\n     </label> </ion-col>\n     <ion-col size=3 ><label class=\"price_title_bottom_value\">$80000</label> </ion-col>\n    </ion-row>\n   <ion-button class=\"_button\" (click)=\"success()\"  >Complete Payment</ion-button>\n </div>\n</div>   \n    </div>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_checkout_checkout_module_ts.js.map