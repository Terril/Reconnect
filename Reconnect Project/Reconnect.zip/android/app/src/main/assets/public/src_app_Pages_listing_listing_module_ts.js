(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_listing_listing_module_ts"],{

/***/ 2845:
/*!*********************************************************!*\
  !*** ./src/app/Pages/listing/listing-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListingPageRoutingModule": () => (/* binding */ ListingPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _listing_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./listing.component */ 3094);




const routes = [
    {
        path: '',
        component: _listing_component__WEBPACK_IMPORTED_MODULE_0__.ListingComponent,
    }
];
let ListingPageRoutingModule = class ListingPageRoutingModule {
};
ListingPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], ListingPageRoutingModule);



/***/ }),

/***/ 3094:
/*!****************************************************!*\
  !*** ./src/app/Pages/listing/listing.component.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListingComponent": () => (/* binding */ ListingComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_listing_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./listing.component.html */ 9816);
/* harmony import */ var _listing_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./listing.component.css */ 9154);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let ListingComponent = class ListingComponent {
    constructor(router) {
        this.router = router;
        this.list = new Array(5);
        this.condition = 2;
    }
    ngOnInit() {
    }
    detail_page() {
        this.router.navigate(['/details/1']);
    }
};
ListingComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
ListingComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-listing',
        template: _raw_loader_listing_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_listing_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ListingComponent);



/***/ }),

/***/ 830:
/*!*************************************************!*\
  !*** ./src/app/Pages/listing/listing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ListingPageModule": () => (/* binding */ ListingPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _listing_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./listing.component */ 3094);
/* harmony import */ var _listing_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./listing-routing.module */ 2845);







let ListingPageModule = class ListingPageModule {
};
ListingPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _listing_routing_module__WEBPACK_IMPORTED_MODULE_1__.ListingPageRoutingModule
        ],
        declarations: [_listing_component__WEBPACK_IMPORTED_MODULE_0__.ListingComponent]
    })
], ListingPageModule);



/***/ }),

/***/ 9154:
/*!*****************************************************!*\
  !*** ./src/app/Pages/listing/listing.component.css ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 130px; background:url('gym_booking.jpg');--background-repeat: no-repeat;\r\n  --background-size: cover;  background-size: cover;}\r\n.header_overlay{background:#20978f69;height: 130px;}\r\n.icon_conatiner{padding-top: 10px;}\r\nion-back-button{\r\n  --color: white;\r\n}\r\n.header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n.right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n.list_container{margin: 5px;}\r\n.list_row{margin: 10px 5px 10px 5px; box-shadow: 0 0px 4px 1px #ddd;border-radius: 5px;}\r\n.img_icon{width: 100px;height: 100px;margin-top: 20px;margin-left: 5px;}\r\n.p_title{margin: 5px; width: 100%; font-size: 13px; color: rgb(85, 83, 83);font-weight: 600;font-family: Georgia, 'Times New Roman', Times, serif;}\r\n.p_sub_title{margin: 3px 0px 0px 3px ; width: 100%; font-size: 13px; color: rgb(112, 111, 111);margin-bottom: 3px;font-family: Georgia, 'Times New Roman', Times, serif;}\r\n.p_location{font-size: 13px;margin-left: 4px;margin-top: 3px;margin-bottom: 3px;}\r\n.p_location ion-icon{color: rgb(100, 152, 231);margin-right: 5px;font-family: Georgia, 'Times New Roman', Times, serif;}\r\n.p_price{font-size: 13px;margin-left: 5px;margin-top: 3px;margin-bottom: 3px;font-family: Georgia, 'Times New Roman', Times, serif;}\r\n.p_time{font-size: 13px;margin-left: 5px;margin-top: 3px;font-family: Georgia, 'Times New Roman', Times, serif; }\r\n.card_content{margin: 5px;}\r\n.rating_star{color:#f9c011;font-size: 13px;margin-left: 5px;margin-top: 5px;margin-bottom: 5px;}\r\n.rating_number{color: rgb(114, 112, 112); font-size: 13px;font-weight: bold;margin-left: 5px;margin-top: 5px;}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxpc3RpbmcuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxlQUFlLFdBQVcsQ0FBQyxhQUFhLEVBQUUsaUNBQStDLENBQUMsOEJBQThCO0VBQ3RILHdCQUF3QixHQUFHLHNCQUFzQixDQUFDO0FBQ3BELGdCQUFnQixvQkFBb0IsQ0FBQyxhQUFhLENBQUM7QUFDbkQsZ0JBQWdCLGlCQUFpQixDQUFDO0FBQ2xDO0VBQ0UsY0FBYztBQUNoQjtBQUNBLGNBQWMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxxQ0FBcUMsQ0FBQyxlQUFlLEVBQUU7QUFDaEgsWUFBWSxXQUFXLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQztBQUN4RCxZQUFZLFdBQVcsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDO0FBQzFFLFlBQVksV0FBVyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUM7QUFFdkYsZ0JBQWdCLFdBQVcsQ0FBQztBQUM1QixVQUFVLHlCQUF5QixFQUFFLDhCQUE4QixDQUFDLGtCQUFrQixDQUFDO0FBQ3ZGLFVBQVUsWUFBWSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQztBQUN2RSxTQUFTLFdBQVcsRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLHNCQUFzQixDQUFDLGdCQUFnQixDQUFDLHFEQUFxRCxDQUFDO0FBQ2xKLGFBQWEsd0JBQXdCLEVBQUUsV0FBVyxFQUFFLGVBQWUsRUFBRSx5QkFBeUIsQ0FBQyxrQkFBa0IsQ0FBQyxxREFBcUQsQ0FBQztBQUN4SyxZQUFZLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUM7QUFDaEYscUJBQXFCLHlCQUF5QixDQUFDLGlCQUFpQixDQUFDLHFEQUFxRCxDQUFDO0FBQ3ZILFNBQVMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQyxxREFBcUQsQ0FBQztBQUNuSSxRQUFRLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMscURBQXFELEVBQUU7QUFDaEgsY0FBYyxXQUFXLENBQUM7QUFDMUIsYUFBYSxhQUFhLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQztBQUMvRixlQUFlLHlCQUF5QixFQUFFLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMiLCJmaWxlIjoibGlzdGluZy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlcl9iYW5uZXJ7d2lkdGg6IDEwMCU7aGVpZ2h0OiAxMzBweDsgYmFja2dyb3VuZDp1cmwoLi4vLi4vLi4vYXNzZXRzL2d5bV9ib29raW5nLmpwZyk7LS1iYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIC0tYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7fVxyXG4uaGVhZGVyX292ZXJsYXl7YmFja2dyb3VuZDojMjA5NzhmNjk7aGVpZ2h0OiAxMzBweDt9XHJcbi5pY29uX2NvbmF0aW5lcntwYWRkaW5nLXRvcDogMTBweDt9XHJcbmlvbi1iYWNrLWJ1dHRvbntcclxuICAtLWNvbG9yOiB3aGl0ZTtcclxufVxyXG4uaGVhZGVyX3RpdGxle2NvbG9yOiAjZmZmO3RleHQtYWxpZ246IGNlbnRlcjt3aWR0aDogMTAwJTtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O2ZvbnQtc2l6ZTogMThweDs7fVxyXG4uX21lbnVfaWNvbntjb2xvcjogI2ZmZjttYXJnaW46IDBweCAwcHg7Zm9udC1zaXplOiAzMHB4O30gICBcclxuLl9jYXJ0X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiA4cHggMHB4O2ZvbnQtc2l6ZTogMjZweDttYXJnaW4tbGVmdDogMTBweDt9XHJcbi5yaWdodF9sb2dve3dpZHRoOiAzMHB4O2hlaWdodDogMzVweDtmbG9hdDogcmlnaHQ7bWFyZ2luLXRvcDogLTE5cHg7bWFyZ2luLXJpZ2h0OiAxNXB4O31cclxuXHJcbi5saXN0X2NvbnRhaW5lcnttYXJnaW46IDVweDt9XHJcbi5saXN0X3Jvd3ttYXJnaW46IDEwcHggNXB4IDEwcHggNXB4OyBib3gtc2hhZG93OiAwIDBweCA0cHggMXB4ICNkZGQ7Ym9yZGVyLXJhZGl1czogNXB4O31cclxuLmltZ19pY29ue3dpZHRoOiAxMDBweDtoZWlnaHQ6IDEwMHB4O21hcmdpbi10b3A6IDIwcHg7bWFyZ2luLWxlZnQ6IDVweDt9XHJcbi5wX3RpdGxle21hcmdpbjogNXB4OyB3aWR0aDogMTAwJTsgZm9udC1zaXplOiAxM3B4OyBjb2xvcjogcmdiKDg1LCA4MywgODMpO2ZvbnQtd2VpZ2h0OiA2MDA7Zm9udC1mYW1pbHk6IEdlb3JnaWEsICdUaW1lcyBOZXcgUm9tYW4nLCBUaW1lcywgc2VyaWY7fVxyXG4ucF9zdWJfdGl0bGV7bWFyZ2luOiAzcHggMHB4IDBweCAzcHggOyB3aWR0aDogMTAwJTsgZm9udC1zaXplOiAxM3B4OyBjb2xvcjogcmdiKDExMiwgMTExLCAxMTEpO21hcmdpbi1ib3R0b206IDNweDtmb250LWZhbWlseTogR2VvcmdpYSwgJ1RpbWVzIE5ldyBSb21hbicsIFRpbWVzLCBzZXJpZjt9XHJcbi5wX2xvY2F0aW9ue2ZvbnQtc2l6ZTogMTNweDttYXJnaW4tbGVmdDogNHB4O21hcmdpbi10b3A6IDNweDttYXJnaW4tYm90dG9tOiAzcHg7fVxyXG4ucF9sb2NhdGlvbiBpb24taWNvbntjb2xvcjogcmdiKDEwMCwgMTUyLCAyMzEpO21hcmdpbi1yaWdodDogNXB4O2ZvbnQtZmFtaWx5OiBHZW9yZ2lhLCAnVGltZXMgTmV3IFJvbWFuJywgVGltZXMsIHNlcmlmO31cclxuLnBfcHJpY2V7Zm9udC1zaXplOiAxM3B4O21hcmdpbi1sZWZ0OiA1cHg7bWFyZ2luLXRvcDogM3B4O21hcmdpbi1ib3R0b206IDNweDtmb250LWZhbWlseTogR2VvcmdpYSwgJ1RpbWVzIE5ldyBSb21hbicsIFRpbWVzLCBzZXJpZjt9XHJcbi5wX3RpbWV7Zm9udC1zaXplOiAxM3B4O21hcmdpbi1sZWZ0OiA1cHg7bWFyZ2luLXRvcDogM3B4O2ZvbnQtZmFtaWx5OiBHZW9yZ2lhLCAnVGltZXMgTmV3IFJvbWFuJywgVGltZXMsIHNlcmlmOyB9XHJcbi5jYXJkX2NvbnRlbnR7bWFyZ2luOiA1cHg7fVxyXG4ucmF0aW5nX3N0YXJ7Y29sb3I6I2Y5YzAxMTtmb250LXNpemU6IDEzcHg7bWFyZ2luLWxlZnQ6IDVweDttYXJnaW4tdG9wOiA1cHg7bWFyZ2luLWJvdHRvbTogNXB4O31cclxuLnJhdGluZ19udW1iZXJ7Y29sb3I6IHJnYigxMTQsIDExMiwgMTEyKTsgZm9udC1zaXplOiAxM3B4O2ZvbnQtd2VpZ2h0OiBib2xkO21hcmdpbi1sZWZ0OiA1cHg7bWFyZ2luLXRvcDogNXB4O30iXX0= */");

/***/ }),

/***/ 9816:
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/listing/listing.component.html ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">Gym Booking</ion-label></ion-row>\n         </div>\n\n    \n\n      \n          \n   \n      </div>\n    </div>\n  \n    <ion-list class=\"list_container\">\n      <ion-row class=\"list_row\" (click)=\"detail_page()\" *ngFor=\"let card of [0,1,2,3,4,5,6] \">\n      \n         <ion-col size=5>\n         \n            <img style=\"height: 130px;border-radius: 5px;\" src=\"../../../assets/sample.jpg\">\n    \n         </ion-col>\n\n         <ion-col size=7>\n          <ion-row><label class=\"p_title\">Fit and Lift Gym Center</label></ion-row>\n          <ion-row> <label class=\"p_sub_title\">Marcus</label></ion-row>\n          <ion-row> <label class=\"p_location\"><ion-icon name=\"location-outline\"></ion-icon>New Daily, India</label></ion-row>\n          <ion-row> <label class=\"p_price\">$4000.00</label></ion-row>\n          <ion-row> <label class=\"p_time\"><ion-icon name=\"calendar-number-outline\"></ion-icon> Monday - Sunday</label></ion-row>\n          <ion-row><ion-icon class=\"rating_star\" *ngFor=\"let item of list;let i = index\" [name]=\"condition <= i? 'star-outline' :'star' \">\n          </ion-icon> <label class=\"rating_number\">2.2</label></ion-row>\n        </ion-col>\n\n      </ion-row>\n     \n    </ion-list>\n   \n  \n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_listing_listing_module_ts.js.map