(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_pasess_pasess_module_ts"],{

/***/ 9995:
/*!*******************************************************!*\
  !*** ./src/app/Pages/pasess/pasess-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PasessRoutingModule": () => (/* binding */ PasessRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _pasess_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pasess.component */ 2101);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _purchase_purchase_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./purchase/purchase.component */ 671);





const routes = [
    {
        path: "",
        component: _pasess_component__WEBPACK_IMPORTED_MODULE_0__.PasessComponent
    },
    {
        path: "purchae",
        component: _purchase_purchase_component__WEBPACK_IMPORTED_MODULE_1__.PurchaseComponent
    }
];
let PasessRoutingModule = class PasessRoutingModule {
};
PasessRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_4__.RouterModule]
    })
], PasessRoutingModule);



/***/ }),

/***/ 2101:
/*!**************************************************!*\
  !*** ./src/app/Pages/pasess/pasess.component.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PasessComponent": () => (/* binding */ PasessComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_pasess_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./pasess.component.html */ 4049);
/* harmony import */ var _pasess_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pasess.component.css */ 5583);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let PasessComponent = class PasessComponent {
    constructor(router) {
        this.router = router;
        this.show_container_one = true;
        this.icon_name = "caret-down-outline";
        this.show_container_two = false;
        this.icon_name_two = "caret-down-outline";
    }
    ngOnInit() {
    }
    toggle2() {
        if (this.show_container_two == false) {
            this.show_container_two = true;
            this.icon_name_two = "caret-down-outline";
        }
        else {
            this.show_container_two = false;
            this.icon_name_two = "caret-up-outline";
        }
    }
    toggle() {
        if (this.show_container_one) {
            this.show_container_one = false;
            this.icon_name = "caret-up-outline";
        }
        else {
            this.show_container_one = true;
            this.icon_name = "caret-down-outline";
        }
    }
    pucrchase() {
        this.router.navigate(['/pasess/purchae']);
    }
};
PasessComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
PasessComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-pasess',
        template: _raw_loader_pasess_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_pasess_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PasessComponent);



/***/ }),

/***/ 6245:
/*!***********************************************!*\
  !*** ./src/app/Pages/pasess/pasess.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PasessModule": () => (/* binding */ PasessModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _pasess_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pasess.component */ 2101);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _pasess_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pasess-routing.module */ 9995);
/* harmony import */ var _purchase_purchase_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./purchase/purchase.component */ 671);







let PasessModule = class PasessModule {
};
PasessModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_pasess_component__WEBPACK_IMPORTED_MODULE_0__.PasessComponent, _purchase_purchase_component__WEBPACK_IMPORTED_MODULE_2__.PurchaseComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _pasess_routing_module__WEBPACK_IMPORTED_MODULE_1__.PasessRoutingModule
        ]
    })
], PasessModule);



/***/ }),

/***/ 4433:
/*!************************************************!*\
  !*** ./src/app/Pages/pasess/passes.service.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PassesService": () => (/* binding */ PassesService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 205);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 5304);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);






let PassesService = class PassesService {
    constructor(httpClient) {
        this.httpClient = httpClient;
        this.getDayPassesList = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url + "DayPassesApi/getDayPassesList";
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({ 'Content-Type': 'application/json' })
        };
    }
    _getDayPassesList() {
        return this.httpClient.get(`${this.getDayPassesList}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.handleError));
        ;
    }
    handleError(error) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Error: ${error.error.message}`;
        }
        else {
            // server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.log(errorMessage);
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(errorMessage);
    }
};
PassesService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
PassesService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], PassesService);



/***/ }),

/***/ 671:
/*!*************************************************************!*\
  !*** ./src/app/Pages/pasess/purchase/purchase.component.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PurchaseComponent": () => (/* binding */ PurchaseComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_purchase_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./purchase.component.html */ 8346);
/* harmony import */ var _purchase_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./purchase.component.css */ 5132);
/* harmony import */ var _passes_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../passes.service */ 4433);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);







let PurchaseComponent = class PurchaseComponent {
    constructor(router, api, loadingController) {
        this.router = router;
        this.api = api;
        this.loadingController = loadingController;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.loading = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: 'Please wait...',
                duration: 2000
            });
            this.get_listing();
        });
    }
    get_listing() {
        this.loading.present();
        this.api._getDayPassesList().subscribe(data => {
            this.passesList = data.DayPassList;
            this.loading.dismiss();
        });
    }
    _checkOut() {
        this.router.navigate(['/checkout']);
    }
};
PurchaseComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _passes_service__WEBPACK_IMPORTED_MODULE_2__.PassesService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController }
];
PurchaseComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-purchase',
        template: _raw_loader_purchase_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_purchase_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PurchaseComponent);



/***/ }),

/***/ 5583:
/*!***************************************************!*\
  !*** ./src/app/Pages/pasess/pasess.component.css ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 130px; background:url('banner-bg.jpg');--background-repeat: no-repeat;\r\n    --background-size: cover;  background-size: cover;}\r\n  .header_overlay{background:#20978f69;height: 130px;}\r\n  .icon_conatiner{padding-top: 10px;}\r\n  ion-back-button{\r\n    --color: white;\r\n  }\r\n  .header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n  ._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n  ._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n  .right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n  .container_view{margin: 10px;}\r\n  .expandable_container{background: #fff;}\r\n  .exapandable_view{background-color: #75b1b9;padding: 10px;width: 100%;color:#fff;font-family:Poppins-Medium !important;}\r\n  .card_view{height: 100px;padding: 0px;margin: 0px;color: #fff;font-family:Poppins-Medium !important;}\r\n  .card_lable_number{font-size: 22px;font-weight: bolder;}\r\n  .card_lable_text{font-size: 15px;}\r\n  .black_layer{padding: 0px;margin: 10px;}\r\n  .card_lable_view{text-align: center;font-size: 9px;width: 100%;}\r\n  ._button{margin: 0px auto;\r\n    width: 90%;\r\n      margin-bottom: 10px;\r\n      --background-activated:#20978F;\r\n      display: block;\r\n      --background: #75b1b9;\r\n      font-size: 18px;\r\n      --border-radius: 5px;\r\n      height: 40px;}\r\n  .list_container{padding-bottom: 150px;}\r\n  .add_new_box{\r\n        margin-top: 50px;\r\n      }   \r\n       \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhc2Vzcy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGVBQWUsV0FBVyxDQUFDLGFBQWEsRUFBRSwrQkFBNkMsQ0FBQyw4QkFBOEI7SUFDbEgsd0JBQXdCLEdBQUcsc0JBQXNCLENBQUM7RUFDcEQsZ0JBQWdCLG9CQUFvQixDQUFDLGFBQWEsQ0FBQztFQUNuRCxnQkFBZ0IsaUJBQWlCLENBQUM7RUFDbEM7SUFDRSxjQUFjO0VBQ2hCO0VBQ0EsY0FBYyxXQUFXLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLHFDQUFxQyxDQUFDLGVBQWUsRUFBRTtFQUNoSCxZQUFZLFdBQVcsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDO0VBQ3hELFlBQVksV0FBVyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUM7RUFDMUUsWUFBWSxXQUFXLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztFQUN2RixnQkFBZ0IsWUFBWSxDQUFDO0VBQzdCLHNCQUFzQixnQkFBZ0IsQ0FBQztFQUN2QyxrQkFBa0IseUJBQXlCLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMscUNBQXFDLENBQUM7RUFDdkgsV0FBVyxhQUFhLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMscUNBQXFDLENBQUM7RUFDcEcsbUJBQW1CLGVBQWUsQ0FBQyxtQkFBbUIsQ0FBQztFQUN2RCxpQkFBaUIsZUFBZSxDQUFDO0VBQ2pDLGFBQWEsWUFBWSxDQUFDLFlBQVksQ0FBQztFQUN2QyxpQkFBaUIsa0JBQWtCLENBQUMsY0FBYyxDQUFDLFdBQVcsQ0FBQztFQUMvRCxTQUFTLGdCQUFnQjtJQUN2QixVQUFVO01BQ1IsbUJBQW1CO01BQ25CLDhCQUE4QjtNQUM5QixjQUFjO01BQ2QscUJBQXFCO01BQ3JCLGVBQWU7TUFDZixvQkFBb0I7TUFDcEIsWUFBWSxDQUFDO0VBQ2IsZ0JBQWdCLHFCQUFxQixDQUFDO0VBQ3RDO1FBQ0UsZ0JBQWdCO01BQ2xCIiwiZmlsZSI6InBhc2Vzcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlcl9iYW5uZXJ7d2lkdGg6IDEwMCU7aGVpZ2h0OiAxMzBweDsgYmFja2dyb3VuZDp1cmwoLi4vLi4vLi4vYXNzZXRzL2Jhbm5lci1iZy5qcGcpOy0tYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgIC0tYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7fVxyXG4gIC5oZWFkZXJfb3ZlcmxheXtiYWNrZ3JvdW5kOiMyMDk3OGY2OTtoZWlnaHQ6IDEzMHB4O31cclxuICAuaWNvbl9jb25hdGluZXJ7cGFkZGluZy10b3A6IDEwcHg7fVxyXG4gIGlvbi1iYWNrLWJ1dHRvbntcclxuICAgIC0tY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuICAuaGVhZGVyX3RpdGxle2NvbG9yOiAjZmZmO3RleHQtYWxpZ246IGNlbnRlcjt3aWR0aDogMTAwJTtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O2ZvbnQtc2l6ZTogMThweDs7fVxyXG4gIC5fbWVudV9pY29ue2NvbG9yOiAjZmZmO21hcmdpbjogMHB4IDBweDtmb250LXNpemU6IDMwcHg7fSAgIFxyXG4gIC5fY2FydF9pY29ue2NvbG9yOiAjZmZmO21hcmdpbjogOHB4IDBweDtmb250LXNpemU6IDI2cHg7bWFyZ2luLWxlZnQ6IDEwcHg7fVxyXG4gIC5yaWdodF9sb2dve3dpZHRoOiAzMHB4O2hlaWdodDogMzVweDtmbG9hdDogcmlnaHQ7bWFyZ2luLXRvcDogLTE5cHg7bWFyZ2luLXJpZ2h0OiAxNXB4O31cclxuICAuY29udGFpbmVyX3ZpZXd7bWFyZ2luOiAxMHB4O31cclxuICAuZXhwYW5kYWJsZV9jb250YWluZXJ7YmFja2dyb3VuZDogI2ZmZjt9XHJcbiAgLmV4YXBhbmRhYmxlX3ZpZXd7YmFja2dyb3VuZC1jb2xvcjogIzc1YjFiOTtwYWRkaW5nOiAxMHB4O3dpZHRoOiAxMDAlO2NvbG9yOiNmZmY7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbiAgLmNhcmRfdmlld3toZWlnaHQ6IDEwMHB4O3BhZGRpbmc6IDBweDttYXJnaW46IDBweDtjb2xvcjogI2ZmZjtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O31cclxuICAuY2FyZF9sYWJsZV9udW1iZXJ7Zm9udC1zaXplOiAyMnB4O2ZvbnQtd2VpZ2h0OiBib2xkZXI7fVxyXG4gIC5jYXJkX2xhYmxlX3RleHR7Zm9udC1zaXplOiAxNXB4O31cclxuICAuYmxhY2tfbGF5ZXJ7cGFkZGluZzogMHB4O21hcmdpbjogMTBweDt9XHJcbiAgLmNhcmRfbGFibGVfdmlld3t0ZXh0LWFsaWduOiBjZW50ZXI7Zm9udC1zaXplOiA5cHg7d2lkdGg6IDEwMCU7fVxyXG4gIC5fYnV0dG9ue21hcmdpbjogMHB4IGF1dG87XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiMyMDk3OEY7XHJcbiAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAtLWJhY2tncm91bmQ6ICM3NWIxYjk7XHJcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgIGhlaWdodDogNDBweDt9XHJcbiAgICAgIC5saXN0X2NvbnRhaW5lcntwYWRkaW5nLWJvdHRvbTogMTUwcHg7fVxyXG4gICAgICAuYWRkX25ld19ib3h7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogNTBweDtcclxuICAgICAgfSAgIFxyXG4gICAgICAgIl19 */");

/***/ }),

/***/ 5132:
/*!**************************************************************!*\
  !*** ./src/app/Pages/pasess/purchase/purchase.component.css ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 130px; background:url('gym_booking.jpg');--background-repeat: no-repeat;\r\n    --background-size: cover;  background-size: cover;}\r\n  .header_overlay{background:#20978f69;height: 130px;}\r\n  .icon_conatiner{padding-top: 10px;}\r\n  ion-back-button{\r\n    --color: white;\r\n  }\r\n  .header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n  ._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n  ._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n  .right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n  .container_form_box{margin: 5px;}\r\n  .section_one{border:1px solid #ddd;width: 100%; border-radius: 5px;padding: 10px;margin-top: 10px;}\r\n  .input_box{font-size: 15px; width: 100%; background-color: white;border: 2px solid #ddd;border-radius: 5px;font-family:Poppins-Light !important;display: inline-block;\r\n    padding-left: 10px;}\r\n  .input_lable{color: black;margin-top: 10px;font-size: 10px; font-family:Poppins-Medium !important;margin-bottom: 10px;}\r\n  ._button{margin: 0px auto;\r\n  width: 80%;\r\n    margin-top: 20px;\r\n    --background-activated:#20978F;\r\n    display: block;\r\n    --background: #75b1b9;\r\n    font-size: 18px;\r\n    --border-radius: 5px;\r\n    height: 40px;}\r\n  .card_view{height: 100px;padding: 0px;margin: 0px;color: #fff;font-family:Poppins-Medium !important;}\r\n  .card_lable_number{font-size: 22px;font-weight: bolder;}\r\n  .card_lable_text{font-size: 15px;}\r\n  .black_layer{padding: 0px;margin: 10px;}\r\n  .card_lable_view{text-align: center;font-size: 9px;width: 100%;}\r\n  .total_item{font-family:Poppins-Medium !important;margin: 10px;font-weight: bold;color: #545252;}\r\n  .list_container{margin: 5px;}\r\n  .list_row{margin: 10px 5px 10px 5px}\r\n  .img_icon{width: 50px;height: 50px;}\r\n  .p_title{width: 100%; font-size: 13px; color: rgb(85, 83, 83);font-weight: 600;font-family:Poppins-Medium !important;}\r\n  .p_sub_title{margin-left: 10px; width: 100%; font-size: 13px; color: rgb(112, 111, 111);font-family:Poppins-Medium !important;}\r\n  .p_price{margin-left: 10px;font-size: 13px;margin-top: 3px;font-family:Poppins-Medium !important;}\r\n  .save_{\r\n\r\n    --background-activated: #2fc3e4;\r\n    background: #2fc3e4;\r\n    height: 32px;\r\n    width: 32px;\r\n    /* font-size: 14px; */\r\n    border-radius: 4px;\r\n    color: #fff;\r\n      }\r\n  ._input{\r\n        height: 32px;\r\n    width: 32px;\r\n    margin-left: 1px;\r\n      }\r\n  ._remove\r\n      {\r\n        \r\n        --background-activated: #2fc3e4;\r\n        background: #f44336;\r\n        height: 32px;\r\n        width: 32px;\r\n        /* font-size: 14px; */\r\n        border-radius: 4px;\r\n        color: #fff;\r\n      }\r\n  .bottom_container {\r\n      position: fixed;\r\n      left: 0;\r\n      bottom: 10px;\r\n      right: 0;\r\n    }\r\n  .total_{width: 100%;border-top:1px solid #cccccc ;padding: 10px;}\r\n  .price_title_bottom{font-family:Poppins-Medium !important;}\r\n  .price_title_bottom_value  {font-family:Poppins-Medium !important;color: #47bfd8;}\r\n  ._counte{    font-family: Poppins-Medium !important;\r\n      padding: 13px;\r\n      /* margin: 5px; */\r\n      padding-top: 9px;\r\n      width: 19px;\r\n      position: relative;\r\n      top: 5px;}\r\n\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInB1cmNoYXNlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZUFBZSxXQUFXLENBQUMsYUFBYSxFQUFFLGlDQUFrRCxDQUFDLDhCQUE4QjtJQUN2SCx3QkFBd0IsR0FBRyxzQkFBc0IsQ0FBQztFQUNwRCxnQkFBZ0Isb0JBQW9CLENBQUMsYUFBYSxDQUFDO0VBQ25ELGdCQUFnQixpQkFBaUIsQ0FBQztFQUNsQztJQUNFLGNBQWM7RUFDaEI7RUFDQSxjQUFjLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMscUNBQXFDLENBQUMsZUFBZSxFQUFFO0VBQ2hILFlBQVksV0FBVyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUM7RUFDeEQsWUFBWSxXQUFXLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQztFQUMxRSxZQUFZLFdBQVcsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDO0VBQ3ZGLG9CQUFvQixXQUFXLENBQUM7RUFDaEMsYUFBYSxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsa0JBQWtCLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDO0VBQ2xHLFdBQVcsZUFBZSxFQUFFLFdBQVcsRUFBRSx1QkFBdUIsQ0FBQyxzQkFBc0IsQ0FBQyxrQkFBa0IsQ0FBQyxvQ0FBb0MsQ0FBQyxxQkFBcUI7SUFDbkssa0JBQWtCLENBQUM7RUFDdkIsYUFBYSxZQUFZLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxFQUFFLHFDQUFxQyxDQUFDLG1CQUFtQixDQUFDO0VBQ3RILFNBQVMsZ0JBQWdCO0VBQ3ZCLFVBQVU7SUFDUixnQkFBZ0I7SUFDaEIsOEJBQThCO0lBQzlCLGNBQWM7SUFDZCxxQkFBcUI7SUFDckIsZUFBZTtJQUNmLG9CQUFvQjtJQUNwQixZQUFZLENBQUM7RUFDYixXQUFXLGFBQWEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxxQ0FBcUMsQ0FBQztFQUNwRyxtQkFBbUIsZUFBZSxDQUFDLG1CQUFtQixDQUFDO0VBQ3ZELGlCQUFpQixlQUFlLENBQUM7RUFDakMsYUFBYSxZQUFZLENBQUMsWUFBWSxDQUFDO0VBQ3ZDLGlCQUFpQixrQkFBa0IsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDO0VBQy9ELFlBQVkscUNBQXFDLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQztFQUNoRyxnQkFBZ0IsV0FBVyxDQUFDO0VBQzVCLFVBQVUseUJBQXlCO0VBQ25DLFVBQVUsV0FBVyxDQUFDLFlBQVksQ0FBQztFQUNuQyxTQUFTLFdBQVcsRUFBRSxlQUFlLEVBQUUsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUMscUNBQXFDLENBQUM7RUFDckgsYUFBYSxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLHlCQUF5QixDQUFDLHFDQUFxQyxDQUFDO0VBQzlILFNBQVMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxxQ0FBcUMsQ0FBQztFQUNqRzs7SUFFQSwrQkFBK0I7SUFDL0IsbUJBQW1CO0lBQ25CLFlBQVk7SUFDWixXQUFXO0lBQ1gscUJBQXFCO0lBQ3JCLGtCQUFrQjtJQUNsQixXQUFXO01BQ1Q7RUFDQTtRQUNFLFlBQVk7SUFDaEIsV0FBVztJQUNYLGdCQUFnQjtNQUNkO0VBQ0E7OztRQUdFLCtCQUErQjtRQUMvQixtQkFBbUI7UUFDbkIsWUFBWTtRQUNaLFdBQVc7UUFDWCxxQkFBcUI7UUFDckIsa0JBQWtCO1FBQ2xCLFdBQVc7TUFDYjtFQUNGO01BQ0UsZUFBZTtNQUNmLE9BQU87TUFDUCxZQUFZO01BQ1osUUFBUTtJQUNWO0VBRUEsUUFBUSxXQUFXLENBQUMsNkJBQTZCLENBQUMsYUFBYSxDQUFDO0VBQ2hFLG9CQUFvQixxQ0FBcUMsQ0FBQztFQUMxRCw0QkFBNEIscUNBQXFDLENBQUMsY0FBYyxDQUFDO0VBQ2pGLGFBQWEsc0NBQXNDO01BQ2pELGFBQWE7TUFDYixpQkFBaUI7TUFDakIsZ0JBQWdCO01BQ2hCLFdBQVc7TUFDWCxrQkFBa0I7TUFDbEIsUUFBUSxDQUFDIiwiZmlsZSI6InB1cmNoYXNlLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyX2Jhbm5lcnt3aWR0aDogMTAwJTtoZWlnaHQ6IDEzMHB4OyBiYWNrZ3JvdW5kOnVybCguLi8uLi8uLi8uLi9hc3NldHMvZ3ltX2Jvb2tpbmcuanBnKTstLWJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAtLWJhY2tncm91bmQtc2l6ZTogY292ZXI7ICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO31cclxuICAuaGVhZGVyX292ZXJsYXl7YmFja2dyb3VuZDojMjA5NzhmNjk7aGVpZ2h0OiAxMzBweDt9XHJcbiAgLmljb25fY29uYXRpbmVye3BhZGRpbmctdG9wOiAxMHB4O31cclxuICBpb24tYmFjay1idXR0b257XHJcbiAgICAtLWNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiAgLmhlYWRlcl90aXRsZXtjb2xvcjogI2ZmZjt0ZXh0LWFsaWduOiBjZW50ZXI7d2lkdGg6IDEwMCU7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtmb250LXNpemU6IDE4cHg7O31cclxuICAuX21lbnVfaWNvbntjb2xvcjogI2ZmZjttYXJnaW46IDBweCAwcHg7Zm9udC1zaXplOiAzMHB4O30gICBcclxuICAuX2NhcnRfaWNvbntjb2xvcjogI2ZmZjttYXJnaW46IDhweCAwcHg7Zm9udC1zaXplOiAyNnB4O21hcmdpbi1sZWZ0OiAxMHB4O31cclxuICAucmlnaHRfbG9nb3t3aWR0aDogMzBweDtoZWlnaHQ6IDM1cHg7ZmxvYXQ6IHJpZ2h0O21hcmdpbi10b3A6IC0xOXB4O21hcmdpbi1yaWdodDogMTVweDt9XHJcbiAgLmNvbnRhaW5lcl9mb3JtX2JveHttYXJnaW46IDVweDt9XHJcbiAgLnNlY3Rpb25fb25le2JvcmRlcjoxcHggc29saWQgI2RkZDt3aWR0aDogMTAwJTsgYm9yZGVyLXJhZGl1czogNXB4O3BhZGRpbmc6IDEwcHg7bWFyZ2luLXRvcDogMTBweDt9XHJcbiAgLmlucHV0X2JveHtmb250LXNpemU6IDE1cHg7IHdpZHRoOiAxMDAlOyBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtib3JkZXI6IDJweCBzb2xpZCAjZGRkO2JvcmRlci1yYWRpdXM6IDVweDtmb250LWZhbWlseTpQb3BwaW5zLUxpZ2h0ICFpbXBvcnRhbnQ7ZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O31cclxuLmlucHV0X2xhYmxle2NvbG9yOiBibGFjazttYXJnaW4tdG9wOiAxMHB4O2ZvbnQtc2l6ZTogMTBweDsgZm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDttYXJnaW4tYm90dG9tOiAxMHB4O31cclxuLl9idXR0b257bWFyZ2luOiAwcHggYXV0bztcclxuICB3aWR0aDogODAlO1xyXG4gICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IzIwOTc4RjtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjNzViMWI5O1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7fVxyXG4gICAgLmNhcmRfdmlld3toZWlnaHQ6IDEwMHB4O3BhZGRpbmc6IDBweDttYXJnaW46IDBweDtjb2xvcjogI2ZmZjtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O31cclxuICAgIC5jYXJkX2xhYmxlX251bWJlcntmb250LXNpemU6IDIycHg7Zm9udC13ZWlnaHQ6IGJvbGRlcjt9XHJcbiAgICAuY2FyZF9sYWJsZV90ZXh0e2ZvbnQtc2l6ZTogMTVweDt9XHJcbiAgICAuYmxhY2tfbGF5ZXJ7cGFkZGluZzogMHB4O21hcmdpbjogMTBweDt9XHJcbiAgICAuY2FyZF9sYWJsZV92aWV3e3RleHQtYWxpZ246IGNlbnRlcjtmb250LXNpemU6IDlweDt3aWR0aDogMTAwJTt9XHJcbiAgICAudG90YWxfaXRlbXtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O21hcmdpbjogMTBweDtmb250LXdlaWdodDogYm9sZDtjb2xvcjogIzU0NTI1Mjt9XHJcbiAgICAubGlzdF9jb250YWluZXJ7bWFyZ2luOiA1cHg7fVxyXG4gICAgLmxpc3Rfcm93e21hcmdpbjogMTBweCA1cHggMTBweCA1cHh9XHJcbiAgICAuaW1nX2ljb257d2lkdGg6IDUwcHg7aGVpZ2h0OiA1MHB4O31cclxuICAgIC5wX3RpdGxle3dpZHRoOiAxMDAlOyBmb250LXNpemU6IDEzcHg7IGNvbG9yOiByZ2IoODUsIDgzLCA4Myk7Zm9udC13ZWlnaHQ6IDYwMDtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O31cclxuICAgIC5wX3N1Yl90aXRsZXttYXJnaW4tbGVmdDogMTBweDsgd2lkdGg6IDEwMCU7IGZvbnQtc2l6ZTogMTNweDsgY29sb3I6IHJnYigxMTIsIDExMSwgMTExKTtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O31cclxuICAgIC5wX3ByaWNle21hcmdpbi1sZWZ0OiAxMHB4O2ZvbnQtc2l6ZTogMTNweDttYXJnaW4tdG9wOiAzcHg7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbiAgICAuc2F2ZV97XHJcblxyXG4gICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogIzJmYzNlNDtcclxuICAgIGJhY2tncm91bmQ6ICMyZmMzZTQ7XHJcbiAgICBoZWlnaHQ6IDMycHg7XHJcbiAgICB3aWR0aDogMzJweDtcclxuICAgIC8qIGZvbnQtc2l6ZTogMTRweDsgKi9cclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICB9XHJcbiAgICAgIC5faW5wdXR7XHJcbiAgICAgICAgaGVpZ2h0OiAzMnB4O1xyXG4gICAgd2lkdGg6IDMycHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMXB4O1xyXG4gICAgICB9XHJcbiAgICAgIC5fcmVtb3ZlXHJcbiAgICAgIHtcclxuICAgICAgICBcclxuICAgICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMmZjM2U0O1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNmNDQzMzY7XHJcbiAgICAgICAgaGVpZ2h0OiAzMnB4O1xyXG4gICAgICAgIHdpZHRoOiAzMnB4O1xyXG4gICAgICAgIC8qIGZvbnQtc2l6ZTogMTRweDsgKi9cclxuICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgIH1cclxuICAgIC5ib3R0b21fY29udGFpbmVyIHtcclxuICAgICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgICBsZWZ0OiAwO1xyXG4gICAgICBib3R0b206IDEwcHg7XHJcbiAgICAgIHJpZ2h0OiAwO1xyXG4gICAgfVxyXG5cclxuICAgIC50b3RhbF97d2lkdGg6IDEwMCU7Ym9yZGVyLXRvcDoxcHggc29saWQgI2NjY2NjYyA7cGFkZGluZzogMTBweDt9XHJcbiAgICAucHJpY2VfdGl0bGVfYm90dG9te2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7fVxyXG4gICAgLnByaWNlX3RpdGxlX2JvdHRvbV92YWx1ZSAge2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7Y29sb3I6ICM0N2JmZDg7fSBcclxuICAgIC5fY291bnRleyAgICBmb250LWZhbWlseTogUG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtcclxuICAgICAgcGFkZGluZzogMTNweDtcclxuICAgICAgLyogbWFyZ2luOiA1cHg7ICovXHJcbiAgICAgIHBhZGRpbmctdG9wOiA5cHg7XHJcbiAgICAgIHdpZHRoOiAxOXB4O1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIHRvcDogNXB4O31cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ 4049:
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/pasess/pasess.component.html ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">Day Pasess</ion-label></ion-row>\n         </div>\n   \n      </div>\n    </div>\n    <div class=\"container_view\">\n       <div class=\"exapandable_view\"  (click)=\"toggle()\">\n           <ion-row>\n               <ion-col size=\"9\">Available Day Pasess </ion-col>\n               <ion-col size=\"1\" offset=\"2\"><ion-icon name=\"{{icon_name}}\"></ion-icon></ion-col>\n           </ion-row>\n       </div>\n    \n        <ng-container *ngIf=\"show_container_one; \">\n            <div  class=\"expandable_container\">\n                <ion-grid>\n      \n                    <ion-row>\n                     <ion-col>\n                       <ion-card class=\"card_view\" style=\"background: #c3c3c3;\">\n                           <ion-card-content class=\"black_layer\">\n                               <ion-row style=\"padding: 0px!important;\">\n                                   <ion-col size=\"4\" ><label class=\"card_lable_number\" >01</label></ion-col>\n                                   <ion-col size=\"8\" >  <label class=\"card_lable_text\" >Fairmont the plam</label></ion-col>\n                               </ion-row>\n                               <ion-row> <label class=\"card_lable_view\" >Tap to redeem</label></ion-row>\n                           </ion-card-content>\n                       </ion-card>\n                     </ion-col>\n                     <ion-col>  \n                       <ion-card class=\"card_view\" style=\"background: #7fd0ed;\">\n                        <ion-card-content class=\"black_layer\">\n                            <ion-row>\n                                <ion-col size=\"4\"><label class=\"card_lable_number\" >02</label></ion-col>\n                                <ion-col size=\"8\">  <label class=\"card_lable_text\" >Riva the plam</label></ion-col>\n                            </ion-row>\n                            <ion-row> <label class=\"card_lable_view\" >Tap to redeem</label></ion-row>\n\n                        </ion-card-content>\n                     </ion-card></ion-col>\n                    </ion-row>\n                    <ion-row>\n                        <ion-col>\n                          <ion-card class=\"card_view\"  style=\"background: #dd9ca2;\">\n                              <ion-card-content class=\"black_layer\">\n                                <ion-row>\n                                    <ion-col size=\"4\"><label class=\"card_lable_number\" >03</label></ion-col>\n                                    <ion-col size=\"8\">  <label class=\"card_lable_text\" >Riva New Vase</label></ion-col>\n                                </ion-row>\n                                <ion-row> <label class=\"card_lable_view\" >Tap to redeem</label></ion-row>\n                              </ion-card-content>\n                          </ion-card>\n                        </ion-col>\n                        <ion-col>  \n                          <ion-card class=\"card_view\"  style=\"background: #7d7d7d;\">\n                            <ion-card-content class=\"black_layer\">\n                                <ion-row>\n                                    <ion-col size=\"4\"><label class=\"card_lable_number\" >04</label></ion-col>\n                                    <ion-col size=\"8\">  <label class=\"card_lable_text\" >Movenpick JLT</label></ion-col>\n                                </ion-row>\n                               <ion-row> <label class=\"card_lable_view\" >Tap to redeem</label></ion-row>\n\n                            </ion-card-content>\n                        </ion-card></ion-col>\n                       </ion-row>\n                </ion-grid>\n            </div>     \n        </ng-container>\n\n        <div class=\"exapandable_view\"  (click)=\"toggle2()\">\n            <ion-row>\n                <ion-col size=\"9\">Purchased Day Pasess </ion-col>\n                <ion-col size=\"1\" offset=\"2\"><ion-icon name=\"{{icon_name_two}}\"></ion-icon></ion-col>\n            </ion-row>\n        </div>\n     \n         <ng-container *ngIf=\"show_container_two; \">\n             <div  class=\"expandable_container\">\n\n                <div class=\"add_new_box\">\n                    <ion-button class=\"_button\"  (click)=\"pucrchase()\"  >Purchase Passess</ion-button>\n                </div>\n                \n             </div>     \n         </ng-container>\n          \n           \n    </div>\n  \n  </ion-content>");

/***/ }),

/***/ 8346:
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/pasess/purchase/purchase.component.html ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">Purchase Passes</ion-label></ion-row>\n         </div>\n\n    \n\n      \n          \n   \n      </div>\n    </div>\n\n    <div class=\"container_form_box\">\n        <section class=\"section_one\">\n           \n          <div  class=\"expandable_container\">\n            <ion-item>\n          \n               <ion-col>\n                 <label class=\"p_title\">First Name</label><br>\n                 <label class=\"p_value\">Maria</label>\n               </ion-col>\n               <ion-col>\n                 <label class=\"p_title\">Last Name</label><br>\n                 <label class=\"p_value\">Ustinaska</label>\n               </ion-col>\n             </ion-item>\n            \n             \n\n             <ion-item >\n               <ion-col>\n                 <label class=\"p_title\">Membership</label><br>\n                 <label class=\"p_value\">Dimand</label>\n               </ion-col>\n               <ion-col >\n                 <label class=\"p_title\">Property</label><br>\n                 <label class=\"p_value\">Fiarmount The Plam</label>\n               </ion-col>\n             </ion-item>\n\n             <ion-item lines=\"none\" >\n              <ion-col>\n                <label class=\"p_title\">Term</label><br>\n                <label class=\"p_value\"></label>\n              </ion-col>\n              <ion-col >\n                <label class=\"p_title\">Visa Type</label><br>\n                <label class=\"p_value\"></label>\n              </ion-col>\n            </ion-item>\n             \n           </div>     \n\n\n            \n\n \n\n        </section>\n\n        <section class=\"section_one\">\n           \n          <ion-list class=\"list_container\">\n            <ion-row class=\"list_row\"  *ngFor=\"let item of passesList \">\n            \n               <ion-col size=4>\n               \n                  <img style=\" width: 100px; height: 80px;border-radius: 5px;\" src=\"../../../assets/sample.jpg\">\n          \n               </ion-col>\n      \n               <ion-col size=7 >\n                <ion-row><label class=\"p_title\">{{item.Daypasses}}</label></ion-row>\n                <ion-row> <label class=\"p_price\">${{item.Price}}</label></ion-row>\n                <ion-row>\n                  <ion-col size=2><button class=\"save_\">+</button></ion-col>\n                  <ion-col size=2><label class=\"_counte\">1</label></ion-col>\n                  <ion-col size=2 ><button class=\"_remove\" color=\"danger\" >-</button></ion-col>\n              </ion-row>\n               \n              </ion-col>\n      \n            </ion-row>\n           \n          </ion-list>\n\n\n          \n\n\n      \n\n      </section>\n      <ion-button class=\"_button\"  (click)=\"_checkOut()\"  >Purchase Passess</ion-button>\n    </div>\n  \n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_pasess_pasess_module_ts.js.map