(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_profile_profile_module_ts"],{

/***/ 1779:
/*!****************************************************************!*\
  !*** ./node_modules/@capacitor/camera/dist/esm/definitions.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CameraSource": () => (/* binding */ CameraSource),
/* harmony export */   "CameraDirection": () => (/* binding */ CameraDirection),
/* harmony export */   "CameraResultType": () => (/* binding */ CameraResultType)
/* harmony export */ });
var CameraSource;
(function (CameraSource) {
    CameraSource["Prompt"] = "PROMPT";
    CameraSource["Camera"] = "CAMERA";
    CameraSource["Photos"] = "PHOTOS";
})(CameraSource || (CameraSource = {}));
var CameraDirection;
(function (CameraDirection) {
    CameraDirection["Rear"] = "REAR";
    CameraDirection["Front"] = "FRONT";
})(CameraDirection || (CameraDirection = {}));
var CameraResultType;
(function (CameraResultType) {
    CameraResultType["Uri"] = "uri";
    CameraResultType["Base64"] = "base64";
    CameraResultType["DataUrl"] = "dataUrl";
})(CameraResultType || (CameraResultType = {}));
//# sourceMappingURL=definitions.js.map

/***/ }),

/***/ 7673:
/*!**********************************************************!*\
  !*** ./node_modules/@capacitor/camera/dist/esm/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CameraDirection": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.CameraDirection),
/* harmony export */   "CameraResultType": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.CameraResultType),
/* harmony export */   "CameraSource": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.CameraSource),
/* harmony export */   "Camera": () => (/* binding */ Camera)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 8384);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 1779);

const Camera = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Camera', {
    web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_camera_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 4028)).then(m => new m.CameraWeb()),
});


//# sourceMappingURL=index.js.map

/***/ }),

/***/ 8384:
/*!****************************************************!*\
  !*** ./node_modules/@capacitor/core/dist/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Capacitor": () => (/* binding */ Capacitor),
/* harmony export */   "CapacitorException": () => (/* binding */ CapacitorException),
/* harmony export */   "CapacitorPlatforms": () => (/* binding */ CapacitorPlatforms),
/* harmony export */   "ExceptionCode": () => (/* binding */ ExceptionCode),
/* harmony export */   "Plugins": () => (/* binding */ Plugins),
/* harmony export */   "WebPlugin": () => (/* binding */ WebPlugin),
/* harmony export */   "WebView": () => (/* binding */ WebView),
/* harmony export */   "addPlatform": () => (/* binding */ addPlatform),
/* harmony export */   "registerPlugin": () => (/* binding */ registerPlugin),
/* harmony export */   "registerWebPlugin": () => (/* binding */ registerWebPlugin),
/* harmony export */   "setPlatform": () => (/* binding */ setPlatform)
/* harmony export */ });
/*! Capacitor: https://capacitorjs.com/ - MIT License */
const createCapacitorPlatforms = (win) => {
    const defaultPlatformMap = new Map();
    defaultPlatformMap.set('web', { name: 'web' });
    const capPlatforms = win.CapacitorPlatforms || {
        currentPlatform: { name: 'web' },
        platforms: defaultPlatformMap,
    };
    const addPlatform = (name, platform) => {
        capPlatforms.platforms.set(name, platform);
    };
    const setPlatform = (name) => {
        if (capPlatforms.platforms.has(name)) {
            capPlatforms.currentPlatform = capPlatforms.platforms.get(name);
        }
    };
    capPlatforms.addPlatform = addPlatform;
    capPlatforms.setPlatform = setPlatform;
    return capPlatforms;
};
const initPlatforms = (win) => (win.CapacitorPlatforms = createCapacitorPlatforms(win));
const CapacitorPlatforms = /*#__PURE__*/ initPlatforms((typeof globalThis !== 'undefined'
    ? globalThis
    : typeof self !== 'undefined'
        ? self
        : typeof window !== 'undefined'
            ? window
            : typeof global !== 'undefined'
                ? global
                : {}));
const addPlatform = CapacitorPlatforms.addPlatform;
const setPlatform = CapacitorPlatforms.setPlatform;

const legacyRegisterWebPlugin = (cap, webPlugin) => {
    var _a;
    const config = webPlugin.config;
    const Plugins = cap.Plugins;
    if (!config || !config.name) {
        // TODO: add link to upgrade guide
        throw new Error(`Capacitor WebPlugin is using the deprecated "registerWebPlugin()" function, but without the config. Please use "registerPlugin()" instead to register this web plugin."`);
    }
    // TODO: add link to upgrade guide
    console.warn(`Capacitor plugin "${config.name}" is using the deprecated "registerWebPlugin()" function`);
    if (!Plugins[config.name] || ((_a = config === null || config === void 0 ? void 0 : config.platforms) === null || _a === void 0 ? void 0 : _a.includes(cap.getPlatform()))) {
        // Add the web plugin into the plugins registry if there already isn't
        // an existing one. If it doesn't already exist, that means
        // there's no existing native implementation for it.
        // - OR -
        // If we already have a plugin registered (meaning it was defined in the native layer),
        // then we should only overwrite it if the corresponding web plugin activates on
        // a certain platform. For example: Geolocation uses the WebPlugin on Android but not iOS
        Plugins[config.name] = webPlugin;
    }
};

var ExceptionCode;
(function (ExceptionCode) {
    /**
     * API is not implemented.
     *
     * This usually means the API can't be used because it is not implemented for
     * the current platform.
     */
    ExceptionCode["Unimplemented"] = "UNIMPLEMENTED";
    /**
     * API is not available.
     *
     * This means the API can't be used right now because:
     *   - it is currently missing a prerequisite, such as network connectivity
     *   - it requires a particular platform or browser version
     */
    ExceptionCode["Unavailable"] = "UNAVAILABLE";
})(ExceptionCode || (ExceptionCode = {}));
class CapacitorException extends Error {
    constructor(message, code) {
        super(message);
        this.message = message;
        this.code = code;
    }
}
const getPlatformId = (win) => {
    var _a, _b;
    if (win === null || win === void 0 ? void 0 : win.androidBridge) {
        return 'android';
    }
    else if ((_b = (_a = win === null || win === void 0 ? void 0 : win.webkit) === null || _a === void 0 ? void 0 : _a.messageHandlers) === null || _b === void 0 ? void 0 : _b.bridge) {
        return 'ios';
    }
    else {
        return 'web';
    }
};

const createCapacitor = (win) => {
    var _a, _b, _c, _d, _e;
    const cap = win.Capacitor || {};
    const Plugins = (cap.Plugins = cap.Plugins || {});
    const capPlatforms = win.CapacitorPlatforms;
    const defaultGetPlatform = () => getPlatformId(win);
    const getPlatform = ((_a = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _a === void 0 ? void 0 : _a.getPlatform) || defaultGetPlatform;
    const defaultIsNativePlatform = () => getPlatformId(win) !== 'web';
    const isNativePlatform = ((_b = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _b === void 0 ? void 0 : _b.isNativePlatform) || defaultIsNativePlatform;
    const defaultIsPluginAvailable = (pluginName) => {
        const plugin = registeredPlugins.get(pluginName);
        if (plugin === null || plugin === void 0 ? void 0 : plugin.platforms.has(getPlatform())) {
            // JS implementation available for the current platform.
            return true;
        }
        if (getPluginHeader(pluginName)) {
            // Native implementation available.
            return true;
        }
        return false;
    };
    const isPluginAvailable = ((_c = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _c === void 0 ? void 0 : _c.isPluginAvailable) ||
        defaultIsPluginAvailable;
    const defaultGetPluginHeader = (pluginName) => { var _a; return (_a = cap.PluginHeaders) === null || _a === void 0 ? void 0 : _a.find(h => h.name === pluginName); };
    const getPluginHeader = ((_d = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _d === void 0 ? void 0 : _d.getPluginHeader) || defaultGetPluginHeader;
    const handleError = (err) => win.console.error(err);
    const pluginMethodNoop = (_target, prop, pluginName) => {
        return Promise.reject(`${pluginName} does not have an implementation of "${prop}".`);
    };
    const registeredPlugins = new Map();
    const defaultRegisterPlugin = (pluginName, jsImplementations = {}) => {
        const registeredPlugin = registeredPlugins.get(pluginName);
        if (registeredPlugin) {
            console.warn(`Capacitor plugin "${pluginName}" already registered. Cannot register plugins twice.`);
            return registeredPlugin.proxy;
        }
        const platform = getPlatform();
        const pluginHeader = getPluginHeader(pluginName);
        let jsImplementation;
        const loadPluginImplementation = async () => {
            if (!jsImplementation && platform in jsImplementations) {
                jsImplementation =
                    typeof jsImplementations[platform] === 'function'
                        ? (jsImplementation = await jsImplementations[platform]())
                        : (jsImplementation = jsImplementations[platform]);
            }
            return jsImplementation;
        };
        const createPluginMethod = (impl, prop) => {
            var _a, _b;
            if (pluginHeader) {
                const methodHeader = pluginHeader === null || pluginHeader === void 0 ? void 0 : pluginHeader.methods.find(m => prop === m.name);
                if (methodHeader) {
                    if (methodHeader.rtype === 'promise') {
                        return (options) => cap.nativePromise(pluginName, prop.toString(), options);
                    }
                    else {
                        return (options, callback) => cap.nativeCallback(pluginName, prop.toString(), options, callback);
                    }
                }
                else if (impl) {
                    return (_a = impl[prop]) === null || _a === void 0 ? void 0 : _a.bind(impl);
                }
            }
            else if (impl) {
                return (_b = impl[prop]) === null || _b === void 0 ? void 0 : _b.bind(impl);
            }
            else {
                throw new CapacitorException(`"${pluginName}" plugin is not implemented on ${platform}`, ExceptionCode.Unimplemented);
            }
        };
        const createPluginMethodWrapper = (prop) => {
            let remove;
            const wrapper = (...args) => {
                const p = loadPluginImplementation().then(impl => {
                    const fn = createPluginMethod(impl, prop);
                    if (fn) {
                        const p = fn(...args);
                        remove = p === null || p === void 0 ? void 0 : p.remove;
                        return p;
                    }
                    else {
                        throw new CapacitorException(`"${pluginName}.${prop}()" is not implemented on ${platform}`, ExceptionCode.Unimplemented);
                    }
                });
                if (prop === 'addListener') {
                    p.remove = async () => remove();
                }
                return p;
            };
            // Some flair ✨
            wrapper.toString = () => `${prop.toString()}() { [capacitor code] }`;
            Object.defineProperty(wrapper, 'name', {
                value: prop,
                writable: false,
                configurable: false,
            });
            return wrapper;
        };
        const addListener = createPluginMethodWrapper('addListener');
        const removeListener = createPluginMethodWrapper('removeListener');
        const addListenerNative = (eventName, callback) => {
            const call = addListener({ eventName }, callback);
            const remove = async () => {
                const callbackId = await call;
                removeListener({
                    eventName,
                    callbackId,
                }, callback);
            };
            const p = new Promise(resolve => call.then(() => resolve({ remove })));
            p.remove = async () => {
                console.warn(`Using addListener() without 'await' is deprecated.`);
                await remove();
            };
            return p;
        };
        const proxy = new Proxy({}, {
            get(_, prop) {
                switch (prop) {
                    // https://github.com/facebook/react/issues/20030
                    case '$$typeof':
                        return undefined;
                    case 'addListener':
                        return pluginHeader ? addListenerNative : addListener;
                    case 'removeListener':
                        return removeListener;
                    default:
                        return createPluginMethodWrapper(prop);
                }
            },
        });
        Plugins[pluginName] = proxy;
        registeredPlugins.set(pluginName, {
            name: pluginName,
            proxy,
            platforms: new Set([
                ...Object.keys(jsImplementations),
                ...(pluginHeader ? [platform] : []),
            ]),
        });
        return proxy;
    };
    const registerPlugin = ((_e = capPlatforms === null || capPlatforms === void 0 ? void 0 : capPlatforms.currentPlatform) === null || _e === void 0 ? void 0 : _e.registerPlugin) || defaultRegisterPlugin;
    // Add in convertFileSrc for web, it will already be available in native context
    if (!cap.convertFileSrc) {
        cap.convertFileSrc = filePath => filePath;
    }
    cap.getPlatform = getPlatform;
    cap.handleError = handleError;
    cap.isNativePlatform = isNativePlatform;
    cap.isPluginAvailable = isPluginAvailable;
    cap.pluginMethodNoop = pluginMethodNoop;
    cap.registerPlugin = registerPlugin;
    cap.Exception = CapacitorException;
    cap.DEBUG = !!cap.DEBUG;
    cap.isLoggingEnabled = !!cap.isLoggingEnabled;
    // Deprecated props
    cap.platform = cap.getPlatform();
    cap.isNative = cap.isNativePlatform();
    return cap;
};
const initCapacitorGlobal = (win) => (win.Capacitor = createCapacitor(win));

const Capacitor = /*#__PURE__*/ initCapacitorGlobal(typeof globalThis !== 'undefined'
    ? globalThis
    : typeof self !== 'undefined'
        ? self
        : typeof window !== 'undefined'
            ? window
            : typeof global !== 'undefined'
                ? global
                : {});
const registerPlugin = Capacitor.registerPlugin;
/**
 * @deprecated Provided for backwards compatibility for Capacitor v2 plugins.
 * Capacitor v3 plugins should import the plugin directly. This "Plugins"
 * export is deprecated in v3, and will be removed in v4.
 */
const Plugins = Capacitor.Plugins;
/**
 * Provided for backwards compatibility. Use the registerPlugin() API
 * instead, and provide the web plugin as the "web" implmenetation.
 * For example
 *
 * export const Example = registerPlugin('Example', {
 *   web: () => import('./web').then(m => new m.Example())
 * })
 *
 * @deprecated Deprecated in v3, will be removed from v4.
 */
const registerWebPlugin = (plugin) => legacyRegisterWebPlugin(Capacitor, plugin);

/**
 * Base class web plugins should extend.
 */
class WebPlugin {
    constructor(config) {
        this.listeners = {};
        this.windowListeners = {};
        if (config) {
            // TODO: add link to upgrade guide
            console.warn(`Capacitor WebPlugin "${config.name}" config object was deprecated in v3 and will be removed in v4.`);
            this.config = config;
        }
    }
    addListener(eventName, listenerFunc) {
        const listeners = this.listeners[eventName];
        if (!listeners) {
            this.listeners[eventName] = [];
        }
        this.listeners[eventName].push(listenerFunc);
        // If we haven't added a window listener for this event and it requires one,
        // go ahead and add it
        const windowListener = this.windowListeners[eventName];
        if (windowListener && !windowListener.registered) {
            this.addWindowListener(windowListener);
        }
        const remove = async () => this.removeListener(eventName, listenerFunc);
        const p = Promise.resolve({ remove });
        Object.defineProperty(p, 'remove', {
            value: async () => {
                console.warn(`Using addListener() without 'await' is deprecated.`);
                await remove();
            },
        });
        return p;
    }
    async removeAllListeners() {
        this.listeners = {};
        for (const listener in this.windowListeners) {
            this.removeWindowListener(this.windowListeners[listener]);
        }
        this.windowListeners = {};
    }
    notifyListeners(eventName, data) {
        const listeners = this.listeners[eventName];
        if (listeners) {
            listeners.forEach(listener => listener(data));
        }
    }
    hasListeners(eventName) {
        return !!this.listeners[eventName].length;
    }
    registerWindowListener(windowEventName, pluginEventName) {
        this.windowListeners[pluginEventName] = {
            registered: false,
            windowEventName,
            pluginEventName,
            handler: event => {
                this.notifyListeners(pluginEventName, event);
            },
        };
    }
    unimplemented(msg = 'not implemented') {
        return new Capacitor.Exception(msg, ExceptionCode.Unimplemented);
    }
    unavailable(msg = 'not available') {
        return new Capacitor.Exception(msg, ExceptionCode.Unavailable);
    }
    async removeListener(eventName, listenerFunc) {
        const listeners = this.listeners[eventName];
        if (!listeners) {
            return;
        }
        const index = listeners.indexOf(listenerFunc);
        this.listeners[eventName].splice(index, 1);
        // If there are no more listeners for this type of event,
        // remove the window listener
        if (!this.listeners[eventName].length) {
            this.removeWindowListener(this.windowListeners[eventName]);
        }
    }
    addWindowListener(handle) {
        window.addEventListener(handle.windowEventName, handle.handler);
        handle.registered = true;
    }
    removeWindowListener(handle) {
        if (!handle) {
            return;
        }
        window.removeEventListener(handle.windowEventName, handle.handler);
        handle.registered = false;
    }
}

const WebView = /*#__PURE__*/ registerPlugin('WebView');


//# sourceMappingURL=index.js.map


/***/ }),

/***/ 237:
/*!*********************************************************!*\
  !*** ./src/app/Pages/profile/profile-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageRoutingModule": () => (/* binding */ ProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _profile_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.component */ 3185);




const routes = [
    {
        path: '',
        component: _profile_component__WEBPACK_IMPORTED_MODULE_0__.ProfileComponent,
    }
];
let ProfilePageRoutingModule = class ProfilePageRoutingModule {
};
ProfilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], ProfilePageRoutingModule);



/***/ }),

/***/ 3185:
/*!****************************************************!*\
  !*** ./src/app/Pages/profile/profile.component.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileComponent": () => (/* binding */ ProfileComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_profile_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./profile.component.html */ 2506);
/* harmony import */ var _profile_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.component.css */ 2209);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/camera */ 7673);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/storage-angular */ 1628);







let ProfileComponent = class ProfileComponent {
    constructor(menu, animationCtrl, storage) {
        this.menu = menu;
        this.animationCtrl = animationCtrl;
        this.storage = storage;
        this.icon_name = "caret-down-outline";
        this.show_container_two = false;
        this.show_container_one = true;
        this.show_container_three = false;
        this.show_container_four = false;
        this.icon_name_two = "caret-down-outline";
        this.icon_name_three = "caret-down-outline";
        this.icon_name_four = "caret-down-outline";
        this.img = "../../../assets/no_profile.jpg";
        this.takePicture = () => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_2__.Camera.getPhoto({
                quality: 40,
                allowEditing: true,
                width: 100,
                height: 100,
                resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_2__.CameraResultType.Uri
            });
            // image.webPath will contain a path that can be set as an image src.
            // You can access the original file using image.path, which can be
            // passed to the Filesystem API to read the raw data of the image,
            // if desired (or pass resultType: CameraResultType.Base64 to getPhoto)
            var imageUrl = image.webPath;
            alert(imageUrl);
            // Can be set to the src of an image now
            this.img = imageUrl;
        });
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.menu.enable(true);
            yield this.storage.create();
            this.storage.get("userdata").then(data => {
                console.log(data);
                this.pname = data.Name;
                this.pqr = "data:image/jpeg;base64," + data.qrCodeString;
                this.pexpdate = data.MembershipEndDate;
                this.pemail = data.MailId;
                this.ptype = data.membershipCategory;
                this.pmemberstart = data.MembershipStartDate;
                this.pmemberend = data.MembershipEndDate;
            });
        });
    }
    addNewToGallery() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            // Take a photo
        });
    }
    opncamera() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const capturedPhoto = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_2__.Camera.getPhoto({
                resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_2__.CameraResultType.Uri,
                source: _capacitor_camera__WEBPACK_IMPORTED_MODULE_2__.CameraSource.Camera,
                quality: 100
            });
            this.img = capturedPhoto.webPath;
        });
    }
    ngAfterViewInit() {
        console.log("afterinit");
        setTimeout(() => {
            //  this.startLoad();
        }, 1000);
    }
    toggle4() {
        if (this.show_container_four == false) {
            this.show_container_four = true;
            this.icon_name_four = "caret-down-outline";
        }
        else {
            this.show_container_four = false;
            this.icon_name_four = "caret-up-outline";
        }
    }
    toggle3() {
        if (this.show_container_three == false) {
            this.show_container_three = true;
            this.icon_name_three = "caret-down-outline";
        }
        else {
            this.show_container_three = false;
            this.icon_name_three = "caret-up-outline";
        }
    }
    toggle2() {
        if (this.show_container_two == false) {
            this.show_container_two = true;
            this.icon_name_two = "caret-down-outline";
        }
        else {
            this.show_container_two = false;
            this.icon_name_two = "caret-up-outline";
        }
    }
    toggle() {
        if (this.show_container_one) {
            this.show_container_one = false;
            this.icon_name = "caret-up-outline";
        }
        else {
            this.show_container_one = true;
            this.icon_name = "caret-down-outline";
        }
    }
    front_side() {
        $(".v_card").show();
        $(".front_side").hide();
    }
    back_side() {
        $(".v_card").hide();
        // $(".front_side").toggleClass('flipped')
        $(".front_side").show();
    }
    startLoad() {
        const loadingAnimation = this.animationCtrl.create('loading-animation')
            .addElement(this.loadingIcon.nativeElement)
            .duration(1500)
            .iterations(3)
            .fromTo('transform', 'rotate(0deg)', 'rotate(360deg)');
        // Don't forget to start the animation!
        loadingAnimation.play();
    }
    ionViewWillEnter() {
        setTimeout(() => {
            this.data = {
                'heading': 'Normal text',
                'para1': 'Lorem ipsum dolor sit amet, consectetur',
                'para2': 'adipiscing elit.'
            };
        }, 5000);
    }
    fileChange(event) {
        if (event.target.files && event.target.files[0]) {
            let reader = new FileReader();
            reader.onload = (event) => {
                this.img = event.target.result;
            };
            reader.readAsDataURL(event.target.files[0]); // to trigger onload
        }
        let fileList = event.target.files;
        let file = fileList[0];
        console.log(file);
    }
};
ProfileComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.AnimationController },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_5__.Storage }
];
ProfileComponent.propDecorators = {
    loadingIcon: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild, args: ['loadingIcon', { read: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ElementRef },] }]
};
ProfileComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-profile',
        template: _raw_loader_profile_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_profile_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ProfileComponent);



/***/ }),

/***/ 824:
/*!*************************************************!*\
  !*** ./src/app/Pages/profile/profile.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageModule": () => (/* binding */ ProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _profile_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.component */ 3185);
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile-routing.module */ 237);







let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _profile_routing_module__WEBPACK_IMPORTED_MODULE_1__.ProfilePageRoutingModule,
        ],
        providers: [],
        declarations: [_profile_component__WEBPACK_IMPORTED_MODULE_0__.ProfileComponent]
    })
], ProfilePageModule);



/***/ }),

/***/ 2209:
/*!*****************************************************!*\
  !*** ./src/app/Pages/profile/profile.component.css ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 220px; background:url('banner-bg.jpg');--background-repeat: no-repeat;\r\n  --background-size: cover;  background-size: cover;}\r\n.header_overlay{background:#20978f69;height: 200px;}\r\n.icon_conatiner{padding-top: 10px;}\r\nion-back-button{\r\n  --color: white;\r\n}\r\n.header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n.right_logo{width: 30px;height: 35px;float: right;margin-top: -30px;margin-right: 15px;}\r\n.container_view{margin: 10px;}\r\n.expandable_container{background: #fff;}\r\n.exapandable_view{background-color: #75b1b9;padding: 5px;width: 100%;color:#fff;font-family:Poppins-Medium !important;}\r\n.card_view{height: 100px;padding: 0px;margin: 0px;color: #fff;font-family:Poppins-Medium !important;}\r\n.card_lable_number{font-size: 22px;font-weight: bolder;}\r\n.card_lable_text{font-size: 15px;}\r\n.black_layer{padding: 0px;margin: 10px;}\r\n.card_lable_view{text-align: center;font-size: 9px;width: 100%;}\r\n._curve{    width: 25%;\r\n  margin: 0px auto;\r\n  text-align: center}\r\n.mem_title{text-align: center;width: 65%;background: #75b1b9;color:#fff;margin: 0px auto;padding: 5px;border-radius: 25px;margin-top: 10px;}\r\n.mem_title ion-label {font-size: 12px;}\r\n.v_card{width: 100%;height: auto;background:url('card.png');    background-size: cover;}\r\n.spacer{padding-bottom: 100px;}\r\n.card_logo{width: 30px;height: 35px;float: right;margin-right: 15px;margin-top: 10px;}\r\n.card_overlay{background: #22242821;}\r\n.valid_thr{font-family:Poppins-Light !important; font-size: 10px!important;}\r\n.name_info{position: absolute;\r\n  bottom: 29px;\r\n  text-align: right;\r\n  width: 100%;\r\n  right: 10px;\r\n  font-weight: bold;}\r\n.p_title{font-size: 13px;}\r\n.p_value{font-family:Poppins-Medium !important;}\r\n.black_strip{width: 100%;height: 30px;background: #000;margin-top: 30px;}\r\n.card_text{font-family:Poppins-Medium !important; padding: 10px;font-size: 10px;margin-top: 20px;}\r\n.flipped {\r\n    transform: rotateY( 180deg );\r\n}\r\n.front_side{display:none;}\r\n#myFileInput{\r\n  position: absolute;\r\n  opacity: 0;\r\n  left: 96px;\r\n  width: 50%;\r\n}\r\n  \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2ZpbGUuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxlQUFlLFdBQVcsQ0FBQyxhQUFhLEVBQUUsK0JBQTZDLENBQUMsOEJBQThCO0VBQ3BILHdCQUF3QixHQUFHLHNCQUFzQixDQUFDO0FBQ3BELGdCQUFnQixvQkFBb0IsQ0FBQyxhQUFhLENBQUM7QUFDbkQsZ0JBQWdCLGlCQUFpQixDQUFDO0FBQ2xDO0VBQ0UsY0FBYztBQUNoQjtBQUNBLGNBQWMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxxQ0FBcUMsQ0FBQyxlQUFlLEVBQUU7QUFDaEgsWUFBWSxXQUFXLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQztBQUN4RCxZQUFZLFdBQVcsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDO0FBQzFFLFlBQVksV0FBVyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUM7QUFDdkYsZ0JBQWdCLFlBQVksQ0FBQztBQUM3QixzQkFBc0IsZ0JBQWdCLENBQUM7QUFDdkMsa0JBQWtCLHlCQUF5QixDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLHFDQUFxQyxDQUFDO0FBQ3RILFdBQVcsYUFBYSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLHFDQUFxQyxDQUFDO0FBQ3BHLG1CQUFtQixlQUFlLENBQUMsbUJBQW1CLENBQUM7QUFDdkQsaUJBQWlCLGVBQWUsQ0FBQztBQUNqQyxhQUFhLFlBQVksQ0FBQyxZQUFZLENBQUM7QUFDdkMsaUJBQWlCLGtCQUFrQixDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUM7QUFDL0QsWUFBWSxVQUFVO0VBQ3BCLGdCQUFnQjtFQUNoQixrQkFBa0I7QUFDcEIsV0FBVyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQyxnQkFBZ0IsQ0FBQztBQUMzSSxzQkFBc0IsZUFBZSxDQUFDO0FBQ3RDLFFBQVEsV0FBVyxDQUFDLFlBQVksQ0FBQywwQkFBd0MsS0FBSyxzQkFBc0IsQ0FBQztBQUNyRyxRQUFRLHFCQUFxQixDQUFDO0FBRTlCLFdBQVcsV0FBVyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsa0JBQWtCLENBQUMsZ0JBQWdCLENBQUM7QUFDckYsY0FBYyxxQkFBcUIsQ0FBQztBQUNwQyxXQUFXLG9DQUFvQyxFQUFFLHlCQUF5QixDQUFDO0FBQzNFLFdBQVcsa0JBQWtCO0VBQzNCLFlBQVk7RUFDWixpQkFBaUI7RUFDakIsV0FBVztFQUNYLFdBQVc7RUFDWCxpQkFBaUIsQ0FBQztBQUNsQixTQUFTLGVBQWUsQ0FBQztBQUN6QixTQUFTLHFDQUFxQyxDQUFDO0FBQy9DLGFBQWEsV0FBVyxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQztBQUN4RSxXQUFXLHFDQUFxQyxFQUFFLGFBQWEsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLENBQUM7QUFDakc7SUFJRSw0QkFBNEI7QUFDaEM7QUFDQSxZQUFZLFlBQVksQ0FBQztBQUN6QjtFQUNFLGtCQUFrQjtFQUNsQixVQUFVO0VBQ1YsVUFBVTtFQUNWLFVBQVU7QUFDWiIsImZpbGUiOiJwcm9maWxlLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyX2Jhbm5lcnt3aWR0aDogMTAwJTtoZWlnaHQ6IDIyMHB4OyBiYWNrZ3JvdW5kOnVybCguLi8uLi8uLi9hc3NldHMvYmFubmVyLWJnLmpwZyk7LS1iYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIC0tYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7fVxyXG4uaGVhZGVyX292ZXJsYXl7YmFja2dyb3VuZDojMjA5NzhmNjk7aGVpZ2h0OiAyMDBweDt9XHJcbi5pY29uX2NvbmF0aW5lcntwYWRkaW5nLXRvcDogMTBweDt9XHJcbmlvbi1iYWNrLWJ1dHRvbntcclxuICAtLWNvbG9yOiB3aGl0ZTtcclxufVxyXG4uaGVhZGVyX3RpdGxle2NvbG9yOiAjZmZmO3RleHQtYWxpZ246IGNlbnRlcjt3aWR0aDogMTAwJTtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O2ZvbnQtc2l6ZTogMThweDs7fVxyXG4uX21lbnVfaWNvbntjb2xvcjogI2ZmZjttYXJnaW46IDBweCAwcHg7Zm9udC1zaXplOiAzMHB4O30gICBcclxuLl9jYXJ0X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiA4cHggMHB4O2ZvbnQtc2l6ZTogMjZweDttYXJnaW4tbGVmdDogMTBweDt9XHJcbi5yaWdodF9sb2dve3dpZHRoOiAzMHB4O2hlaWdodDogMzVweDtmbG9hdDogcmlnaHQ7bWFyZ2luLXRvcDogLTMwcHg7bWFyZ2luLXJpZ2h0OiAxNXB4O31cclxuLmNvbnRhaW5lcl92aWV3e21hcmdpbjogMTBweDt9XHJcbi5leHBhbmRhYmxlX2NvbnRhaW5lcntiYWNrZ3JvdW5kOiAjZmZmO31cclxuLmV4YXBhbmRhYmxlX3ZpZXd7YmFja2dyb3VuZC1jb2xvcjogIzc1YjFiOTtwYWRkaW5nOiA1cHg7d2lkdGg6IDEwMCU7Y29sb3I6I2ZmZjtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O31cclxuLmNhcmRfdmlld3toZWlnaHQ6IDEwMHB4O3BhZGRpbmc6IDBweDttYXJnaW46IDBweDtjb2xvcjogI2ZmZjtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O31cclxuLmNhcmRfbGFibGVfbnVtYmVye2ZvbnQtc2l6ZTogMjJweDtmb250LXdlaWdodDogYm9sZGVyO31cclxuLmNhcmRfbGFibGVfdGV4dHtmb250LXNpemU6IDE1cHg7fVxyXG4uYmxhY2tfbGF5ZXJ7cGFkZGluZzogMHB4O21hcmdpbjogMTBweDt9XHJcbi5jYXJkX2xhYmxlX3ZpZXd7dGV4dC1hbGlnbjogY2VudGVyO2ZvbnQtc2l6ZTogOXB4O3dpZHRoOiAxMDAlO31cclxuLl9jdXJ2ZXsgICAgd2lkdGg6IDI1JTtcclxuICBtYXJnaW46IDBweCBhdXRvO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcn1cclxuLm1lbV90aXRsZXt0ZXh0LWFsaWduOiBjZW50ZXI7d2lkdGg6IDY1JTtiYWNrZ3JvdW5kOiAjNzViMWI5O2NvbG9yOiNmZmY7bWFyZ2luOiAwcHggYXV0bztwYWRkaW5nOiA1cHg7Ym9yZGVyLXJhZGl1czogMjVweDttYXJnaW4tdG9wOiAxMHB4O31cclxuLm1lbV90aXRsZSBpb24tbGFiZWwge2ZvbnQtc2l6ZTogMTJweDt9XHJcbi52X2NhcmR7d2lkdGg6IDEwMCU7aGVpZ2h0OiBhdXRvO2JhY2tncm91bmQ6dXJsKC4uLy4uLy4uL2Fzc2V0cy9jYXJkLnBuZyk7ICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7fVxyXG4uc3BhY2Vye3BhZGRpbmctYm90dG9tOiAxMDBweDt9XHJcblxyXG4uY2FyZF9sb2dve3dpZHRoOiAzMHB4O2hlaWdodDogMzVweDtmbG9hdDogcmlnaHQ7bWFyZ2luLXJpZ2h0OiAxNXB4O21hcmdpbi10b3A6IDEwcHg7fVxyXG4uY2FyZF9vdmVybGF5e2JhY2tncm91bmQ6ICMyMjI0MjgyMTt9XHJcbi52YWxpZF90aHJ7Zm9udC1mYW1pbHk6UG9wcGlucy1MaWdodCAhaW1wb3J0YW50OyBmb250LXNpemU6IDEwcHghaW1wb3J0YW50O31cclxuLm5hbWVfaW5mb3twb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgYm90dG9tOiAyOXB4O1xyXG4gIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIHJpZ2h0OiAxMHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO31cclxuICAucF90aXRsZXtmb250LXNpemU6IDEzcHg7fVxyXG4gIC5wX3ZhbHVle2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7fVxyXG4gIC5ibGFja19zdHJpcHt3aWR0aDogMTAwJTtoZWlnaHQ6IDMwcHg7YmFja2dyb3VuZDogIzAwMDttYXJnaW4tdG9wOiAzMHB4O31cclxuICAuY2FyZF90ZXh0e2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7IHBhZGRpbmc6IDEwcHg7Zm9udC1zaXplOiAxMHB4O21hcmdpbi10b3A6IDIwcHg7fVxyXG4gIC5mbGlwcGVkIHtcclxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGVZKCAxODBkZWcgKTtcclxuICAgIC1tb3otdHJhbnNmb3JtOiByb3RhdGVZKCAxODBkZWcgKTtcclxuICAgIC1vLXRyYW5zZm9ybTogcm90YXRlWSggMTgwZGVnICk7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZVkoIDE4MGRlZyApO1xyXG59XHJcbi5mcm9udF9zaWRle2Rpc3BsYXk6bm9uZTt9XHJcbiNteUZpbGVJbnB1dHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgb3BhY2l0eTogMDtcclxuICBsZWZ0OiA5NnB4O1xyXG4gIHdpZHRoOiA1MCU7XHJcbn1cclxuICAiXX0= */");

/***/ }),

/***/ 2506:
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/profile/profile.component.html ***!
  \********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n\n  <ion-content [fullscreen]=\"true\" #loadingIcon>\n\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <div class=\"_curve\">\n            <ion-avatar style=\"width: 100px;\n            height: 100px\">\n            <img class=\"profile_img\" (click)=\"opncamera()\" *ngIf=\"img\" [src]=\"img\"/> \n            </ion-avatar>\n           \n          </div>\n          <div class=\"mem_title\">\n            \n            <ion-label >UPLOAD PROFILE PITCUTRE<input type=\"file\" id=\"myFileInput\" value=\"\" (change)=\"fileChange($event)\"></ion-label>\n          </div>\n          \n\n          <div class=\"more_info\">\n            <div>\n \n              <ion-col size=\"7\" ><img class=\"right_logo\" src=\"../../../assets/second_logo.png\"/></ion-col>\n            </div>\n          </div>\n         </div>\n   \n      </div>\n    </div>\n\n    \n    <div class=\"container_view\">\n      <div class=\"exapandable_view\"  (click)=\"toggle()\">\n          <ion-row>\n              <ion-col size=\"9\">Digitial Card</ion-col>\n              <ion-col size=\"1\" offset=\"2\"><ion-icon name=\"{{icon_name}}\"></ion-icon></ion-col>\n          </ion-row>\n      </div>\n   \n       <ng-container *ngIf=\"show_container_one; \">\n           <div  class=\"expandable_container\">\n            <ion-grid>\n     \n              <ion-row>\n                <ion-card (click)=\"back_side()\" class=\"v_card\">\n                  <ion-row class=\"card_overlay\">\n                    <ion-col><img class=\"qr_code\" src=\"{{this.pqr}}\"></ion-col>\n                    <ion-col>\n                     <div class=\"more_info\">\n                       <div>\n            \n                         <ion-col size=\"7\" ><img class=\"card_logo\" src=\"../../../assets/second_logo.png\"/></ion-col>\n                       </div>\n                     </div>\n      \n                     <div class=\"name_info\">\n                       <div>\n            \n                         <ion-col size=\"7\" ><label>{{pname}}</label>\n                       \n                        </ion-col>\n                       </div>\n                       <label class=\"valid_thr\">VALID THRU <ion-label class=\"mem_values\"><ion-datetime style=\"display: table-row-group;\" value=\"{{pexpdate}}\" display-timezone=\"utc\"></ion-datetime></ion-label></label>\n                     </div>\n      \n                    </ion-col>\n                    \n                  </ion-row>\n                </ion-card>\n                <ion-card  (click)=\"front_side()\" class=\"front_side\"  >\n                  <ion-row class=\"card_overlay\" style=\"    height: 179px;\n                  \">\n                    <div class=\"black_strip\"></div>\n                    <ion-row><ion-label class=\"card_text\">This card is a prepaid foot court card to be swiped of the time of the payment\n                        <br> This card can be recharged to any amount <br>\n                        A security amount of Rs.30/ - is charged\n      \n                    </ion-label></ion-row> \n                    \n                  </ion-row>\n                </ion-card>\n             </ion-row>\n          </ion-grid>\n           </div>     \n       </ng-container>\n\n       <div class=\"exapandable_view\"  (click)=\"toggle2()\">\n           <ion-row>\n               <ion-col size=\"9\">Personal Information </ion-col>\n               <ion-col size=\"1\" offset=\"2\"><ion-icon name=\"{{icon_name_two}}\"></ion-icon></ion-col>\n           </ion-row>\n       </div>\n    \n        <ng-container *ngIf=\"show_container_two; \">\n            <div  class=\"expandable_container\">\n             <ion-item>\n           \n                <ion-col>\n                  <label class=\"p_title\">First Name</label><br>\n                  <label class=\"p_value\">{{pname}}</label>\n                </ion-col>\n                <ion-col>\n                  <label class=\"p_title\">Last Name</label><br>\n                  <label class=\"p_value\">Ustinaska</label>\n                </ion-col>\n              </ion-item>\n             \n              \n\n              <ion-item>\n                <ion-col>\n                  <label class=\"p_title\">Date of Birth</label><br>\n                  <label class=\"p_value\">28/03/1992</label>\n                </ion-col>\n                <ion-col>\n                  <label class=\"p_title\">Documents Submited</label><br>\n                  <label class=\"p_value\">Passport</label>\n                </ion-col>\n              </ion-item>\n\n              <ion-item>\n                <ion-col>\n                  <label class=\"p_title\">Unit No</label><br>\n                  <label class=\"p_value\">1005/ABCD</label>\n                </ion-col>\n                <ion-col>\n                  <label class=\"p_title\">Registerd Phone no</label><br>\n                  <label class=\"p_value\">99999999</label>\n                </ion-col>\n              </ion-item>\n\n              <ion-item>\n                <ion-col>\n                  <label class=\"p_title\">Email</label><br>\n                  <label class=\"p_value\">{{pemail}}</label>\n                </ion-col>\n               \n              </ion-item>\n\n            </div>     \n        </ng-container>\n\n\n        <div class=\"exapandable_view\"  (click)=\"toggle3()\">\n          <ion-row>\n              <ion-col size=\"9\">Membership Information </ion-col>\n              <ion-col size=\"1\" offset=\"2\"><ion-icon name=\"{{icon_name_three}}\"></ion-icon></ion-col>\n          </ion-row>\n      </div>\n   \n       <ng-container *ngIf=\"show_container_three; \">\n           <div  class=\"expandable_container\">\n            \n            <ion-item>\n              <ion-col>\n                <label class=\"p_title\">Current Membership Tier</label><br>\n                <label class=\"p_value\">{{ptype}}</label>\n              </ion-col>\n             \n            </ion-item>\n\n            <ion-item>\n              <ion-col>\n                <label class=\"p_title\">Membership Start Date</label><br>\n                <label class=\"p_value\"><ion-datetime style=\"display: table-row-group;\" value=\"{{pmemberstart}}\" display-timezone=\"utc\"></ion-datetime></label>\n              </ion-col>\n             \n            </ion-item>\n\n            <ion-item>\n              <ion-col>\n                <label class=\"p_title\">Membership End Date</label><br>\n                <label class=\"p_value\"><ion-datetime style=\"display: table-row-group;\" value=\"{{pmemberend}}\" display-timezone=\"utc\"></ion-datetime></label>\n              </ion-col>\n             \n            </ion-item>\n           </div>     \n       </ng-container>\n\n       <div class=\"exapandable_view\"  (click)=\"toggle4()\">\n        <ion-row>\n            <ion-col size=\"9\">Activity History </ion-col>\n            <ion-col size=\"1\" offset=\"2\"><ion-icon name=\"{{icon_name_four}}\"></ion-icon></ion-col>\n        </ion-row>\n    </div>\n \n     <ng-container *ngIf=\"show_container_four; \">\n         <div  class=\"expandable_container\">\n\n          \n          <ion-item>\n            <ion-row>\n              <ion-col>\n                <label class=\"p_title\">Membership Tier</label><br>\n                <label class=\"p_value\">Diamand</label>\n              </ion-col>\n          </ion-row>\n          <ion-row>\n            <ion-col>\n              <label class=\"p_title\">Payment Date</label><br>\n              <label class=\"p_value\">25-6-2021</label>\n            </ion-col>\n        </ion-row>\n        <ion-row>\n          <ion-col>\n            <label class=\"p_title\">Paid Amount</label><br>\n            <label class=\"p_value\">$2000</label>\n          </ion-col>\n      </ion-row>\n          </ion-item>\n         </div>     \n     </ng-container>\n         \n          \n   </div>\n   <div class=\"spacer\"></div>\n  \n  \n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_profile_profile_module_ts.js.map