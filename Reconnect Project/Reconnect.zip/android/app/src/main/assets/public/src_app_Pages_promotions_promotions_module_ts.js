(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_promotions_promotions_module_ts"],{

/***/ 5566:
/*!***************************************************************!*\
  !*** ./src/app/Pages/promotions/promotions-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PromotionsRoutingModule": () => (/* binding */ PromotionsRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _promotions_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./promotions.component */ 2558);




const routes = [
    {
        path: "",
        component: _promotions_component__WEBPACK_IMPORTED_MODULE_0__.PromotionsComponent
    }
];
let PromotionsRoutingModule = class PromotionsRoutingModule {
};
PromotionsRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], PromotionsRoutingModule);



/***/ }),

/***/ 2558:
/*!**********************************************************!*\
  !*** ./src/app/Pages/promotions/promotions.component.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PromotionsComponent": () => (/* binding */ PromotionsComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_promotions_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./promotions.component.html */ 4682);
/* harmony import */ var _promotions_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./promotions.component.css */ 7751);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _promotions_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./promotions.service */ 2556);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 476);






let PromotionsComponent = class PromotionsComponent {
    constructor(api, loadingController) {
        this.api = api;
        this.loadingController = loadingController;
        this.list = new Array(5);
        this.condition = 2;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.loading = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: 'Please wait...',
                duration: 2000
            });
            this.get_listing();
        });
    }
    get_listing() {
        this.loading.present();
        this.api._getPartnerOfferList().subscribe(data => {
            this.promostionList = data;
            console.log(this.promostionList);
            this.loading.dismiss();
        });
    }
};
PromotionsComponent.ctorParameters = () => [
    { type: _promotions_service__WEBPACK_IMPORTED_MODULE_2__.PromotionsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController }
];
PromotionsComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-promotions',
        template: _raw_loader_promotions_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_promotions_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PromotionsComponent);



/***/ }),

/***/ 5608:
/*!*******************************************************!*\
  !*** ./src/app/Pages/promotions/promotions.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PromotionsModule": () => (/* binding */ PromotionsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _promotions_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./promotions-routing.module */ 5566);
/* harmony import */ var _promotions_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./promotions.component */ 2558);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);






let PromotionsModule = class PromotionsModule {
};
PromotionsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_promotions_component__WEBPACK_IMPORTED_MODULE_1__.PromotionsComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _promotions_routing_module__WEBPACK_IMPORTED_MODULE_0__.PromotionsRoutingModule
        ]
    })
], PromotionsModule);



/***/ }),

/***/ 2556:
/*!********************************************************!*\
  !*** ./src/app/Pages/promotions/promotions.service.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PromotionsService": () => (/* binding */ PromotionsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 205);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 5304);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);






let PromotionsService = class PromotionsService {
    constructor(httpClient) {
        this.httpClient = httpClient;
        this.getPartnerOfferList = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url + "PartnerOfferApi/getPartnerOfferList";
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({ 'Content-Type': 'application/json' })
        };
    }
    _getPartnerOfferList() {
        return this.httpClient.get(`${this.getPartnerOfferList}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.handleError));
        ;
    }
    handleError(error) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Error: ${error.error.message}`;
        }
        else {
            // server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.log(errorMessage);
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(errorMessage);
    }
};
PromotionsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
PromotionsService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], PromotionsService);



/***/ }),

/***/ 7751:
/*!***********************************************************!*\
  !*** ./src/app/Pages/promotions/promotions.component.css ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 130px; background:url('banner-bg.jpg');--background-repeat: no-repeat;\r\n    --background-size: cover;  background-size: cover;}\r\n  .header_overlay{background:#20978f69;height: 130px;}\r\n  .icon_conatiner{padding-top: 10px;}\r\n  ion-back-button{\r\n    --color: white;\r\n  }\r\n  .header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n  ._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n  ._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n  .right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n  .list_container{margin: 5px;}\r\n  .list_row{margin: 10px 5px 10px 5px; box-shadow: 0 0px 4px 1px #ddd;border-radius: 5px;}\r\n  .img_icon{width: 100px;height: 100px;margin-top: 20px;margin-left: 5px;}\r\n  .p_title{margin-left: 11px; width: 100%; font-size: 17px; color:#fff;font-family:Poppins-Medium !important;}\r\n  .p_sub_title{margin-left: 11px; width: 100%; font-size: 13px; color:#fff;margin-bottom: 3px;font-family:Poppins-Medium !important;}\r\n  .p_location{font-size: 13px;margin-left: 4px;margin-top: 3px;margin-bottom: 3px;}\r\n  .p_location ion-icon{color: rgb(100, 152, 231);margin-right: 5px;}\r\n  .p_price{font-size: 13px;margin-left: 5px;margin-top: 3px;margin-bottom: 3px;}\r\n  .p_time{font-size: 13px;margin-left: 5px;margin-top: 3px; }\r\n  .card_content{margin: 5px;}\r\n  .rating_star{color:#fbff12;font-size: 13px;margin-left: 5px;padding: 2px;}\r\n  .rating_number{ margin-left: 10px;border: 1px solid #ddd; color:#fff; font-size: 13px;padding: 2px;}\r\n  .hotel_text{position: absolute;z-index: 999;border: 0px;top: 124px;}\r\n  .item_container{position: absolute;\r\n    z-index: 999;\r\n    border: 0px;\r\n    top: 5px;\r\n    bottom: 0px;\r\n    width: 97%;\r\n    height: 200px;\r\n    background: #0000007d;}\r\n  .rating_conainer{margin-left: 5px;display: none;}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb21vdGlvbnMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxlQUFlLFdBQVcsQ0FBQyxhQUFhLEVBQUUsK0JBQTZDLENBQUMsOEJBQThCO0lBQ2xILHdCQUF3QixHQUFHLHNCQUFzQixDQUFDO0VBQ3BELGdCQUFnQixvQkFBb0IsQ0FBQyxhQUFhLENBQUM7RUFDbkQsZ0JBQWdCLGlCQUFpQixDQUFDO0VBQ2xDO0lBQ0UsY0FBYztFQUNoQjtFQUNBLGNBQWMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQyxxQ0FBcUMsQ0FBQyxlQUFlLEVBQUU7RUFDaEgsWUFBWSxXQUFXLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQztFQUN4RCxZQUFZLFdBQVcsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDLGlCQUFpQixDQUFDO0VBQzFFLFlBQVksV0FBVyxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLENBQUM7RUFDdkYsZ0JBQWdCLFdBQVcsQ0FBQztFQUM5QixVQUFVLHlCQUF5QixFQUFFLDhCQUE4QixDQUFDLGtCQUFrQixDQUFDO0VBQ3ZGLFVBQVUsWUFBWSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQztFQUN2RSxTQUFTLGlCQUFpQixFQUFFLFdBQVcsRUFBRSxlQUFlLEVBQUUsVUFBVSxDQUFDLHFDQUFxQyxDQUFDO0VBQzNHLGFBQWEsaUJBQWlCLEVBQUUsV0FBVyxFQUFFLGVBQWUsRUFBRSxVQUFVLENBQUMsa0JBQWtCLENBQUMscUNBQXFDLENBQUM7RUFDbEksWUFBWSxlQUFlLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDO0VBQ2hGLHFCQUFxQix5QkFBeUIsQ0FBQyxpQkFBaUIsQ0FBQztFQUNqRSxTQUFTLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUM7RUFDN0UsUUFBUSxlQUFlLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxFQUFFO0VBQzFELGNBQWMsV0FBVyxDQUFDO0VBQzFCLGFBQWEsYUFBYSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUM7RUFDekUsZ0JBQWdCLGlCQUFpQixDQUFDLHNCQUFzQixFQUFFLFVBQVUsRUFBRSxlQUFlLENBQUMsWUFBWSxDQUFDO0VBQ25HLFlBQVksa0JBQWtCLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUM7RUFDbkUsZ0JBQWdCLGtCQUFrQjtJQUM5QixZQUFZO0lBQ1osV0FBVztJQUNYLFFBQVE7SUFDUixXQUFXO0lBQ1gsVUFBVTtJQUNWLGFBQWE7SUFDYixxQkFBcUIsQ0FBQztFQUN0QixpQkFBaUIsZ0JBQWdCLENBQUMsYUFBYSxDQUFDIiwiZmlsZSI6InByb21vdGlvbnMuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJfYmFubmVye3dpZHRoOiAxMDAlO2hlaWdodDogMTMwcHg7IGJhY2tncm91bmQ6dXJsKC4uLy4uLy4uL2Fzc2V0cy9iYW5uZXItYmcuanBnKTstLWJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAtLWJhY2tncm91bmQtc2l6ZTogY292ZXI7ICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO31cclxuICAuaGVhZGVyX292ZXJsYXl7YmFja2dyb3VuZDojMjA5NzhmNjk7aGVpZ2h0OiAxMzBweDt9XHJcbiAgLmljb25fY29uYXRpbmVye3BhZGRpbmctdG9wOiAxMHB4O31cclxuICBpb24tYmFjay1idXR0b257XHJcbiAgICAtLWNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiAgLmhlYWRlcl90aXRsZXtjb2xvcjogI2ZmZjt0ZXh0LWFsaWduOiBjZW50ZXI7d2lkdGg6IDEwMCU7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtmb250LXNpemU6IDE4cHg7O31cclxuICAuX21lbnVfaWNvbntjb2xvcjogI2ZmZjttYXJnaW46IDBweCAwcHg7Zm9udC1zaXplOiAzMHB4O30gICBcclxuICAuX2NhcnRfaWNvbntjb2xvcjogI2ZmZjttYXJnaW46IDhweCAwcHg7Zm9udC1zaXplOiAyNnB4O21hcmdpbi1sZWZ0OiAxMHB4O31cclxuICAucmlnaHRfbG9nb3t3aWR0aDogMzBweDtoZWlnaHQ6IDM1cHg7ZmxvYXQ6IHJpZ2h0O21hcmdpbi10b3A6IC0xOXB4O21hcmdpbi1yaWdodDogMTVweDt9XHJcbiAgLmxpc3RfY29udGFpbmVye21hcmdpbjogNXB4O31cclxuLmxpc3Rfcm93e21hcmdpbjogMTBweCA1cHggMTBweCA1cHg7IGJveC1zaGFkb3c6IDAgMHB4IDRweCAxcHggI2RkZDtib3JkZXItcmFkaXVzOiA1cHg7fVxyXG4uaW1nX2ljb257d2lkdGg6IDEwMHB4O2hlaWdodDogMTAwcHg7bWFyZ2luLXRvcDogMjBweDttYXJnaW4tbGVmdDogNXB4O31cclxuLnBfdGl0bGV7bWFyZ2luLWxlZnQ6IDExcHg7IHdpZHRoOiAxMDAlOyBmb250LXNpemU6IDE3cHg7IGNvbG9yOiNmZmY7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbi5wX3N1Yl90aXRsZXttYXJnaW4tbGVmdDogMTFweDsgd2lkdGg6IDEwMCU7IGZvbnQtc2l6ZTogMTNweDsgY29sb3I6I2ZmZjttYXJnaW4tYm90dG9tOiAzcHg7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbi5wX2xvY2F0aW9ue2ZvbnQtc2l6ZTogMTNweDttYXJnaW4tbGVmdDogNHB4O21hcmdpbi10b3A6IDNweDttYXJnaW4tYm90dG9tOiAzcHg7fVxyXG4ucF9sb2NhdGlvbiBpb24taWNvbntjb2xvcjogcmdiKDEwMCwgMTUyLCAyMzEpO21hcmdpbi1yaWdodDogNXB4O31cclxuLnBfcHJpY2V7Zm9udC1zaXplOiAxM3B4O21hcmdpbi1sZWZ0OiA1cHg7bWFyZ2luLXRvcDogM3B4O21hcmdpbi1ib3R0b206IDNweDt9XHJcbi5wX3RpbWV7Zm9udC1zaXplOiAxM3B4O21hcmdpbi1sZWZ0OiA1cHg7bWFyZ2luLXRvcDogM3B4OyB9XHJcbi5jYXJkX2NvbnRlbnR7bWFyZ2luOiA1cHg7fVxyXG4ucmF0aW5nX3N0YXJ7Y29sb3I6I2ZiZmYxMjtmb250LXNpemU6IDEzcHg7bWFyZ2luLWxlZnQ6IDVweDtwYWRkaW5nOiAycHg7fVxyXG4ucmF0aW5nX251bWJlcnsgbWFyZ2luLWxlZnQ6IDEwcHg7Ym9yZGVyOiAxcHggc29saWQgI2RkZDsgY29sb3I6I2ZmZjsgZm9udC1zaXplOiAxM3B4O3BhZGRpbmc6IDJweDt9XHJcbi5ob3RlbF90ZXh0e3Bvc2l0aW9uOiBhYnNvbHV0ZTt6LWluZGV4OiA5OTk7Ym9yZGVyOiAwcHg7dG9wOiAxMjRweDt9XHJcbi5pdGVtX2NvbnRhaW5lcntwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB6LWluZGV4OiA5OTk7XHJcbiAgICBib3JkZXI6IDBweDtcclxuICAgIHRvcDogNXB4O1xyXG4gICAgYm90dG9tOiAwcHg7XHJcbiAgICB3aWR0aDogOTclO1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxuICAgIGJhY2tncm91bmQ6ICMwMDAwMDA3ZDt9XHJcbiAgICAucmF0aW5nX2NvbmFpbmVye21hcmdpbi1sZWZ0OiA1cHg7ZGlzcGxheTogbm9uZTt9Il19 */");

/***/ }),

/***/ 4682:
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/promotions/promotions.component.html ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">Hotel Promotions</ion-label></ion-row>\n         </div>\n   \n      </div>\n    </div>\n\n    <ion-list class=\"list_container\">\n        <ion-row class=\"list_row\"  *ngFor=\"let card of [0,1,2,3,4,5,6] \">\n        \n       \n            <ion-col>\n              <img style=\"height: 200px; width: 100%; border-radius: 5px;\" src=\"../../../assets/Waves.jpg\">\n              <div class=\"item_container\">\n              <div class=\"hotel_text\">\n                    <ion-row><label class=\"p_title\">The Hotel Vivanta</label></ion-row>\n                    <ion-row> <label class=\"p_sub_title\">Marcus</label></ion-row>\n                    <ion-row class=\"rating_conainer\"> <ion-icon class=\"rating_star\" *ngFor=\"let item of list;let i = index\" [name]=\"condition <= i? 'star-outline' :'star' \">\n                    </ion-icon> <label class=\"rating_number\">2.2</label></ion-row>\n                 </div> \n               </div>\n           </ion-col>\n  \n          \n  \n        </ion-row>\n       \n      </ion-list>\n  \n  \n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_promotions_promotions_module_ts.js.map