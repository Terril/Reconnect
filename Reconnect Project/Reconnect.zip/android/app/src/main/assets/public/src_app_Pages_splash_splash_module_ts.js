(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_splash_splash_module_ts"],{

/***/ 6025:
/*!*******************************************************!*\
  !*** ./src/app/Pages/splash/spalsh-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "routes": () => (/* binding */ routes),
/* harmony export */   "SplashPageRoutingModule": () => (/* binding */ SplashPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _splash_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./splash.component */ 4061);




const routes = [
    {
        path: "",
        component: _splash_component__WEBPACK_IMPORTED_MODULE_0__.SplashComponent
    }
];
let SplashPageRoutingModule = class SplashPageRoutingModule {
};
SplashPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        declarations: [],
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SplashPageRoutingModule);



/***/ }),

/***/ 4061:
/*!**************************************************!*\
  !*** ./src/app/Pages/splash/splash.component.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashComponent": () => (/* binding */ SplashComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_splash_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./splash.component.html */ 8716);
/* harmony import */ var _splash_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./splash.component.css */ 8637);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let SplashComponent = class SplashComponent {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    login() {
        this.router.navigate(['/login']);
    }
    dashboard() {
        this.router.navigate(['/register']);
    }
};
SplashComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
SplashComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-splash',
        template: _raw_loader_splash_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_splash_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SplashComponent);



/***/ }),

/***/ 3851:
/*!***********************************************!*\
  !*** ./src/app/Pages/splash/splash.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SplashPageModule": () => (/* binding */ SplashPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _spalsh_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./spalsh-routing.module */ 6025);
/* harmony import */ var _splash_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./splash.component */ 4061);






let SplashPageModule = class SplashPageModule {
};
SplashPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _spalsh_routing_module__WEBPACK_IMPORTED_MODULE_0__.SplashPageRoutingModule
        ],
        declarations: [_splash_component__WEBPACK_IMPORTED_MODULE_1__.SplashComponent],
    })
], SplashPageModule);



/***/ }),

/***/ 8637:
/*!***************************************************!*\
  !*** ./src/app/Pages/splash/splash.component.css ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".body_container{width: 100%; background:url('login-bg.png');height:  100%;--background-repeat: no-repeat ;--background-size: cover; }\r\n.body_overlay{background:#75b1b9e0;height: 100%;}\r\n.slogan_container{width: 80%;margin: 0px auto;display: block;text-align: center;margin-top: 38px;}\r\n.slogan{color: #fff; font-family:Poppins-Medium !important;font-size: 25px;opacity: 0.4;font-weight: 600;}\r\n.slogan_pre{ font-family:Poppins-Light !important;color: #fff;font-weight: 500;}\r\n.logo_container{width: 15%;margin: 0px auto;}\r\n.logo_container img{margin-top: 50px;}\r\n._button{ --background-activated:#fff; width: 80%;margin: 0px auto;  --border-radius: 5px!important; box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);font-family:Poppins-Medium !important;font-weight: bold; margin-top: 20px; color: #2a918a; --background: #fff;font-size: 18px;--border-radius: 6px;display: block;height: 50px;}\r\n._button:hover{--background-hover: #fff;--background: #fff;outline: none;}\r\n.footer_pre{font-family:Poppins-Medium !important;}\r\n.footer_text{ width: 100%;padding-bottom: 0 !important;position: fixed;bottom:0px; padding: 5px;margin-bottom: 30px; margin-top: 20px; font-family:Poppins-Light !important;color: #fff;font-weight: 500;font-size: 10px;text-align: center;float: right;}\r\n.text_logo{text-align: center;color: #fff; font-family:Poppins-Medium !important;font-size: 30px;font-weight: bolder;}\r\n.lower_content { padding-bottom: 0 !important;position: fixed;bottom:0px; padding: 5px;margin-bottom: 30px;  color: #28aebb;font-size: 14px;float: right;text-decoration: none;text-align: center;}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNwbGFzaC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQixXQUFXLEVBQUUsOEJBQTRDLENBQUMsYUFBYSxDQUFDLCtCQUErQixDQUFDLHdCQUF3QixFQUFFO0FBQ2xKLGNBQWMsb0JBQW9CLENBQUMsWUFBWSxDQUFDO0FBQ2hELGtCQUFrQixVQUFVLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDO0FBQ2pHLFFBQVEsV0FBVyxFQUFFLHFDQUFxQyxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUM7QUFDekcsYUFBYSxvQ0FBb0MsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUM7QUFDL0UsZ0JBQWdCLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQztBQUM1QyxvQkFBb0IsZ0JBQWdCLENBQUM7QUFDckMsVUFBVSwyQkFBMkIsRUFBRSxVQUFVLENBQUMsZ0JBQWdCLEdBQUcsOEJBQThCLEVBQUUsdUNBQXVDLENBQUMscUNBQXFDLENBQUMsaUJBQWlCLEVBQUUsZ0JBQWdCLEVBQUUsY0FBYyxFQUFFLGtCQUFrQixDQUFDLGVBQWUsQ0FBQyxvQkFBb0IsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDO0FBQzVULGVBQWUsd0JBQXdCLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDO0FBQ3pFLFlBQVkscUNBQXFDLENBQUM7QUFDbEQsY0FBYyxXQUFXLENBQUMsNEJBQTRCLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxZQUFZLENBQUMsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsb0NBQW9DLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUM7QUFDelAsV0FBVyxrQkFBa0IsQ0FBQyxXQUFXLEVBQUUscUNBQXFDLENBQUMsZUFBZSxDQUFDLG1CQUFtQixDQUFDO0FBQ3JILGlCQUFpQiw0QkFBNEIsQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLFlBQVksQ0FBQyxtQkFBbUIsR0FBRyxjQUFjLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBa0IsQ0FBQyIsImZpbGUiOiJzcGxhc2guY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib2R5X2NvbnRhaW5lcnt3aWR0aDogMTAwJTsgYmFja2dyb3VuZDp1cmwoLi4vLi4vLi4vYXNzZXRzL2xvZ2luLWJnLnBuZyk7aGVpZ2h0OiAgMTAwJTstLWJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQgOy0tYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsgfVxyXG4uYm9keV9vdmVybGF5e2JhY2tncm91bmQ6Izc1YjFiOWUwO2hlaWdodDogMTAwJTt9XHJcbi5zbG9nYW5fY29udGFpbmVye3dpZHRoOiA4MCU7bWFyZ2luOiAwcHggYXV0bztkaXNwbGF5OiBibG9jazt0ZXh0LWFsaWduOiBjZW50ZXI7bWFyZ2luLXRvcDogMzhweDt9XHJcbi5zbG9nYW57Y29sb3I6ICNmZmY7IGZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7Zm9udC1zaXplOiAyNXB4O29wYWNpdHk6IDAuNDtmb250LXdlaWdodDogNjAwO31cclxuLnNsb2dhbl9wcmV7IGZvbnQtZmFtaWx5OlBvcHBpbnMtTGlnaHQgIWltcG9ydGFudDtjb2xvcjogI2ZmZjtmb250LXdlaWdodDogNTAwO31cclxuLmxvZ29fY29udGFpbmVye3dpZHRoOiAxNSU7bWFyZ2luOiAwcHggYXV0bzt9XHJcbi5sb2dvX2NvbnRhaW5lciBpbWd7bWFyZ2luLXRvcDogNTBweDt9XHJcbi5fYnV0dG9ueyAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiNmZmY7IHdpZHRoOiA4MCU7bWFyZ2luOiAwcHggYXV0bzsgIC0tYm9yZGVyLXJhZGl1czogNXB4IWltcG9ydGFudDsgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSgwLDAsMCwwLjIpO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7Zm9udC13ZWlnaHQ6IGJvbGQ7IG1hcmdpbi10b3A6IDIwcHg7IGNvbG9yOiAjMmE5MThhOyAtLWJhY2tncm91bmQ6ICNmZmY7Zm9udC1zaXplOiAxOHB4Oy0tYm9yZGVyLXJhZGl1czogNnB4O2Rpc3BsYXk6IGJsb2NrO2hlaWdodDogNTBweDt9XHJcbi5fYnV0dG9uOmhvdmVyey0tYmFja2dyb3VuZC1ob3ZlcjogI2ZmZjstLWJhY2tncm91bmQ6ICNmZmY7b3V0bGluZTogbm9uZTt9XHJcbi5mb290ZXJfcHJle2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7fVxyXG4uZm9vdGVyX3RleHR7IHdpZHRoOiAxMDAlO3BhZGRpbmctYm90dG9tOiAwICFpbXBvcnRhbnQ7cG9zaXRpb246IGZpeGVkO2JvdHRvbTowcHg7IHBhZGRpbmc6IDVweDttYXJnaW4tYm90dG9tOiAzMHB4OyBtYXJnaW4tdG9wOiAyMHB4OyBmb250LWZhbWlseTpQb3BwaW5zLUxpZ2h0ICFpbXBvcnRhbnQ7Y29sb3I6ICNmZmY7Zm9udC13ZWlnaHQ6IDUwMDtmb250LXNpemU6IDEwcHg7dGV4dC1hbGlnbjogY2VudGVyO2Zsb2F0OiByaWdodDt9XHJcbi50ZXh0X2xvZ297dGV4dC1hbGlnbjogY2VudGVyO2NvbG9yOiAjZmZmOyBmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O2ZvbnQtc2l6ZTogMzBweDtmb250LXdlaWdodDogYm9sZGVyO31cclxuLmxvd2VyX2NvbnRlbnQgeyBwYWRkaW5nLWJvdHRvbTogMCAhaW1wb3J0YW50O3Bvc2l0aW9uOiBmaXhlZDtib3R0b206MHB4OyBwYWRkaW5nOiA1cHg7bWFyZ2luLWJvdHRvbTogMzBweDsgIGNvbG9yOiAjMjhhZWJiO2ZvbnQtc2l6ZTogMTRweDtmbG9hdDogcmlnaHQ7dGV4dC1kZWNvcmF0aW9uOiBub25lO3RleHQtYWxpZ246IGNlbnRlcjt9Il19 */");

/***/ }),

/***/ 8716:
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/splash/splash.component.html ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<div class=\"body_container\">\n <div class=\"body_overlay\">\n     <div class=\"logo_container\"><img src=\"../../../assets/reconnect_logo.png\"/></div>\n     <div class=\"slogan_container\">\n     <div class=\"slogan\"><span class=\"slogan_pre\">Re</span>Plenish</div>\n     <div class=\"slogan\"><span class=\"slogan_pre\">Re</span>Charge</div>\n     <div class=\"slogan\"><span class=\"slogan_pre\">Re</span>Shape</div>\n    </div>\n    \n    <div class=\"text_logo\">ReConnect</div>\n    <ion-button class=\"_button\" (click)=\"login()\">LOGIN</ion-button>\n    <ion-button class=\"_button\"(click)=\"dashboard()\" >GUEST</ion-button>\n    <div class=\"footer_text\"><span class=\"footer_pre\">ReConnect</span>@ is part of IFA Group.All Rights Reserved.</div>\n </div>\n</div>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_splash_splash_module_ts.js.map