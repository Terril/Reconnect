(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_classbooking_classbooking_module_ts"],{

/***/ 7249:
/*!*******************************************************************!*\
  !*** ./src/app/Pages/classbooking/classbooking-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClassbookingRoutingModule": () => (/* binding */ ClassbookingRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _classbooking_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./classbooking.component */ 4358);




const routes = [{
        path: "",
        component: _classbooking_component__WEBPACK_IMPORTED_MODULE_0__.ClassbookingComponent
    }];
let ClassbookingRoutingModule = class ClassbookingRoutingModule {
};
ClassbookingRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], ClassbookingRoutingModule);



/***/ }),

/***/ 4358:
/*!**************************************************************!*\
  !*** ./src/app/Pages/classbooking/classbooking.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClassbookingComponent": () => (/* binding */ ClassbookingComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_classbooking_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./classbooking.component.html */ 5799);
/* harmony import */ var _classbooking_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./classbooking.component.scss */ 1658);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let ClassbookingComponent = class ClassbookingComponent {
    constructor(router) {
        this.router = router;
        this.list = new Array('Yoga', 'Prama', 'Meditation', 'Arobics');
        this.condition = 2;
    }
    ngOnInit() { }
    detail_page() {
        this.router.navigate(['/details/1']);
    }
};
ClassbookingComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
ClassbookingComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-classbooking',
        template: _raw_loader_classbooking_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_classbooking_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ClassbookingComponent);



/***/ }),

/***/ 8290:
/*!***********************************************************!*\
  !*** ./src/app/Pages/classbooking/classbooking.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ClassbookingModule": () => (/* binding */ ClassbookingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _classbooking_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./classbooking-routing.module */ 7249);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _classbooking_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./classbooking.component */ 4358);






let ClassbookingModule = class ClassbookingModule {
};
ClassbookingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_classbooking_component__WEBPACK_IMPORTED_MODULE_1__.ClassbookingComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _classbooking_routing_module__WEBPACK_IMPORTED_MODULE_0__.ClassbookingRoutingModule
        ]
    })
], ClassbookingModule);



/***/ }),

/***/ 1658:
/*!****************************************************************!*\
  !*** ./src/app/Pages/classbooking/classbooking.component.scss ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner {\n  width: 100%;\n  height: 130px;\n  background: url('gym_booking.jpg');\n  --background-repeat: no-repeat;\n  --background-size: cover;\n  background-size: cover;\n}\n\n.header_overlay {\n  background: #20978f69;\n  height: 130px;\n}\n\n.icon_conatiner {\n  padding-top: 10px;\n}\n\nion-back-button {\n  --color: white;\n}\n\n.header_title {\n  color: #fff;\n  text-align: center;\n  width: 100%;\n  font-family: Poppins-Medium !important;\n  font-size: 18px;\n}\n\n._menu_icon {\n  color: #fff;\n  margin: 0px 0px;\n  font-size: 30px;\n}\n\n._cart_icon {\n  color: #fff;\n  margin: 8px 0px;\n  font-size: 26px;\n  margin-left: 10px;\n}\n\n.right_logo {\n  width: 30px;\n  height: 35px;\n  float: right;\n  margin-top: -19px;\n  margin-right: 15px;\n}\n\n.list_container {\n  margin: 5px;\n}\n\n.list_row {\n  margin: 10px 5px 10px 5px;\n  border: 2px solid #20978f69;\n  border-radius: 5px;\n}\n\n.img_icon {\n  width: 100px;\n  height: 137px;\n  margin-top: 20px;\n  margin-left: 5px;\n}\n\n.p_title {\n  margin: 5px;\n  width: 100%;\n  font-size: 13px;\n  color: #555353;\n  font-weight: 600;\n  font-family: Poppins-Medium !important;\n}\n\n.p_sub_title {\n  margin: 3px 0px 0px 3px;\n  width: 100%;\n  font-size: 13px;\n  color: #706f6f;\n  margin-bottom: 3px;\n  font-family: Poppins-Medium !important;\n}\n\n.p_location {\n  font-size: 13px;\n  margin-left: 4px;\n  margin-top: 3px;\n  margin-bottom: 3px;\n}\n\n.p_location ion-icon {\n  color: #6498e7;\n  margin-right: 5px;\n  font-family: Poppins-Medium !important;\n}\n\n.p_price {\n  font-size: 13px;\n  margin-left: 5px;\n  margin-top: 3px;\n  margin-bottom: 3px;\n  font-family: Poppins-Medium !important;\n}\n\n.p_time {\n  font-size: 13px;\n  margin-left: 5px;\n  margin-top: 3px;\n  font-family: Poppins-Medium !important;\n}\n\n.card_content {\n  margin: 5px;\n}\n\n.rating_star {\n  color: #f9c011;\n  font-size: 13px;\n  margin-left: 5px;\n  margin-top: 5px;\n  margin-bottom: 5px;\n}\n\n.rating_number {\n  color: #727070;\n  font-size: 13px;\n  font-weight: bold;\n  margin-left: 5px;\n  margin-top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNsYXNzYm9va2luZy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUFlLFdBQUE7RUFBWSxhQUFBO0VBQWUsa0NBQUE7RUFBZ0QsOEJBQUE7RUFDdEYsd0JBQUE7RUFBMkIsc0JBQUE7QUFNL0I7O0FBTEU7RUFBZ0IscUJBQUE7RUFBcUIsYUFBQTtBQVV2Qzs7QUFURTtFQUFnQixpQkFBQTtBQWFsQjs7QUFaRTtFQUNFLGNBQUE7QUFlSjs7QUFiRTtFQUFjLFdBQUE7RUFBWSxrQkFBQTtFQUFtQixXQUFBO0VBQVksc0NBQUE7RUFBc0MsZUFBQTtBQXFCakc7O0FBcEJFO0VBQVksV0FBQTtFQUFZLGVBQUE7RUFBZ0IsZUFBQTtBQTBCMUM7O0FBekJFO0VBQVksV0FBQTtFQUFZLGVBQUE7RUFBZ0IsZUFBQTtFQUFnQixpQkFBQTtBQWdDMUQ7O0FBL0JFO0VBQVksV0FBQTtFQUFZLFlBQUE7RUFBYSxZQUFBO0VBQWEsaUJBQUE7RUFBa0Isa0JBQUE7QUF1Q3RFOztBQXJDRTtFQUFnQixXQUFBO0FBeUNsQjs7QUF4Q0U7RUFBVSx5QkFBQTtFQUEyQiwyQkFBQTtFQUE0QixrQkFBQTtBQThDbkU7O0FBN0NFO0VBQVUsWUFBQTtFQUFhLGFBQUE7RUFBYyxnQkFBQTtFQUFpQixnQkFBQTtBQW9EeEQ7O0FBbkRFO0VBQVMsV0FBQTtFQUFhLFdBQUE7RUFBYSxlQUFBO0VBQWlCLGNBQUE7RUFBdUIsZ0JBQUE7RUFBaUIsc0NBQUE7QUE0RDlGOztBQTNERTtFQUFhLHVCQUFBO0VBQTBCLFdBQUE7RUFBYSxlQUFBO0VBQWlCLGNBQUE7RUFBMEIsa0JBQUE7RUFBbUIsc0NBQUE7QUFvRXBIOztBQW5FRTtFQUFZLGVBQUE7RUFBZ0IsZ0JBQUE7RUFBaUIsZUFBQTtFQUFnQixrQkFBQTtBQTBFL0Q7O0FBekVFO0VBQXFCLGNBQUE7RUFBMEIsaUJBQUE7RUFBa0Isc0NBQUE7QUErRW5FOztBQTlFRTtFQUFTLGVBQUE7RUFBZ0IsZ0JBQUE7RUFBaUIsZUFBQTtFQUFnQixrQkFBQTtFQUFtQixzQ0FBQTtBQXNGL0U7O0FBckZFO0VBQVEsZUFBQTtFQUFnQixnQkFBQTtFQUFpQixlQUFBO0VBQWdCLHNDQUFBO0FBNEYzRDs7QUEzRkU7RUFBYyxXQUFBO0FBK0ZoQjs7QUE5RkU7RUFBYSxjQUFBO0VBQWMsZUFBQTtFQUFnQixnQkFBQTtFQUFpQixlQUFBO0VBQWdCLGtCQUFBO0FBc0c5RTs7QUFyR0U7RUFBZSxjQUFBO0VBQTJCLGVBQUE7RUFBZ0IsaUJBQUE7RUFBa0IsZ0JBQUE7RUFBaUIsZUFBQTtBQTZHL0YiLCJmaWxlIjoiY2xhc3Nib29raW5nLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlcl9iYW5uZXJ7d2lkdGg6IDEwMCU7aGVpZ2h0OiAxMzBweDsgYmFja2dyb3VuZDp1cmwoLi4vLi4vLi4vYXNzZXRzL2d5bV9ib29raW5nLmpwZyk7LS1iYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgLS1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyOyAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjt9XHJcbiAgLmhlYWRlcl9vdmVybGF5e2JhY2tncm91bmQ6IzIwOTc4ZjY5O2hlaWdodDogMTMwcHg7fVxyXG4gIC5pY29uX2NvbmF0aW5lcntwYWRkaW5nLXRvcDogMTBweDt9XHJcbiAgaW9uLWJhY2stYnV0dG9ue1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgfVxyXG4gIC5oZWFkZXJfdGl0bGV7Y29sb3I6ICNmZmY7dGV4dC1hbGlnbjogY2VudGVyO3dpZHRoOiAxMDAlO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7Zm9udC1zaXplOiAxOHB4Ozt9XHJcbiAgLl9tZW51X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiAwcHggMHB4O2ZvbnQtc2l6ZTogMzBweDt9ICAgXHJcbiAgLl9jYXJ0X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiA4cHggMHB4O2ZvbnQtc2l6ZTogMjZweDttYXJnaW4tbGVmdDogMTBweDt9XHJcbiAgLnJpZ2h0X2xvZ297d2lkdGg6IDMwcHg7aGVpZ2h0OiAzNXB4O2Zsb2F0OiByaWdodDttYXJnaW4tdG9wOiAtMTlweDttYXJnaW4tcmlnaHQ6IDE1cHg7fVxyXG4gIFxyXG4gIC5saXN0X2NvbnRhaW5lcnttYXJnaW46IDVweDt9XHJcbiAgLmxpc3Rfcm93e21hcmdpbjogMTBweCA1cHggMTBweCA1cHg7IGJvcmRlcjogMnB4IHNvbGlkICMyMDk3OGY2OTtib3JkZXItcmFkaXVzOiA1cHg7fVxyXG4gIC5pbWdfaWNvbnt3aWR0aDogMTAwcHg7aGVpZ2h0OiAxMzdweDttYXJnaW4tdG9wOiAyMHB4O21hcmdpbi1sZWZ0OiA1cHg7fVxyXG4gIC5wX3RpdGxle21hcmdpbjogNXB4OyB3aWR0aDogMTAwJTsgZm9udC1zaXplOiAxM3B4OyBjb2xvcjogcmdiKDg1LCA4MywgODMpO2ZvbnQtd2VpZ2h0OiA2MDA7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbiAgLnBfc3ViX3RpdGxle21hcmdpbjogM3B4IDBweCAwcHggM3B4IDsgd2lkdGg6IDEwMCU7IGZvbnQtc2l6ZTogMTNweDsgY29sb3I6IHJnYigxMTIsIDExMSwgMTExKTttYXJnaW4tYm90dG9tOiAzcHg7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbiAgLnBfbG9jYXRpb257Zm9udC1zaXplOiAxM3B4O21hcmdpbi1sZWZ0OiA0cHg7bWFyZ2luLXRvcDogM3B4O21hcmdpbi1ib3R0b206IDNweDt9XHJcbiAgLnBfbG9jYXRpb24gaW9uLWljb257Y29sb3I6IHJnYigxMDAsIDE1MiwgMjMxKTttYXJnaW4tcmlnaHQ6IDVweDtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O31cclxuICAucF9wcmljZXtmb250LXNpemU6IDEzcHg7bWFyZ2luLWxlZnQ6IDVweDttYXJnaW4tdG9wOiAzcHg7bWFyZ2luLWJvdHRvbTogM3B4O2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7O31cclxuICAucF90aW1le2ZvbnQtc2l6ZTogMTNweDttYXJnaW4tbGVmdDogNXB4O21hcmdpbi10b3A6IDNweDtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50OyB9XHJcbiAgLmNhcmRfY29udGVudHttYXJnaW46IDVweDt9XHJcbiAgLnJhdGluZ19zdGFye2NvbG9yOiNmOWMwMTE7Zm9udC1zaXplOiAxM3B4O21hcmdpbi1sZWZ0OiA1cHg7bWFyZ2luLXRvcDogNXB4O21hcmdpbi1ib3R0b206IDVweDt9XHJcbiAgLnJhdGluZ19udW1iZXJ7Y29sb3I6IHJnYigxMTQsIDExMiwgMTEyKTsgZm9udC1zaXplOiAxM3B4O2ZvbnQtd2VpZ2h0OiBib2xkO21hcmdpbi1sZWZ0OiA1cHg7bWFyZ2luLXRvcDogNXB4O30iXX0= */");

/***/ }),

/***/ 5799:
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/classbooking/classbooking.component.html ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">Class Booking</ion-label></ion-row>\n         </div>\n\n    \n\n      \n          \n   \n      </div>\n    </div>\n  \n    <ion-list class=\"list_container\">\n      <ion-row class=\"list_row\" (click)=\"detail_page()\" *ngFor=\"let card of list \">\n      \n         <ion-col size=5>\n         \n            <img style=\"height: 137px;border-radius: 5px;margin-top: 7px;\" src=\"../../../assets/sample.jpg\">\n    \n         </ion-col>\n\n         <ion-col size=7>\n          <ion-row><label class=\"p_title\">{{card}}</label></ion-row>\n          <ion-row> <label class=\"p_sub_title\">Marcus</label></ion-row>\n          <ion-row> <label class=\"p_location\"><ion-icon name=\"location-outline\"></ion-icon>New Daily, India</label></ion-row>\n          <ion-row> <label class=\"p_price\">$4000.00</label></ion-row>\n          <ion-row> <label class=\"p_time\"><ion-icon name=\"calendar-number-outline\"></ion-icon> Monday - Sunday</label></ion-row>\n          <ion-row><ion-icon class=\"rating_star\" *ngFor=\"let item of list;let i = index\" [name]=\"condition <= i? 'star-outline' :'star' \">\n          </ion-icon> <label class=\"rating_number\">2.2</label></ion-row>\n        </ion-col>\n\n      </ion-row>\n     \n    </ion-list>\n   \n  \n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_classbooking_classbooking_module_ts.js.map