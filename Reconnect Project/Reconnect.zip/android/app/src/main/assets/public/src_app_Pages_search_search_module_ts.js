(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_search_search_module_ts"],{

/***/ 8932:
/*!*******************************************************!*\
  !*** ./src/app/Pages/search/search-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchPageRoutingModule": () => (/* binding */ SearchPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _search_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search.component */ 1881);




const routes = [
    {
        path: '',
        component: _search_component__WEBPACK_IMPORTED_MODULE_0__.SearchComponent,
    }
];
let SearchPageRoutingModule = class SearchPageRoutingModule {
};
SearchPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], SearchPageRoutingModule);



/***/ }),

/***/ 1881:
/*!**************************************************!*\
  !*** ./src/app/Pages/search/search.component.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchComponent": () => (/* binding */ SearchComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_search_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./search.component.html */ 3495);
/* harmony import */ var _search_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./search.component.css */ 3098);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let SearchComponent = class SearchComponent {
    constructor() { }
    ngOnInit() {
    }
};
SearchComponent.ctorParameters = () => [];
SearchComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-search',
        template: _raw_loader_search_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_search_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SearchComponent);



/***/ }),

/***/ 4322:
/*!***********************************************!*\
  !*** ./src/app/Pages/search/search.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchPageModule": () => (/* binding */ SearchPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _search_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./search.component */ 1881);
/* harmony import */ var _search_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./search-routing.module */ 8932);







let SearchPageModule = class SearchPageModule {
};
SearchPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _search_routing_module__WEBPACK_IMPORTED_MODULE_1__.SearchPageRoutingModule
        ],
        declarations: [_search_component__WEBPACK_IMPORTED_MODULE_0__.SearchComponent]
    })
], SearchPageModule);



/***/ }),

/***/ 3098:
/*!***************************************************!*\
  !*** ./src/app/Pages/search/search.component.css ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 130px; background:url('gym_booking.jpg');--background-repeat: no-repeat;\r\n  --background-size: cover;  background-size: cover;}\r\n.header_overlay{background:#20978f69;height: 130px;}\r\n.icon_conatiner{padding-top: 10px;}\r\nion-back-button{\r\n  --color: white;\r\n}\r\n.header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n.right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlYXJjaC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGVBQWUsV0FBVyxDQUFDLGFBQWEsRUFBRSxpQ0FBK0MsQ0FBQyw4QkFBOEI7RUFDdEgsd0JBQXdCLEdBQUcsc0JBQXNCLENBQUM7QUFDcEQsZ0JBQWdCLG9CQUFvQixDQUFDLGFBQWEsQ0FBQztBQUNuRCxnQkFBZ0IsaUJBQWlCLENBQUM7QUFDbEM7RUFDRSxjQUFjO0FBQ2hCO0FBQ0EsY0FBYyxXQUFXLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLHFDQUFxQyxDQUFDLGVBQWUsRUFBRTtBQUNoSCxZQUFZLFdBQVcsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDO0FBQ3hELFlBQVksV0FBVyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUM7QUFDMUUsWUFBWSxXQUFXLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQyIsImZpbGUiOiJzZWFyY2guY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJfYmFubmVye3dpZHRoOiAxMDAlO2hlaWdodDogMTMwcHg7IGJhY2tncm91bmQ6dXJsKC4uLy4uLy4uL2Fzc2V0cy9neW1fYm9va2luZy5qcGcpOy0tYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAtLWJhY2tncm91bmQtc2l6ZTogY292ZXI7ICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO31cclxuLmhlYWRlcl9vdmVybGF5e2JhY2tncm91bmQ6IzIwOTc4ZjY5O2hlaWdodDogMTMwcHg7fVxyXG4uaWNvbl9jb25hdGluZXJ7cGFkZGluZy10b3A6IDEwcHg7fVxyXG5pb24tYmFjay1idXR0b257XHJcbiAgLS1jb2xvcjogd2hpdGU7XHJcbn1cclxuLmhlYWRlcl90aXRsZXtjb2xvcjogI2ZmZjt0ZXh0LWFsaWduOiBjZW50ZXI7d2lkdGg6IDEwMCU7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtmb250LXNpemU6IDE4cHg7O31cclxuLl9tZW51X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiAwcHggMHB4O2ZvbnQtc2l6ZTogMzBweDt9ICAgXHJcbi5fY2FydF9pY29ue2NvbG9yOiAjZmZmO21hcmdpbjogOHB4IDBweDtmb250LXNpemU6IDI2cHg7bWFyZ2luLWxlZnQ6IDEwcHg7fVxyXG4ucmlnaHRfbG9nb3t3aWR0aDogMzBweDtoZWlnaHQ6IDM1cHg7ZmxvYXQ6IHJpZ2h0O21hcmdpbi10b3A6IC0xOXB4O21hcmdpbi1yaWdodDogMTVweDt9Il19 */");

/***/ }),

/***/ 3495:
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/search/search.component.html ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">Property Listing</ion-label></ion-row>\n         </div>\n\n    \n\n      \n          \n   \n      </div>\n    </div>\n  \n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_search_search_module_ts.js.map