(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_resetpassword_resetpassword_module_ts"],{

/***/ 499:
/*!*********************************************************************!*\
  !*** ./src/app/Pages/resetpassword/resetpassword-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResetPasswordRoutingModule": () => (/* binding */ ResetPasswordRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _resetpassword_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./resetpassword.component */ 8470);




const routes = [
    {
        path: '',
        component: _resetpassword_component__WEBPACK_IMPORTED_MODULE_0__.ResetpasswordComponent
    }
];
let ResetPasswordRoutingModule = class ResetPasswordRoutingModule {
};
ResetPasswordRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], ResetPasswordRoutingModule);



/***/ }),

/***/ 8470:
/*!****************************************************************!*\
  !*** ./src/app/Pages/resetpassword/resetpassword.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResetpasswordComponent": () => (/* binding */ ResetpasswordComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_resetpassword_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./resetpassword.component.html */ 8441);
/* harmony import */ var _resetpassword_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./resetpassword.component.css */ 2738);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);





let ResetpasswordComponent = class ResetpasswordComponent {
    constructor(router) {
        this.router = router;
        this.password_type = 'password';
        this.email_type = 'text';
    }
    ngOnInit() {
    }
    togglePasswordMode() {
        this.password_type = this.password_type === 'text' ? 'password' : 'text';
    }
    next() {
        this.router.navigate(['/tablinks']);
    }
};
ResetpasswordComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
ResetpasswordComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-resetpassword',
        template: _raw_loader_resetpassword_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_resetpassword_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], ResetpasswordComponent);



/***/ }),

/***/ 9301:
/*!*************************************************************!*\
  !*** ./src/app/Pages/resetpassword/resetpassword.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ResetpasswordModule": () => (/* binding */ ResetpasswordModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _resetpassword_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./resetpassword.component */ 8470);
/* harmony import */ var _resetpassword_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./resetpassword-routing.module */ 499);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);






let ResetpasswordModule = class ResetpasswordModule {
};
ResetpasswordModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_resetpassword_component__WEBPACK_IMPORTED_MODULE_0__.ResetpasswordComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _resetpassword_routing_module__WEBPACK_IMPORTED_MODULE_1__.ResetPasswordRoutingModule
        ]
    })
], ResetpasswordModule);



/***/ }),

/***/ 2738:
/*!*****************************************************************!*\
  !*** ./src/app/Pages/resetpassword/resetpassword.component.css ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".body_container{width: 100%; background:url('login-bg.png');height:  100%;--background-repeat: no-repeat ;--background-size: cover; }\r\n.logo{margin-top: 50px;}\r\n.logo_container{width: auto;margin: 0px auto;display: table;margin-top: 50px;}\r\n.body_overlay{background:#4c919c73;height: 100%;}\r\n.login_container{margin:40px 20px 10px 20px;;}\r\n.input_box{color: #20978F; background-color: white; margin-top: 5px; margin-bottom: 15px;box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);border-radius: 5px;}\r\n.input_lable{margin-top: 10px; color: #fff;font-family:Poppins-Light !important;}\r\n.input_icon{color: #20978F;font-size: 20px;padding: 8px 0px 5px 5px ;}\r\n.input_text{text-indent: 5px;}\r\n._button{ --background-activated:#20978F; width: 100%;margin: 0px auto;  --border-radius: 5px!important; box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);font-family:Poppins-Medium !important; margin-top: 29px; color: #fff; --background: #20978F;font-size: 18px;--border-radius: 6px;display: block;height: 50px;}\r\n._button:hover{--background-hover: #20978F;--background: #20978F;outline: none;}\r\n.forget_lable{font-family:Poppins-Light !important;color: #fff;margin-top: 15px;float: right;text-decoration: none;text-align: center;}\r\n.lower_content {font-family:Poppins-Light !important; padding-bottom: 0 !important;bottom:0px; padding: 5px;margin-top: 30px;  color: #fff;font-size: 14px;float: right;text-decoration: none;text-align: center;}\r\n.footer_pre{font-family:Poppins-Light !important;}\r\n.footer_text{ width: 100%;padding-bottom: 0 !important;position: fixed;bottom:0px; padding: 5px;margin-bottom: 30px; margin-top: 20px; font-family:Poppins-Light !important;color: #fff;font-weight: 500;font-size: 10px;text-align: center;float: right;}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlc2V0cGFzc3dvcmQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnQkFBZ0IsV0FBVyxFQUFFLDhCQUE0QyxDQUFDLGFBQWEsQ0FBQywrQkFBK0IsQ0FBQyx3QkFBd0IsRUFBRTtBQUNsSixNQUFNLGdCQUFnQixDQUFDO0FBQ3ZCLGdCQUFnQixXQUFXLENBQUMsZ0JBQWdCLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDO0FBQzdFLGNBQWMsb0JBQW9CLENBQUMsWUFBWSxDQUFDO0FBQ2hELGlCQUFpQiwwQkFBMEIsRUFBRTtBQUM3QyxXQUFXLGNBQWMsRUFBRSx1QkFBdUIsRUFBRSxlQUFlLEVBQUUsbUJBQW1CLENBQUMsdUNBQXVDLENBQUMsa0JBQWtCLENBQUM7QUFDcEosYUFBYSxnQkFBZ0IsRUFBRSxXQUFXLENBQUMsb0NBQW9DLENBQUM7QUFDaEYsWUFBWSxjQUFjLENBQUMsZUFBZSxDQUFDLHlCQUF5QixDQUFDO0FBQ3JFLFlBQVksZ0JBQWdCLENBQUM7QUFDN0IsVUFBVSw4QkFBOEIsRUFBRSxXQUFXLENBQUMsZ0JBQWdCLEdBQUcsOEJBQThCLEVBQUUsdUNBQXVDLENBQUMscUNBQXFDLEVBQUUsZ0JBQWdCLEVBQUUsV0FBVyxFQUFFLHFCQUFxQixDQUFDLGVBQWUsQ0FBQyxvQkFBb0IsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDO0FBQzlTLGVBQWUsMkJBQTJCLENBQUMscUJBQXFCLENBQUMsYUFBYSxDQUFDO0FBQy9FLGNBQWMsb0NBQW9DLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBa0IsQ0FBQztBQUN0SSxnQkFBZ0Isb0NBQW9DLEVBQUUsNEJBQTRCLENBQUMsVUFBVSxFQUFFLFlBQVksQ0FBQyxnQkFBZ0IsR0FBRyxXQUFXLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBa0IsQ0FBQztBQUNqTixZQUFZLG9DQUFvQyxDQUFDO0FBQ2pELGNBQWMsV0FBVyxDQUFDLDRCQUE0QixDQUFDLGVBQWUsQ0FBQyxVQUFVLEVBQUUsWUFBWSxDQUFDLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLG9DQUFvQyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDIiwiZmlsZSI6InJlc2V0cGFzc3dvcmQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5ib2R5X2NvbnRhaW5lcnt3aWR0aDogMTAwJTsgYmFja2dyb3VuZDp1cmwoLi4vLi4vLi4vYXNzZXRzL2xvZ2luLWJnLnBuZyk7aGVpZ2h0OiAgMTAwJTstLWJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQgOy0tYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsgfVxyXG4ubG9nb3ttYXJnaW4tdG9wOiA1MHB4O31cclxuLmxvZ29fY29udGFpbmVye3dpZHRoOiBhdXRvO21hcmdpbjogMHB4IGF1dG87ZGlzcGxheTogdGFibGU7bWFyZ2luLXRvcDogNTBweDt9XHJcbi5ib2R5X292ZXJsYXl7YmFja2dyb3VuZDojNGM5MTljNzM7aGVpZ2h0OiAxMDAlO31cclxuLmxvZ2luX2NvbnRhaW5lcnttYXJnaW46NDBweCAyMHB4IDEwcHggMjBweDs7fVxyXG4uaW5wdXRfYm94e2NvbG9yOiAjMjA5NzhGOyBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTsgbWFyZ2luLXRvcDogNXB4OyBtYXJnaW4tYm90dG9tOiAxNXB4O2JveC1zaGFkb3c6IDAgNHB4IDhweCAwIHJnYmEoMCwwLDAsMC4yKTtib3JkZXItcmFkaXVzOiA1cHg7fVxyXG4uaW5wdXRfbGFibGV7bWFyZ2luLXRvcDogMTBweDsgY29sb3I6ICNmZmY7Zm9udC1mYW1pbHk6UG9wcGlucy1MaWdodCAhaW1wb3J0YW50O31cclxuLmlucHV0X2ljb257Y29sb3I6ICMyMDk3OEY7Zm9udC1zaXplOiAyMHB4O3BhZGRpbmc6IDhweCAwcHggNXB4IDVweCA7fVxyXG4uaW5wdXRfdGV4dHt0ZXh0LWluZGVudDogNXB4O31cclxuLl9idXR0b257IC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6IzIwOTc4Rjsgd2lkdGg6IDEwMCU7bWFyZ2luOiAwcHggYXV0bzsgIC0tYm9yZGVyLXJhZGl1czogNXB4IWltcG9ydGFudDsgYm94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSgwLDAsMCwwLjIpO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7IG1hcmdpbi10b3A6IDI5cHg7IGNvbG9yOiAjZmZmOyAtLWJhY2tncm91bmQ6ICMyMDk3OEY7Zm9udC1zaXplOiAxOHB4Oy0tYm9yZGVyLXJhZGl1czogNnB4O2Rpc3BsYXk6IGJsb2NrO2hlaWdodDogNTBweDt9XHJcbi5fYnV0dG9uOmhvdmVyey0tYmFja2dyb3VuZC1ob3ZlcjogIzIwOTc4RjstLWJhY2tncm91bmQ6ICMyMDk3OEY7b3V0bGluZTogbm9uZTt9XHJcbi5mb3JnZXRfbGFibGV7Zm9udC1mYW1pbHk6UG9wcGlucy1MaWdodCAhaW1wb3J0YW50O2NvbG9yOiAjZmZmO21hcmdpbi10b3A6IDE1cHg7ZmxvYXQ6IHJpZ2h0O3RleHQtZGVjb3JhdGlvbjogbm9uZTt0ZXh0LWFsaWduOiBjZW50ZXI7fVxyXG4ubG93ZXJfY29udGVudCB7Zm9udC1mYW1pbHk6UG9wcGlucy1MaWdodCAhaW1wb3J0YW50OyBwYWRkaW5nLWJvdHRvbTogMCAhaW1wb3J0YW50O2JvdHRvbTowcHg7IHBhZGRpbmc6IDVweDttYXJnaW4tdG9wOiAzMHB4OyAgY29sb3I6ICNmZmY7Zm9udC1zaXplOiAxNHB4O2Zsb2F0OiByaWdodDt0ZXh0LWRlY29yYXRpb246IG5vbmU7dGV4dC1hbGlnbjogY2VudGVyO31cclxuLmZvb3Rlcl9wcmV7Zm9udC1mYW1pbHk6UG9wcGlucy1MaWdodCAhaW1wb3J0YW50O31cclxuLmZvb3Rlcl90ZXh0eyB3aWR0aDogMTAwJTtwYWRkaW5nLWJvdHRvbTogMCAhaW1wb3J0YW50O3Bvc2l0aW9uOiBmaXhlZDtib3R0b206MHB4OyBwYWRkaW5nOiA1cHg7bWFyZ2luLWJvdHRvbTogMzBweDsgbWFyZ2luLXRvcDogMjBweDsgZm9udC1mYW1pbHk6UG9wcGlucy1MaWdodCAhaW1wb3J0YW50O2NvbG9yOiAjZmZmO2ZvbnQtd2VpZ2h0OiA1MDA7Zm9udC1zaXplOiAxMHB4O3RleHQtYWxpZ246IGNlbnRlcjtmbG9hdDogcmlnaHQ7fVxyXG4iXX0= */");

/***/ }),

/***/ 8441:
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/resetpassword/resetpassword.component.html ***!
  \********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content [fullscreen]=\"true\" >\n    <div class=\"body_container\">\n     <div class=\"body_overlay\">\n         <ion-row>\n             <ion-col size=\"4\" offset=\"4\">\n               <img class=\"logo_container\" src=\"../../../assets/second_logo.png\" alt=\"logo-image\"/>\n             </ion-col>\n        </ion-row>\n        <ion-grid class=\"login_container\">\n        <label class=\"input_lable\">Email / Mobile No</label>\n        <ion-row class=\"input_box\">\n         <ion-col  size=\"1\">\n             <ion-icon class=\"input_icon\" name=\"mail-outline\"></ion-icon>\n         </ion-col>\n         <ion-col size=\"9\">\n            <ion-input class=\"input_text\"  value=\"johndoe@gmail.com\" ></ion-input>\n           </ion-col>\n    </ion-row>\n \n    <label class=\"input_lable\">Old Password</label>\n    <ion-row class=\"input_box\">\n     <ion-col  size=\"1\">\n         <ion-icon  class=\"input_icon\" name=\"lock-closed-outline\"></ion-icon>\n     </ion-col>\n     <ion-col size=\"8.9\">\n        <ion-input class=\"input_text\"  [type]=\"password_type\" ></ion-input>\n       </ion-col>\n       <ion-col  size=\"1\">\n         <ion-icon name=\"eye\" class=\"input_icon\" item-right (click)=\"togglePasswordMode()\"></ion-icon>\n     </ion-col>\n      \n</ion-row>\n  \n<label class=\"input_lable\">New  Password</label>\n<ion-row class=\"input_box\">\n <ion-col  size=\"1\">\n     <ion-icon  class=\"input_icon\" name=\"lock-closed-outline\"></ion-icon>\n </ion-col>\n <ion-col size=\"8.9\">\n    <ion-input class=\"input_text\"  [type]=\"password_type\"></ion-input>\n   </ion-col>\n   <ion-col  size=\"1\">\n     <ion-icon name=\"eye\" class=\"input_icon\" item-right (click)=\"togglePasswordMode()\"></ion-icon>\n </ion-col>\n  \n</ion-row>\n    <ion-button class=\"_button\" (click)=\"next()\" >RESET PASSWORD</ion-button>\n \n   \n \n    \n     \n     </ion-grid>\n   </div>\n \n </div>\n \n <div class=\"footer_text\"><span class=\"footer_pre\">ReConnect</span>@ is part of IFA Group.All Rights Reserved.</div>\n </ion-content>\n \n  ");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_resetpassword_resetpassword_module_ts.js.map