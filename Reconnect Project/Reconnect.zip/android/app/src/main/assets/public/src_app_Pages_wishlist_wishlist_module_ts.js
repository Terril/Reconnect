(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_wishlist_wishlist_module_ts"],{

/***/ 1606:
/*!***********************************************************!*\
  !*** ./src/app/Pages/wishlist/wishlist-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WishlistPageRoutingModule": () => (/* binding */ WishlistPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _wishlist_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./wishlist.component */ 9493);




const routes = [
    {
        path: '',
        component: _wishlist_component__WEBPACK_IMPORTED_MODULE_0__.WishlistComponent,
    }
];
let WishlistPageRoutingModule = class WishlistPageRoutingModule {
};
WishlistPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], WishlistPageRoutingModule);



/***/ }),

/***/ 9493:
/*!******************************************************!*\
  !*** ./src/app/Pages/wishlist/wishlist.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WishlistComponent": () => (/* binding */ WishlistComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_wishlist_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./wishlist.component.html */ 9335);
/* harmony import */ var _wishlist_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./wishlist.component.css */ 5208);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let WishlistComponent = class WishlistComponent {
    constructor() { }
    ngOnInit() {
    }
};
WishlistComponent.ctorParameters = () => [];
WishlistComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-wishlist',
        template: _raw_loader_wishlist_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_wishlist_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], WishlistComponent);



/***/ }),

/***/ 295:
/*!***************************************************!*\
  !*** ./src/app/Pages/wishlist/wishlist.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WishlistPageModule": () => (/* binding */ WishlistPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _wishlist_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./wishlist-routing.module */ 1606);
/* harmony import */ var _wishlist_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./wishlist.component */ 9493);







let WishlistPageModule = class WishlistPageModule {
};
WishlistPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _wishlist_routing_module__WEBPACK_IMPORTED_MODULE_0__.WishlistPageRoutingModule
        ],
        declarations: [_wishlist_component__WEBPACK_IMPORTED_MODULE_1__.WishlistComponent]
    })
], WishlistPageModule);



/***/ }),

/***/ 5208:
/*!*******************************************************!*\
  !*** ./src/app/Pages/wishlist/wishlist.component.css ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 130px; background:url('banner-bg.jpg');--background-repeat: no-repeat;\r\n  --background-size: cover;  background-size: cover;}\r\n.header_overlay{background:#20978f69;height: 130px;}\r\n.icon_conatiner{padding-top: 10px;}\r\nion-back-button{\r\n  --color: white;\r\n}\r\n.header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n.right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n.container_view{margin: 10px;}\r\n.expandable_container{background: #fff;}\r\n.exapandable_view{background-color: #75b1b9;padding: 10px;width: 100%;color:#fff;font-family:Poppins-Medium !important;}\r\n.card_view{height: 100px;padding: 0px;margin: 0px;color: #fff;font-family:Poppins-Medium !important;}\r\n.card_lable_number{font-size: 22px;font-weight: bolder;}\r\n.card_lable_text{font-size: 15px;}\r\n.black_layer{padding: 0px;margin: 10px;}\r\n.card_lable_view{text-align: center;font-size: 9px;width: 100%;}\r\n.total_item{font-family:Poppins-Medium !important;margin: 10px;font-weight: bold;color: #545252;}\r\n.list_container{margin: 5px;}\r\n.list_row{margin: 10px 5px 10px 5px}\r\n.img_icon{width: 50px;height: 50px;}\r\n.p_title{margin-left: 10px;width: 100%; font-size: 13px; color: rgb(85, 83, 83);font-weight: 600;font-family:Poppins-Medium !important;}\r\n.p_sub_title{margin-left: 10px; width: 100%; font-size: 13px; color: rgb(112, 111, 111);font-family:Poppins-Medium !important;}\r\n.p_price{margin-left: 10px;font-size: 13px;margin-top: 3px;font-family:Poppins-Medium !important;}\r\n.save_{\r\nwidth: 120px;\r\n--background-activated: #2fc3e4;\r\nbackground: #2fc3e4;\r\nheight: 32px;\r\n/* font-size: 14px; */\r\nborder-radius: 4px;\r\ncolor: #fff;\r\n  }\r\n._remove\r\n  {\r\n    \r\n    --background-activated: #2fc3e4;\r\n    background: #f44336;\r\n    height: 32px;\r\n    width: 32px;\r\n    margin-left: 20px;\r\n    /* font-size: 14px; */\r\n    border-radius: 4px;\r\n    color: #fff;\r\n  }\r\n.bottom_container {\r\n  position: fixed;\r\n  left: 0;\r\n  bottom: 10px;\r\n  right: 0;\r\n}\r\n._button{margin: 0px auto;\r\nwidth: 90%;\r\n  margin-top: 10px;\r\n  margin-bottom: 10px;\r\n  --background-activated:#20978F;\r\n  display: block;\r\n  --background: #75b1b9;\r\n  font-size: 18px;\r\n  --border-radius: 5px;\r\n  height: 40px;}\r\n.total_{width: 100%;border-top:1px solid #cccccc ;padding: 10px;}\r\n.price_title_bottom{font-family:Poppins-Medium !important;}\r\n.price_title_bottom_value  {font-family:Poppins-Medium !important;color: #47bfd8;} \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndpc2hsaXN0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZUFBZSxXQUFXLENBQUMsYUFBYSxFQUFFLCtCQUE2QyxDQUFDLDhCQUE4QjtFQUNwSCx3QkFBd0IsR0FBRyxzQkFBc0IsQ0FBQztBQUNwRCxnQkFBZ0Isb0JBQW9CLENBQUMsYUFBYSxDQUFDO0FBQ25ELGdCQUFnQixpQkFBaUIsQ0FBQztBQUNsQztFQUNFLGNBQWM7QUFDaEI7QUFDQSxjQUFjLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMscUNBQXFDLENBQUMsZUFBZSxFQUFFO0FBQ2hILFlBQVksV0FBVyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUM7QUFDeEQsWUFBWSxXQUFXLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQztBQUMxRSxZQUFZLFdBQVcsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDO0FBQ3ZGLGdCQUFnQixZQUFZLENBQUM7QUFDN0Isc0JBQXNCLGdCQUFnQixDQUFDO0FBQ3ZDLGtCQUFrQix5QkFBeUIsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxxQ0FBcUMsQ0FBQztBQUN2SCxXQUFXLGFBQWEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxxQ0FBcUMsQ0FBQztBQUNwRyxtQkFBbUIsZUFBZSxDQUFDLG1CQUFtQixDQUFDO0FBQ3ZELGlCQUFpQixlQUFlLENBQUM7QUFDakMsYUFBYSxZQUFZLENBQUMsWUFBWSxDQUFDO0FBQ3ZDLGlCQUFpQixrQkFBa0IsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDO0FBQy9ELFlBQVkscUNBQXFDLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsQ0FBQztBQUNoRyxnQkFBZ0IsV0FBVyxDQUFDO0FBQzVCLFVBQVUseUJBQXlCO0FBQ25DLFVBQVUsV0FBVyxDQUFDLFlBQVksQ0FBQztBQUNuQyxTQUFTLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxlQUFlLEVBQUUsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUMscUNBQXFDLENBQUM7QUFDdkksYUFBYSxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLHlCQUF5QixDQUFDLHFDQUFxQyxDQUFDO0FBQzlILFNBQVMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxxQ0FBcUMsQ0FBQztBQUNqRztBQUNBLFlBQVk7QUFDWiwrQkFBK0I7QUFDL0IsbUJBQW1CO0FBQ25CLFlBQVk7QUFDWixxQkFBcUI7QUFDckIsa0JBQWtCO0FBQ2xCLFdBQVc7RUFDVDtBQUNBOzs7SUFHRSwrQkFBK0I7SUFDL0IsbUJBQW1CO0lBQ25CLFlBQVk7SUFDWixXQUFXO0lBQ1gsaUJBQWlCO0lBQ2pCLHFCQUFxQjtJQUNyQixrQkFBa0I7SUFDbEIsV0FBVztFQUNiO0FBQ0Y7RUFDRSxlQUFlO0VBQ2YsT0FBTztFQUNQLFlBQVk7RUFDWixRQUFRO0FBQ1Y7QUFDQSxTQUFTLGdCQUFnQjtBQUN6QixVQUFVO0VBQ1IsZ0JBQWdCO0VBQ2hCLG1CQUFtQjtFQUNuQiw4QkFBOEI7RUFDOUIsY0FBYztFQUNkLHFCQUFxQjtFQUNyQixlQUFlO0VBQ2Ysb0JBQW9CO0VBQ3BCLFlBQVksQ0FBQztBQUNmLFFBQVEsV0FBVyxDQUFDLDZCQUE2QixDQUFDLGFBQWEsQ0FBQztBQUNoRSxvQkFBb0IscUNBQXFDLENBQUM7QUFDMUQsNEJBQTRCLHFDQUFxQyxDQUFDLGNBQWMsQ0FBQyIsImZpbGUiOiJ3aXNobGlzdC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlcl9iYW5uZXJ7d2lkdGg6IDEwMCU7aGVpZ2h0OiAxMzBweDsgYmFja2dyb3VuZDp1cmwoLi4vLi4vLi4vYXNzZXRzL2Jhbm5lci1iZy5qcGcpOy0tYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAtLWJhY2tncm91bmQtc2l6ZTogY292ZXI7ICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO31cclxuLmhlYWRlcl9vdmVybGF5e2JhY2tncm91bmQ6IzIwOTc4ZjY5O2hlaWdodDogMTMwcHg7fVxyXG4uaWNvbl9jb25hdGluZXJ7cGFkZGluZy10b3A6IDEwcHg7fVxyXG5pb24tYmFjay1idXR0b257XHJcbiAgLS1jb2xvcjogd2hpdGU7XHJcbn1cclxuLmhlYWRlcl90aXRsZXtjb2xvcjogI2ZmZjt0ZXh0LWFsaWduOiBjZW50ZXI7d2lkdGg6IDEwMCU7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtmb250LXNpemU6IDE4cHg7O31cclxuLl9tZW51X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiAwcHggMHB4O2ZvbnQtc2l6ZTogMzBweDt9ICAgXHJcbi5fY2FydF9pY29ue2NvbG9yOiAjZmZmO21hcmdpbjogOHB4IDBweDtmb250LXNpemU6IDI2cHg7bWFyZ2luLWxlZnQ6IDEwcHg7fVxyXG4ucmlnaHRfbG9nb3t3aWR0aDogMzBweDtoZWlnaHQ6IDM1cHg7ZmxvYXQ6IHJpZ2h0O21hcmdpbi10b3A6IC0xOXB4O21hcmdpbi1yaWdodDogMTVweDt9XHJcbi5jb250YWluZXJfdmlld3ttYXJnaW46IDEwcHg7fVxyXG4uZXhwYW5kYWJsZV9jb250YWluZXJ7YmFja2dyb3VuZDogI2ZmZjt9XHJcbi5leGFwYW5kYWJsZV92aWV3e2JhY2tncm91bmQtY29sb3I6ICM3NWIxYjk7cGFkZGluZzogMTBweDt3aWR0aDogMTAwJTtjb2xvcjojZmZmO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7fVxyXG4uY2FyZF92aWV3e2hlaWdodDogMTAwcHg7cGFkZGluZzogMHB4O21hcmdpbjogMHB4O2NvbG9yOiAjZmZmO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7fVxyXG4uY2FyZF9sYWJsZV9udW1iZXJ7Zm9udC1zaXplOiAyMnB4O2ZvbnQtd2VpZ2h0OiBib2xkZXI7fVxyXG4uY2FyZF9sYWJsZV90ZXh0e2ZvbnQtc2l6ZTogMTVweDt9XHJcbi5ibGFja19sYXllcntwYWRkaW5nOiAwcHg7bWFyZ2luOiAxMHB4O31cclxuLmNhcmRfbGFibGVfdmlld3t0ZXh0LWFsaWduOiBjZW50ZXI7Zm9udC1zaXplOiA5cHg7d2lkdGg6IDEwMCU7fVxyXG4udG90YWxfaXRlbXtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O21hcmdpbjogMTBweDtmb250LXdlaWdodDogYm9sZDtjb2xvcjogIzU0NTI1Mjt9XHJcbi5saXN0X2NvbnRhaW5lcnttYXJnaW46IDVweDt9XHJcbi5saXN0X3Jvd3ttYXJnaW46IDEwcHggNXB4IDEwcHggNXB4fVxyXG4uaW1nX2ljb257d2lkdGg6IDUwcHg7aGVpZ2h0OiA1MHB4O31cclxuLnBfdGl0bGV7bWFyZ2luLWxlZnQ6IDEwcHg7d2lkdGg6IDEwMCU7IGZvbnQtc2l6ZTogMTNweDsgY29sb3I6IHJnYig4NSwgODMsIDgzKTtmb250LXdlaWdodDogNjAwO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7fVxyXG4ucF9zdWJfdGl0bGV7bWFyZ2luLWxlZnQ6IDEwcHg7IHdpZHRoOiAxMDAlOyBmb250LXNpemU6IDEzcHg7IGNvbG9yOiByZ2IoMTEyLCAxMTEsIDExMSk7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbi5wX3ByaWNle21hcmdpbi1sZWZ0OiAxMHB4O2ZvbnQtc2l6ZTogMTNweDttYXJnaW4tdG9wOiAzcHg7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbi5zYXZlX3tcclxud2lkdGg6IDEyMHB4O1xyXG4tLWJhY2tncm91bmQtYWN0aXZhdGVkOiAjMmZjM2U0O1xyXG5iYWNrZ3JvdW5kOiAjMmZjM2U0O1xyXG5oZWlnaHQ6IDMycHg7XHJcbi8qIGZvbnQtc2l6ZTogMTRweDsgKi9cclxuYm9yZGVyLXJhZGl1czogNHB4O1xyXG5jb2xvcjogI2ZmZjtcclxuICB9XHJcbiAgLl9yZW1vdmVcclxuICB7XHJcbiAgICBcclxuICAgIC0tYmFja2dyb3VuZC1hY3RpdmF0ZWQ6ICMyZmMzZTQ7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZjQ0MzM2O1xyXG4gICAgaGVpZ2h0OiAzMnB4O1xyXG4gICAgd2lkdGg6IDMycHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICAgIC8qIGZvbnQtc2l6ZTogMTRweDsgKi9cclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gIH1cclxuLmJvdHRvbV9jb250YWluZXIge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICBsZWZ0OiAwO1xyXG4gIGJvdHRvbTogMTBweDtcclxuICByaWdodDogMDtcclxufVxyXG4uX2J1dHRvbnttYXJnaW46IDBweCBhdXRvO1xyXG53aWR0aDogOTAlO1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiMyMDk3OEY7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjNzViMWI5O1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICAtLWJvcmRlci1yYWRpdXM6IDVweDtcclxuICBoZWlnaHQ6IDQwcHg7fVxyXG4udG90YWxfe3dpZHRoOiAxMDAlO2JvcmRlci10b3A6MXB4IHNvbGlkICNjY2NjY2MgO3BhZGRpbmc6IDEwcHg7fVxyXG4ucHJpY2VfdGl0bGVfYm90dG9te2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7fVxyXG4ucHJpY2VfdGl0bGVfYm90dG9tX3ZhbHVlICB7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtjb2xvcjogIzQ3YmZkODt9ICJdfQ== */");

/***/ }),

/***/ 9335:
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/wishlist/wishlist.component.html ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">My WishList</ion-label></ion-row>\n         </div>\n   \n      </div>\n    </div>\n    <ion-row>\n        <label class=\"total_item\">2 Items</label>\n        \n    </ion-row>\n    <ion-list class=\"list_container\">\n        <ion-row class=\"list_row\"  *ngFor=\"let card of [0,1] \">\n        \n           <ion-col size=4>\n           \n              <img style=\" width: 108px; height: 108px;border-radius: 5px;\" src=\"../../../assets/sample.jpg\">\n      \n           </ion-col>\n  \n           <ion-col size=7>\n            <ion-row><label class=\"p_title\">Fit and Lift Gym Center</label></ion-row>\n            <ion-row> <label class=\"p_sub_title\">Marcus</label></ion-row>\n            <ion-row> <label class=\"p_price\">$4000.00</label></ion-row>\n            <ion-row>\n                <ion-col size=7><button class=\"save_\">Add To Cart</button></ion-col>\n                <ion-col size=3 offset=\"1\"><button class=\"_remove\" color=\"danger\" ><ion-icon name=\"trash\"></ion-icon></button></ion-col>\n            </ion-row>\n           \n          </ion-col>\n  \n        </ion-row>\n       \n      </ion-list>\n    \n  \n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_wishlist_wishlist_module_ts.js.map