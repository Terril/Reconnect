(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_offers_offers_module_ts"],{

/***/ 761:
/*!*******************************************************!*\
  !*** ./src/app/Pages/offers/offers-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OffersPageRoutingModule": () => (/* binding */ OffersPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _offers_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./offers.component */ 583);




const routes = [
    {
        path: '',
        component: _offers_component__WEBPACK_IMPORTED_MODULE_0__.OffersComponent,
    }
];
let OffersPageRoutingModule = class OffersPageRoutingModule {
};
OffersPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], OffersPageRoutingModule);



/***/ }),

/***/ 583:
/*!**************************************************!*\
  !*** ./src/app/Pages/offers/offers.component.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OffersComponent": () => (/* binding */ OffersComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_offers_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./offers.component.html */ 1067);
/* harmony import */ var _offers_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./offers.component.css */ 3408);
/* harmony import */ var _offers_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./offers.service */ 3971);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 476);






let OffersComponent = class OffersComponent {
    constructor(api, loadingController) {
        this.api = api;
        this.loadingController = loadingController;
        this.list = new Array(5);
        this.condition = 2;
        this.slideOptsThumbs = {
            slidesPerView: 2.9,
            spaceBetween: 20
        };
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.loading = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: 'Please wait...',
                duration: 2000
            });
            this.get_listing();
        });
    }
    get_listing() {
        this.loading.present();
        this.api._getoffersOfferList().subscribe(data => {
            this.offersList = data.PartnerList;
            this.loading.dismiss();
        });
    }
};
OffersComponent.ctorParameters = () => [
    { type: _offers_service__WEBPACK_IMPORTED_MODULE_2__.OffersService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController }
];
OffersComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-offers',
        template: _raw_loader_offers_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_offers_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], OffersComponent);



/***/ }),

/***/ 4314:
/*!***********************************************!*\
  !*** ./src/app/Pages/offers/offers.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OffersPageModule": () => (/* binding */ OffersPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _offers_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./offers.component */ 583);
/* harmony import */ var _offers_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./offers-routing.module */ 761);







let OffersPageModule = class OffersPageModule {
};
OffersPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _offers_routing_module__WEBPACK_IMPORTED_MODULE_1__.OffersPageRoutingModule
        ],
        declarations: [_offers_component__WEBPACK_IMPORTED_MODULE_0__.OffersComponent]
    })
], OffersPageModule);



/***/ }),

/***/ 3971:
/*!************************************************!*\
  !*** ./src/app/Pages/offers/offers.service.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OffersService": () => (/* binding */ OffersService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 205);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 5304);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);






let OffersService = class OffersService {
    constructor(httpClient) {
        this.httpClient = httpClient;
        this.getPartnerOfferList = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url + "PartnerOfferApi/getPartnerOfferList";
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({ 'Content-Type': 'application/json' })
        };
    }
    _getoffersOfferList() {
        return this.httpClient.get(`${this.getPartnerOfferList}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.handleError));
        ;
    }
    handleError(error) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Error: ${error.error.message}`;
        }
        else {
            // server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.log(errorMessage);
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(errorMessage);
    }
};
OffersService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
OffersService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], OffersService);



/***/ }),

/***/ 3408:
/*!***************************************************!*\
  !*** ./src/app/Pages/offers/offers.component.css ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 130px; background:url('banner-bg.jpg');--background-repeat: no-repeat;\r\n  --background-size: cover;  background-size: cover;}\r\n.header_overlay{background:#20978f69;height: 130px;}\r\n.icon_conatiner{padding-top: 10px;}\r\nion-back-button{\r\n  --color: white;\r\n}\r\n.header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n.right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n.list_container{margin: 5px;}\r\n.list_row{margin: 10px 5px 10px 5px; box-shadow: 0 0px 4px 1px #ddd;border-radius: 5px;}\r\n.img_icon{width: 100px;height: 100px;margin-top: 20px;margin-left: 5px;}\r\n.p_title{margin-left: 11px; width: 100%; font-size: 17px; color:#fff;font-family:Poppins-Medium !important;}\r\n.p_sub_title{margin-left: 11px; width: 100%; font-size: 13px; color:#fff;margin-bottom: 3px;font-family:Poppins-Medium !important;}\r\n.p_location{font-size: 13px;margin-left: 4px;margin-top: 3px;margin-bottom: 3px;}\r\n.p_location ion-icon{color: rgb(100, 152, 231);margin-right: 5px;}\r\n.p_price{font-size: 13px;margin-left: 5px;margin-top: 3px;margin-bottom: 3px;}\r\n.p_time{font-size: 13px;margin-left: 5px;margin-top: 3px; }\r\n.card_content{margin: 5px;}\r\n.rating_star{color:#fbff12;font-size: 13px;margin-left: 5px;padding: 2px;}\r\n.rating_number{ margin-left: 10px;border: 1px solid #ddd; color:#fff; font-size: 13px;padding: 2px;}\r\n.hotel_text{position: absolute;z-index: 999;border: 0px;top: 124px;}\r\n.item_container{position: absolute;\r\n  z-index: 999;\r\n  border: 0px;\r\n  top: 5px;\r\n  bottom: 0px;\r\n  width: 97%;\r\n  height: 200px;\r\n  background: #0000007d;}\r\n.rating_conainer{margin-left: 5px;display: none;}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9mZmVycy5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGVBQWUsV0FBVyxDQUFDLGFBQWEsRUFBRSwrQkFBNkMsQ0FBQyw4QkFBOEI7RUFDcEgsd0JBQXdCLEdBQUcsc0JBQXNCLENBQUM7QUFDcEQsZ0JBQWdCLG9CQUFvQixDQUFDLGFBQWEsQ0FBQztBQUNuRCxnQkFBZ0IsaUJBQWlCLENBQUM7QUFDbEM7RUFDRSxjQUFjO0FBQ2hCO0FBQ0EsY0FBYyxXQUFXLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDLHFDQUFxQyxDQUFDLGVBQWUsRUFBRTtBQUNoSCxZQUFZLFdBQVcsQ0FBQyxlQUFlLENBQUMsZUFBZSxDQUFDO0FBQ3hELFlBQVksV0FBVyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLENBQUM7QUFDMUUsWUFBWSxXQUFXLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQztBQUN2RixnQkFBZ0IsV0FBVyxDQUFDO0FBQzVCLFVBQVUseUJBQXlCLEVBQUUsOEJBQThCLENBQUMsa0JBQWtCLENBQUM7QUFDdkYsVUFBVSxZQUFZLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDO0FBQ3ZFLFNBQVMsaUJBQWlCLEVBQUUsV0FBVyxFQUFFLGVBQWUsRUFBRSxVQUFVLENBQUMscUNBQXFDLENBQUM7QUFDM0csYUFBYSxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxxQ0FBcUMsQ0FBQztBQUNsSSxZQUFZLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUM7QUFDaEYscUJBQXFCLHlCQUF5QixDQUFDLGlCQUFpQixDQUFDO0FBQ2pFLFNBQVMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQztBQUM3RSxRQUFRLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLEVBQUU7QUFDMUQsY0FBYyxXQUFXLENBQUM7QUFDMUIsYUFBYSxhQUFhLENBQUMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztBQUN6RSxnQkFBZ0IsaUJBQWlCLENBQUMsc0JBQXNCLEVBQUUsVUFBVSxFQUFFLGVBQWUsQ0FBQyxZQUFZLENBQUM7QUFDbkcsWUFBWSxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQztBQUNuRSxnQkFBZ0Isa0JBQWtCO0VBQ2hDLFlBQVk7RUFDWixXQUFXO0VBQ1gsUUFBUTtFQUNSLFdBQVc7RUFDWCxVQUFVO0VBQ1YsYUFBYTtFQUNiLHFCQUFxQixDQUFDO0FBQ3RCLGlCQUFpQixnQkFBZ0IsQ0FBQyxhQUFhLENBQUMiLCJmaWxlIjoib2ZmZXJzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyX2Jhbm5lcnt3aWR0aDogMTAwJTtoZWlnaHQ6IDEzMHB4OyBiYWNrZ3JvdW5kOnVybCguLi8uLi8uLi9hc3NldHMvYmFubmVyLWJnLmpwZyk7LS1iYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gIC0tYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7fVxyXG4uaGVhZGVyX292ZXJsYXl7YmFja2dyb3VuZDojMjA5NzhmNjk7aGVpZ2h0OiAxMzBweDt9XHJcbi5pY29uX2NvbmF0aW5lcntwYWRkaW5nLXRvcDogMTBweDt9XHJcbmlvbi1iYWNrLWJ1dHRvbntcclxuICAtLWNvbG9yOiB3aGl0ZTtcclxufVxyXG4uaGVhZGVyX3RpdGxle2NvbG9yOiAjZmZmO3RleHQtYWxpZ246IGNlbnRlcjt3aWR0aDogMTAwJTtmb250LWZhbWlseTpQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O2ZvbnQtc2l6ZTogMThweDs7fVxyXG4uX21lbnVfaWNvbntjb2xvcjogI2ZmZjttYXJnaW46IDBweCAwcHg7Zm9udC1zaXplOiAzMHB4O30gICBcclxuLl9jYXJ0X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiA4cHggMHB4O2ZvbnQtc2l6ZTogMjZweDttYXJnaW4tbGVmdDogMTBweDt9XHJcbi5yaWdodF9sb2dve3dpZHRoOiAzMHB4O2hlaWdodDogMzVweDtmbG9hdDogcmlnaHQ7bWFyZ2luLXRvcDogLTE5cHg7bWFyZ2luLXJpZ2h0OiAxNXB4O31cclxuLmxpc3RfY29udGFpbmVye21hcmdpbjogNXB4O31cclxuLmxpc3Rfcm93e21hcmdpbjogMTBweCA1cHggMTBweCA1cHg7IGJveC1zaGFkb3c6IDAgMHB4IDRweCAxcHggI2RkZDtib3JkZXItcmFkaXVzOiA1cHg7fVxyXG4uaW1nX2ljb257d2lkdGg6IDEwMHB4O2hlaWdodDogMTAwcHg7bWFyZ2luLXRvcDogMjBweDttYXJnaW4tbGVmdDogNXB4O31cclxuLnBfdGl0bGV7bWFyZ2luLWxlZnQ6IDExcHg7IHdpZHRoOiAxMDAlOyBmb250LXNpemU6IDE3cHg7IGNvbG9yOiNmZmY7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbi5wX3N1Yl90aXRsZXttYXJnaW4tbGVmdDogMTFweDsgd2lkdGg6IDEwMCU7IGZvbnQtc2l6ZTogMTNweDsgY29sb3I6I2ZmZjttYXJnaW4tYm90dG9tOiAzcHg7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDt9XHJcbi5wX2xvY2F0aW9ue2ZvbnQtc2l6ZTogMTNweDttYXJnaW4tbGVmdDogNHB4O21hcmdpbi10b3A6IDNweDttYXJnaW4tYm90dG9tOiAzcHg7fVxyXG4ucF9sb2NhdGlvbiBpb24taWNvbntjb2xvcjogcmdiKDEwMCwgMTUyLCAyMzEpO21hcmdpbi1yaWdodDogNXB4O31cclxuLnBfcHJpY2V7Zm9udC1zaXplOiAxM3B4O21hcmdpbi1sZWZ0OiA1cHg7bWFyZ2luLXRvcDogM3B4O21hcmdpbi1ib3R0b206IDNweDt9XHJcbi5wX3RpbWV7Zm9udC1zaXplOiAxM3B4O21hcmdpbi1sZWZ0OiA1cHg7bWFyZ2luLXRvcDogM3B4OyB9XHJcbi5jYXJkX2NvbnRlbnR7bWFyZ2luOiA1cHg7fVxyXG4ucmF0aW5nX3N0YXJ7Y29sb3I6I2ZiZmYxMjtmb250LXNpemU6IDEzcHg7bWFyZ2luLWxlZnQ6IDVweDtwYWRkaW5nOiAycHg7fVxyXG4ucmF0aW5nX251bWJlcnsgbWFyZ2luLWxlZnQ6IDEwcHg7Ym9yZGVyOiAxcHggc29saWQgI2RkZDsgY29sb3I6I2ZmZjsgZm9udC1zaXplOiAxM3B4O3BhZGRpbmc6IDJweDt9XHJcbi5ob3RlbF90ZXh0e3Bvc2l0aW9uOiBhYnNvbHV0ZTt6LWluZGV4OiA5OTk7Ym9yZGVyOiAwcHg7dG9wOiAxMjRweDt9XHJcbi5pdGVtX2NvbnRhaW5lcntwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgei1pbmRleDogOTk5O1xyXG4gIGJvcmRlcjogMHB4O1xyXG4gIHRvcDogNXB4O1xyXG4gIGJvdHRvbTogMHB4O1xyXG4gIHdpZHRoOiA5NyU7XHJcbiAgaGVpZ2h0OiAyMDBweDtcclxuICBiYWNrZ3JvdW5kOiAjMDAwMDAwN2Q7fVxyXG4gIC5yYXRpbmdfY29uYWluZXJ7bWFyZ2luLWxlZnQ6IDVweDtkaXNwbGF5OiBub25lO30iXX0= */");

/***/ }),

/***/ 1067:
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/offers/offers.component.html ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">Partner Offers</ion-label></ion-row>\n         </div>\n   \n      </div>\n    </div>\n\n    <ion-list class=\"list_container\">\n        <ion-row class=\"list_row\"  *ngFor=\"let item of this.offersList \">\n        \n       \n            <ion-col>\n              <img style=\"height: 200px; width: 100%; border-radius: 5px;\" src=\"../../../assets/Waves.jpg\">\n              <div class=\"item_container\">\n              <div class=\"hotel_text\">\n                    <ion-row><label class=\"p_title\">{{item.PartnerName}}</label></ion-row>\n                    <ion-row> <label class=\"p_sub_title\">25% off</label></ion-row>\n                    <ion-row class=\"rating_conainer\"> <ion-icon class=\"rating_star\" *ngFor=\"let item of list;let i = index\" [name]=\"condition <= i? 'star-outline' :'star' \">\n                    </ion-icon> <label class=\"rating_number\">2.2</label></ion-row>\n                 </div> \n               </div>\n           </ion-col>\n  \n          \n  \n        </ion-row>\n       \n      </ion-list>\n  \n  \n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_offers_offers_module_ts.js.map