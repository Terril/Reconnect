(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_detail-page_detail-page_module_ts"],{

/***/ 2309:
/*!*****************************************************************!*\
  !*** ./src/app/Pages/detail-page/detail-page-routing.module.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPagePageRoutingModule": () => (/* binding */ DetailPagePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _detail_page_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail-page.component */ 509);




const routes = [
    {
        path: '',
        component: _detail_page_component__WEBPACK_IMPORTED_MODULE_0__.DetailPageComponent,
    }
];
let DetailPagePageRoutingModule = class DetailPagePageRoutingModule {
};
DetailPagePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], DetailPagePageRoutingModule);



/***/ }),

/***/ 509:
/*!************************************************************!*\
  !*** ./src/app/Pages/detail-page/detail-page.component.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPageComponent": () => (/* binding */ DetailPageComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_detail_page_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./detail-page.component.html */ 4193);
/* harmony import */ var _detail_page_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail-page.component.css */ 235);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _pophover_pophover_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pophover/pophover.component */ 4098);
/* harmony import */ var _classlisting_popup_popup_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../classlisting/popup/popup.component */ 4648);










let DetailPageComponent = class DetailPageComponent {
    constructor(popoverController, location, router, navCtrl, modalController) {
        this.popoverController = popoverController;
        this.location = location;
        this.router = router;
        this.navCtrl = navCtrl;
        this.modalController = modalController;
        this.condition = 2;
        this.list = new Array(5);
    }
    ngOnInit() {
    }
    back() {
        this.navCtrl.pop();
    }
    addCart() {
        this.router.navigate(['/cart']);
    }
    addwish() {
        this.router.navigate(['/tablinks/wishlist']);
    }
    booking() {
        this.router.navigate(['/booking/1']);
    }
    presentActionSheet() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const myModal = yield this.modalController.create({
                component: _classlisting_popup_popup_component__WEBPACK_IMPORTED_MODULE_3__.PopupComponent,
                cssClass: 'add-booking-modal',
                showBackdrop: true,
                backdropDismiss: false,
            });
            return yield myModal.present();
        });
    }
    presentPopover(ev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _pophover_pophover_component__WEBPACK_IMPORTED_MODULE_2__.PophoverComponent,
                cssClass: 'my-custom-class',
                event: ev,
                translucent: true
            });
            yield popover.present();
            const { role } = yield popover.onDidDismiss();
            console.log('onDidDismiss resolved with role', role);
        });
    }
};
DetailPageComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.PopoverController },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_6__.Location },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController }
];
DetailPageComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-detail-page',
        template: _raw_loader_detail_page_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_detail_page_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DetailPageComponent);



/***/ }),

/***/ 271:
/*!*********************************************************!*\
  !*** ./src/app/Pages/detail-page/detail-page.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPagePageModule": () => (/* binding */ DetailPagePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _detail_page_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail-page.component */ 509);
/* harmony import */ var _detail_page_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail-page-routing.module */ 2309);
/* harmony import */ var _pophover_pophover_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pophover/pophover.component */ 4098);








let DetailPagePageModule = class DetailPagePageModule {
};
DetailPagePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _detail_page_routing_module__WEBPACK_IMPORTED_MODULE_1__.DetailPagePageRoutingModule
        ],
        declarations: [_detail_page_component__WEBPACK_IMPORTED_MODULE_0__.DetailPageComponent, _pophover_pophover_component__WEBPACK_IMPORTED_MODULE_2__.PophoverComponent]
    })
], DetailPagePageModule);



/***/ }),

/***/ 4098:
/*!******************************************************************!*\
  !*** ./src/app/Pages/detail-page/pophover/pophover.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PophoverComponent": () => (/* binding */ PophoverComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_pophover_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./pophover.component.html */ 6423);
/* harmony import */ var _pophover_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./pophover.component.css */ 2904);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);




let PophoverComponent = class PophoverComponent {
    constructor() {
        this.appPages = [
            { title: 'My Profile', url: '/tablinks/profile', icon: 'person' },
            { title: 'Digital card', url: '/folder/Favorites', icon: 'card' },
            { title: 'Avtivity', url: '/folder/Favorites', icon: 'clipboard' },
            { title: 'Vouchers', url: '/folder/Archived', icon: 'gift' },
            { title: 'Help', url: '/folder/Spam', icon: 'help' },
            { title: 'setting', url: '/folder/Spam', icon: 'settings' },
            { title: 'Logout', url: '/folder/Spam', icon: 'log-out' },
        ];
    }
    ngOnInit() {
    }
};
PophoverComponent.ctorParameters = () => [];
PophoverComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-pophover',
        template: _raw_loader_pophover_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_pophover_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], PophoverComponent);



/***/ }),

/***/ 235:
/*!*************************************************************!*\
  !*** ./src/app/Pages/detail-page/detail-page.component.css ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_image{height: 240px;position: absolute;width: 100%;}\r\n.app_toolbar{ --background: #20989000;}\r\n.bar_header {\r\n    border: 0px !important;\r\n    border-bottom-color: transparent !important;\r\n    background-image: none !important;\r\n    border-bottom: none !important;\r\n}\r\n.info_icon\r\n{\r\n    color: #fff;\r\n    background: #20988f;\r\n    border-radius: 5px;\r\n    padding: 5px;\r\n    font-size: 21px;\r\n    margin-left: 10px;\r\n}\r\n.toolbar_buttons{color: #fff;\r\n    background: #20988f;\r\n    border-radius: 5px;\r\n    padding: 5px;\r\n    font-size: 21px;\r\n    margin-left: 10px;}\r\n.container_box\r\n {\r\n    height: 200px;\r\n    background: #fff;\r\n    position: relative;\r\n    bottom: 63px;\r\n    border-top-left-radius: 12px;\r\n    border-top-right-radius: 12px;\r\n }\r\n.rating_star{color:#f9c011;font-size: 16px;margin-left: 5px;margin-top: 5px;margin-bottom: 5px;}\r\n.rating_number{color: rgb(114, 112, 112); font-size: 15px;font-weight: bold;margin-left: 5px;margin-top: 5px;}\r\n.p_price{font-size: 18px;margin-left: 5px;margin-top: 5px;margin-bottom: 5px;font-family: Poppins-Mediam!important;}\r\n.primary_lables{margin-top: 30px;}\r\n.p_location{font-size: 14px;margin-left: 4px;margin-top: 3px;margin-bottom: 3px;color: gray;}\r\n.p_title{margin: 5px; width: 100%; font-size: 18px; color: rgb(85, 83, 83);font-weight: 600;font-family: Poppins-Mediam!important;}\r\n.p_time{font-size: 14px;margin-left: 5px;margin-top: 3px;font-family: Poppins-Mediam!important;}\r\n.divder{height: 1px;background-color:#ddd;margin-top: 10px;}\r\n.featured_lable{    padding: 5px;\r\n    background: #28aebb;\r\n    color: #fff;\r\n    font-size: 12px;\r\n    border-radius: 50px;\r\n    margin-top: 6px;\r\n    display: block;\r\n    text-align: center;}\r\n.detail_container{margin: 10px;}\r\n.login_button{    width: 89%;\r\n        margin: 0px auto;\r\n        margin-top: 10px;\r\n        margin-bottom: 10px;\r\n        display: block;\r\n        --background: #28aebb;\r\n        font-size: 18px;\r\n        --border-radius: 5px;\r\n        height: 2.5em;}\r\n.login_button:hover{--background-hover: #28aebb;}\r\n.detail_icon{font-size: 14px;color:#28aebb;margin-right: 5px;}\r\n.detail_name{font-size: 14px; color: rgb(85, 83, 83);font-family: Poppins-Mediam!important;}\r\n.detail_value{float: right;font-size: 14px;color: rgb(85, 83, 83);font-family: Poppins-Mediam!important;}\r\n.bottom_text{color: #28aebb;font-family: Poppins-Mediam!important;margin-left: 20px;}  \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbC1wYWdlLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsY0FBYyxhQUFhLENBQUMsa0JBQWtCLENBQUMsV0FBVyxDQUFDO0FBQzNELGNBQWMsdUJBQXVCLENBQUM7QUFDdEM7SUFDSSxzQkFBc0I7SUFDdEIsMkNBQTJDO0lBQzNDLGlDQUFpQztJQUNqQyw4QkFBOEI7QUFDbEM7QUFDQTs7SUFFSSxXQUFXO0lBQ1gsbUJBQW1CO0lBQ25CLGtCQUFrQjtJQUNsQixZQUFZO0lBQ1osZUFBZTtJQUNmLGlCQUFpQjtBQUNyQjtBQUNBLGlCQUFpQixXQUFXO0lBQ3hCLG1CQUFtQjtJQUNuQixrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLGVBQWU7SUFDZixpQkFBaUIsQ0FBQztBQUNyQjs7SUFFRyxhQUFhO0lBQ2IsZ0JBQWdCO0lBQ2hCLGtCQUFrQjtJQUNsQixZQUFZO0lBQ1osNEJBQTRCO0lBQzVCLDZCQUE2QjtDQUNoQztBQUNBLGFBQWEsYUFBYSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsa0JBQWtCLENBQUM7QUFDaEcsZUFBZSx5QkFBeUIsRUFBRSxlQUFlLENBQUMsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxDQUFDO0FBQzdHLFNBQVMsZUFBZSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQyxxQ0FBcUMsQ0FBQztBQUNuSCxnQkFBZ0IsZ0JBQWdCLENBQUM7QUFDakMsWUFBWSxlQUFlLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsQ0FBQztBQUM1RixTQUFTLFdBQVcsRUFBRSxXQUFXLEVBQUUsZUFBZSxFQUFFLHNCQUFzQixDQUFDLGdCQUFnQixDQUFDLHFDQUFxQyxDQUFDO0FBQ2xJLFFBQVEsZUFBZSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxxQ0FBcUMsQ0FBQztBQUMvRixRQUFRLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxnQkFBZ0IsQ0FBQztBQUMzRCxvQkFBb0IsWUFBWTtJQUM1QixtQkFBbUI7SUFDbkIsV0FBVztJQUNYLGVBQWU7SUFDZixtQkFBbUI7SUFDbkIsZUFBZTtJQUNmLGNBQWM7SUFDZCxrQkFBa0IsQ0FBQztBQUNuQixrQkFBa0IsWUFBWSxDQUFDO0FBQy9CLGtCQUFrQixVQUFVO1FBQ3hCLGdCQUFnQjtRQUNoQixnQkFBZ0I7UUFDaEIsbUJBQW1CO1FBQ25CLGNBQWM7UUFDZCxxQkFBcUI7UUFDckIsZUFBZTtRQUNmLG9CQUFvQjtRQUNwQixhQUFhLENBQUM7QUFDdEIsb0JBQW9CLDJCQUEyQixDQUFDO0FBQ2hELGFBQWEsZUFBZSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQztBQUM3RCxhQUFhLGVBQWUsRUFBRSxzQkFBc0IsQ0FBQyxxQ0FBcUMsQ0FBQztBQUMzRixjQUFjLFlBQVksQ0FBQyxlQUFlLENBQUMsc0JBQXNCLENBQUMscUNBQXFDLENBQUM7QUFDeEcsYUFBYSxjQUFjLENBQUMscUNBQXFDLENBQUMsaUJBQWlCLENBQUMiLCJmaWxlIjoiZGV0YWlsLXBhZ2UuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJfaW1hZ2V7aGVpZ2h0OiAyNDBweDtwb3NpdGlvbjogYWJzb2x1dGU7d2lkdGg6IDEwMCU7fVxyXG4uYXBwX3Rvb2xiYXJ7IC0tYmFja2dyb3VuZDogIzIwOTg5MDAwO31cclxuLmJhcl9oZWFkZXIge1xyXG4gICAgYm9yZGVyOiAwcHggIWltcG9ydGFudDtcclxuICAgIGJvcmRlci1ib3R0b20tY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItYm90dG9tOiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuLmluZm9faWNvblxyXG57XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJhY2tncm91bmQ6ICMyMDk4OGY7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICBmb250LXNpemU6IDIxcHg7XHJcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcclxufVxyXG4udG9vbGJhcl9idXR0b25ze2NvbG9yOiAjZmZmO1xyXG4gICAgYmFja2dyb3VuZDogIzIwOTg4ZjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIGZvbnQtc2l6ZTogMjFweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O31cclxuIC5jb250YWluZXJfYm94XHJcbiB7XHJcbiAgICBoZWlnaHQ6IDIwMHB4O1xyXG4gICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGJvdHRvbTogNjNweDtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDEycHg7XHJcbiAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMTJweDtcclxuIH1cclxuIC5yYXRpbmdfc3Rhcntjb2xvcjojZjljMDExO2ZvbnQtc2l6ZTogMTZweDttYXJnaW4tbGVmdDogNXB4O21hcmdpbi10b3A6IDVweDttYXJnaW4tYm90dG9tOiA1cHg7fVxyXG4ucmF0aW5nX251bWJlcntjb2xvcjogcmdiKDExNCwgMTEyLCAxMTIpOyBmb250LXNpemU6IDE1cHg7Zm9udC13ZWlnaHQ6IGJvbGQ7bWFyZ2luLWxlZnQ6IDVweDttYXJnaW4tdG9wOiA1cHg7fVxyXG4ucF9wcmljZXtmb250LXNpemU6IDE4cHg7bWFyZ2luLWxlZnQ6IDVweDttYXJnaW4tdG9wOiA1cHg7bWFyZ2luLWJvdHRvbTogNXB4O2ZvbnQtZmFtaWx5OiBQb3BwaW5zLU1lZGlhbSFpbXBvcnRhbnQ7fSAgXHJcbi5wcmltYXJ5X2xhYmxlc3ttYXJnaW4tdG9wOiAzMHB4O30gXHJcbi5wX2xvY2F0aW9ue2ZvbnQtc2l6ZTogMTRweDttYXJnaW4tbGVmdDogNHB4O21hcmdpbi10b3A6IDNweDttYXJnaW4tYm90dG9tOiAzcHg7Y29sb3I6IGdyYXk7fVxyXG4ucF90aXRsZXttYXJnaW46IDVweDsgd2lkdGg6IDEwMCU7IGZvbnQtc2l6ZTogMThweDsgY29sb3I6IHJnYig4NSwgODMsIDgzKTtmb250LXdlaWdodDogNjAwO2ZvbnQtZmFtaWx5OiBQb3BwaW5zLU1lZGlhbSFpbXBvcnRhbnQ7fVxyXG4ucF90aW1le2ZvbnQtc2l6ZTogMTRweDttYXJnaW4tbGVmdDogNXB4O21hcmdpbi10b3A6IDNweDtmb250LWZhbWlseTogUG9wcGlucy1NZWRpYW0haW1wb3J0YW50O31cclxuLmRpdmRlcntoZWlnaHQ6IDFweDtiYWNrZ3JvdW5kLWNvbG9yOiNkZGQ7bWFyZ2luLXRvcDogMTBweDt9XHJcbi5mZWF0dXJlZF9sYWJsZXsgICAgcGFkZGluZzogNXB4O1xyXG4gICAgYmFja2dyb3VuZDogIzI4YWViYjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIG1hcmdpbi10b3A6IDZweDtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO31cclxuICAgIC5kZXRhaWxfY29udGFpbmVye21hcmdpbjogMTBweDt9XHJcbiAgICAubG9naW5fYnV0dG9ueyAgICB3aWR0aDogODklO1xyXG4gICAgICAgIG1hcmdpbjogMHB4IGF1dG87XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogIzI4YWViYjtcclxuICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgICAgLS1ib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgaGVpZ2h0OiAyLjVlbTt9XHJcbi5sb2dpbl9idXR0b246aG92ZXJ7LS1iYWNrZ3JvdW5kLWhvdmVyOiAjMjhhZWJiO31cclxuLmRldGFpbF9pY29ue2ZvbnQtc2l6ZTogMTRweDtjb2xvcjojMjhhZWJiO21hcmdpbi1yaWdodDogNXB4O31cclxuLmRldGFpbF9uYW1le2ZvbnQtc2l6ZTogMTRweDsgY29sb3I6IHJnYig4NSwgODMsIDgzKTtmb250LWZhbWlseTogUG9wcGlucy1NZWRpYW0haW1wb3J0YW50O30gICAgXHJcbi5kZXRhaWxfdmFsdWV7ZmxvYXQ6IHJpZ2h0O2ZvbnQtc2l6ZTogMTRweDtjb2xvcjogcmdiKDg1LCA4MywgODMpO2ZvbnQtZmFtaWx5OiBQb3BwaW5zLU1lZGlhbSFpbXBvcnRhbnQ7fVxyXG4uYm90dG9tX3RleHR7Y29sb3I6ICMyOGFlYmI7Zm9udC1mYW1pbHk6IFBvcHBpbnMtTWVkaWFtIWltcG9ydGFudDttYXJnaW4tbGVmdDogMjBweDt9ICAiXX0= */");

/***/ }),

/***/ 2904:
/*!*******************************************************************!*\
  !*** ./src/app/Pages/detail-page/pophover/pophover.component.css ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".menu_container{background: #fff;}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBvcGhvdmVyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCLGdCQUFnQixDQUFDIiwiZmlsZSI6InBvcGhvdmVyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWVudV9jb250YWluZXJ7YmFja2dyb3VuZDogI2ZmZjt9Il19 */");

/***/ }),

/***/ 4193:
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/detail-page/detail-page.component.html ***!
  \****************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-header style=\"position: absolute;\"  class=\"ion-no-border\">\n   \n    <ion-toolbar class=\"app_toolbar\">\n      <ion-buttons (click)=\"back()\" slot=\"start\">\n        <ion-icon class=\"toolbar_buttons\" name=\"arrow-back\"></ion-icon>\n    </ion-buttons>\n      \n    <ion-buttons slot=\"primary\" style=\"display: none;\" (click)=\"presentPopover($event)\">\n        <div class=\"ion-activatable\">\n            <ion-icon class=\"info_icon\" name=\"ellipsis-vertical-outline\"></ion-icon>\n            \n            <ion-ripple-effect type=\"unbounded\"></ion-ripple-effect>\n          </div>\n    </ion-buttons>\n     \n    </ion-toolbar>\n\n  </ion-header>\n<ion-content [fullscreen]=\"true\">\n    <img  src=\"https://static.toiimg.com/thumb/msid-78118340,imgsize-896783,width-800,height-600,resizemode-75/78118340.jpg\">\n    <div class=\"container_box\">\n     \n     <ion-row>\n        <ion-col size=8 >\n            <ion-row><label class=\"p_title\">Fit and Lift Gym Center</label></ion-row>\n            <ion-row><label class=\"p_location\"><ion-icon name=\"location-outline\"></ion-icon>New Daily, India</label></ion-row>\n        </ion-col> \n        <ion-col size=3><label class=\"featured_lable\">Featured</label></ion-col>\n        \n        </ion-row>\n        <ion-row>\n          <ion-col size=8 > <ion-row><ion-icon class=\"rating_star\" *ngFor=\"let item of list;let i = index\" [name]=\"condition <= i? 'star-outline' :'star' \">\n          </ion-icon> <label class=\"rating_number\">2.2</label></ion-row></ion-col>\n          <ion-col size=4><label class=\"p_price\">$4000.00</label></ion-col>\n   </ion-row>  \n     <ion-row class=\"divder\"> </ion-row>\n     \n      \n      <div class=\"detail_container\">\n        <ion-row>\n            <ion-col size=5><ion-label class=\"detail_name\" ><ion-icon class=\"detail_icon\" name=\"accessibility-outline\"></ion-icon> Class Name</ion-label></ion-col> \n            <ion-col size=6><ion-label class=\"detail_value\" >Dumbel Crunch</ion-label></ion-col> \n           </ion-row>\n           <ion-row>\n            <ion-col size=5><ion-label class=\"detail_name\" ><ion-icon class=\"detail_icon\" name=\"time-outline\"></ion-icon> Time</ion-label></ion-col> \n            <ion-col size=6><ion-label class=\"detail_value\" >6:00 AM - 10:00 PM</ion-label></ion-col> \n           </ion-row>\n           <ion-row>\n            <ion-col size=5><ion-label class=\"detail_name\" ><ion-icon class=\"detail_icon\" name=\"calendar-number-outline\"></ion-icon> Days</ion-label></ion-col> \n            <ion-col size=6><ion-label class=\"detail_value\" >Monday To Sunday</ion-label></ion-col> \n           </ion-row>\n           <ion-row>\n            <ion-col size=5><ion-label class=\"detail_name\" ><ion-icon class=\"detail_icon\" name=\"bag-check-outline\"></ion-icon> Seats</ion-label></ion-col> \n            <ion-col size=6><ion-label class=\"detail_value\" >100</ion-label></ion-col> \n           </ion-row>\n           <ion-row>\n            <ion-col size=5><ion-label class=\"detail_name\" ><ion-icon class=\"detail_icon\" name=\"checkmark-done-outline\"></ion-icon> Booked</ion-label></ion-col> \n            <ion-col size=6><ion-label class=\"detail_value\" >60</ion-label></ion-col> \n           </ion-row>\n           <ion-row>\n            <ion-col size=5><ion-label class=\"detail_name\" ><ion-icon class=\"detail_icon\" name=\"hourglass-outline\"></ion-icon> Wating</ion-label></ion-col> \n            <ion-col size=6><ion-label class=\"detail_value\" >10</ion-label></ion-col> \n           </ion-row>\n           <ion-row>\n            <ion-col size=5><ion-label class=\"detail_name\" ><ion-icon class=\"detail_icon\" name=\"thumbs-up-outline\"></ion-icon> Available</ion-label></ion-col> \n            <ion-col size=6><ion-label class=\"detail_value\" >30</ion-label></ion-col> \n           </ion-row>     \n      </div>      \n          \n      <ion-row class=\"divder\"> </ion-row>\n            \n      <ion-button class=\"login_button\" (click)=\"presentActionSheet()\" >Book Now</ion-button>\n\n      <ion-row>\n        <ion-col ><label class=\"bottom_text\" (click)=\"addCart()\"  >Add to Cart</label> </ion-col>\n        <ion-col offset=2><label class=\"bottom_text\" (click)=\"addwish()\" >Add to Wishlist</label></ion-col>\n      </ion-row>\n            \n            \n      \n            \n   \n    </div>\n\n</ion-content>\n");

/***/ }),

/***/ 6423:
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/detail-page/pophover/pophover.component.html ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<div class=\"menu_container\"> \n    <ion-list>\n\n    <ion-item  *ngFor=\"let p of appPages; let i = index\" routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\" detail=\"false\" routerLinkActive=\"selected\">\n      <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\n      <ion-label>{{ p.title }}</ion-label>\n    </ion-item>\n\n</ion-list>\n  </div>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_detail-page_detail-page_module_ts.js.map