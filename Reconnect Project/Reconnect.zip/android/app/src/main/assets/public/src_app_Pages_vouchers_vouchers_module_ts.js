(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_vouchers_vouchers_module_ts"],{

/***/ 6771:
/*!***************************************************!*\
  !*** ./src/app/Pages/vouchers/qr/qr.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QRComponent": () => (/* binding */ QRComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_qr_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./qr.component.html */ 9361);
/* harmony import */ var _qr_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./qr.component.css */ 8915);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 476);






let QRComponent = class QRComponent {
    constructor(modalController, navParams) {
        this.modalController = modalController;
        this.navParams = navParams;
    }
    ngOnInit() {
        this.qrImage = "data:image/jpeg;base64," + this.navParams.get('qr');
    }
    cancel() {
        this.modalController.dismiss({
            'dismissed': true
        });
    }
};
QRComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavParams }
];
QRComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-qr',
        template: _raw_loader_qr_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_qr_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], QRComponent);



/***/ }),

/***/ 1319:
/*!***********************************************************!*\
  !*** ./src/app/Pages/vouchers/vouchers-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VouchersRoutingModule": () => (/* binding */ VouchersRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _vouchers_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vouchers.component */ 7292);




const routes = [{
        path: "",
        component: _vouchers_component__WEBPACK_IMPORTED_MODULE_0__.VouchersComponent
    }];
let VouchersRoutingModule = class VouchersRoutingModule {
};
VouchersRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], VouchersRoutingModule);



/***/ }),

/***/ 7292:
/*!******************************************************!*\
  !*** ./src/app/Pages/vouchers/vouchers.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VouchersComponent": () => (/* binding */ VouchersComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_vouchers_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./vouchers.component.html */ 220);
/* harmony import */ var _vouchers_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./vouchers.component.css */ 5145);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _qr_qr_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./qr/qr.component */ 6771);
/* harmony import */ var _vouchers_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./vouchers.service */ 4021);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);







let VouchersComponent = class VouchersComponent {
    constructor(modalController, api, loadingController) {
        this.modalController = modalController;
        this.api = api;
        this.loadingController = loadingController;
        this.list = new Array(5);
        this.condition = 2;
        this.slideOptsThumbs = {
            slidesPerView: 2.9,
            spaceBetween: 6
        };
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.loading = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: 'Please wait...',
                duration: 2000
            });
            this.get_listing();
        });
    }
    get_listing() {
        this.loading.present();
        this.api._getVoucherList().subscribe(data => {
            this.vouchersList = data.VoucherList;
            this.loading.dismiss();
            console.log(this.vouchersList);
        });
    }
    opn_qr(qr) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const myModal = yield this.modalController.create({
                component: _qr_qr_component__WEBPACK_IMPORTED_MODULE_2__.QRComponent,
                cssClass: 'qr-code-modal',
                showBackdrop: true,
                componentProps: { qr: qr },
                backdropDismiss: false,
            });
            return yield myModal.present();
        });
    }
};
VouchersComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ModalController },
    { type: _vouchers_service__WEBPACK_IMPORTED_MODULE_3__.VouchersService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController }
];
VouchersComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-vouchers',
        template: _raw_loader_vouchers_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_vouchers_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], VouchersComponent);



/***/ }),

/***/ 3766:
/*!***************************************************!*\
  !*** ./src/app/Pages/vouchers/vouchers.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VouchersModule": () => (/* binding */ VouchersModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _vouchers_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vouchers-routing.module */ 1319);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _vouchers_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./vouchers.component */ 7292);
/* harmony import */ var _qr_qr_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./qr/qr.component */ 6771);







let VouchersModule = class VouchersModule {
};
VouchersModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        declarations: [_vouchers_component__WEBPACK_IMPORTED_MODULE_1__.VouchersComponent, _qr_qr_component__WEBPACK_IMPORTED_MODULE_2__.QRComponent],
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _vouchers_routing_module__WEBPACK_IMPORTED_MODULE_0__.VouchersRoutingModule
        ]
    })
], VouchersModule);



/***/ }),

/***/ 4021:
/*!****************************************************!*\
  !*** ./src/app/Pages/vouchers/vouchers.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VouchersService": () => (/* binding */ VouchersService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 205);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 5304);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);






let VouchersService = class VouchersService {
    constructor(httpClient) {
        this.httpClient = httpClient;
        this.getVoucherList = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url + "VoucherApi/getVoucherList";
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({ 'Content-Type': 'application/json' })
        };
    }
    _getVoucherList() {
        return this.httpClient.get(`${this.getVoucherList}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.handleError));
        ;
    }
    handleError(error) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Error: ${error.error.message}`;
        }
        else {
            // server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.log(errorMessage);
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(errorMessage);
    }
};
VouchersService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
VouchersService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], VouchersService);



/***/ }),

/***/ 8915:
/*!****************************************************!*\
  !*** ./src/app/Pages/vouchers/qr/qr.component.css ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".qr_image\r\n{\r\n    width: 200px;\r\n    height: 200px;\r\n\r\n}\r\n.img_{\r\n    margin-top: 50px;\r\n    text-align: center;\r\n}\r\n.button_container{\r\n    width: 80%;\r\n    margin: 0px auto;\r\n    margin-top: 50px;\r\n}\r\n.action_button_no{ color: #000; --background: #ddd;font-size: 18px;--border-radius: 6px;width: 200px; height:30px}\r\n.action_button_no:hover{color: #000; --background-hover: #ddd;}\r\n.action_button_yes{ color: #fff; --background: #28aebb;font-size: 18px;--border-radius: 6px;width: 200px; height:30px}\r\n.action_button_yes:hover{color: #fff; --background-hover: #28aebb;}\r\n.p_title{width: 100%; text-align: center; display: block;color: rgb(85, 83, 83); margin: 5px 0px; font-weight: 600;font-family: Poppins-Mediam!important;}\r\n.p_sub{width: 100%; text-align: center; display: block;color: rgb(85, 83, 83);font-size: 14px; margin-bottom: 10px;font-family: Poppins-Mediam!important;}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInFyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0lBRUksWUFBWTtJQUNaLGFBQWE7O0FBRWpCO0FBQ0E7SUFDSSxnQkFBZ0I7SUFDaEIsa0JBQWtCO0FBQ3RCO0FBRUE7SUFDSSxVQUFVO0lBQ1YsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtBQUNwQjtBQUVBLG1CQUFtQixXQUFXLEVBQUUsa0JBQWtCLENBQUMsZUFBZSxDQUFDLG9CQUFvQixDQUFDLFlBQVksRUFBRSxXQUFXO0FBQ2pILHdCQUF3QixXQUFXLEVBQUUsd0JBQXdCLENBQUM7QUFFOUQsb0JBQW9CLFdBQVcsRUFBRSxxQkFBcUIsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsWUFBWSxFQUFFLFdBQVc7QUFDckgseUJBQXlCLFdBQVcsRUFBRSwyQkFBMkIsQ0FBQztBQUNsRSxTQUFTLFdBQVcsRUFBRSxrQkFBa0IsRUFBRSxjQUFjLENBQUMsc0JBQXNCLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixDQUFDLHFDQUFxQyxDQUFDO0FBQ3pKLE9BQU8sV0FBVyxFQUFFLGtCQUFrQixFQUFFLGNBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxlQUFlLEVBQUUsbUJBQW1CLENBQUMscUNBQXFDLENBQUMiLCJmaWxlIjoicXIuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5xcl9pbWFnZVxyXG57XHJcbiAgICB3aWR0aDogMjAwcHg7XHJcbiAgICBoZWlnaHQ6IDIwMHB4O1xyXG5cclxufVxyXG4uaW1nX3tcclxuICAgIG1hcmdpbi10b3A6IDUwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5idXR0b25fY29udGFpbmVye1xyXG4gICAgd2lkdGg6IDgwJTtcclxuICAgIG1hcmdpbjogMHB4IGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xyXG59XHJcblxyXG4uYWN0aW9uX2J1dHRvbl9ub3sgY29sb3I6ICMwMDA7IC0tYmFja2dyb3VuZDogI2RkZDtmb250LXNpemU6IDE4cHg7LS1ib3JkZXItcmFkaXVzOiA2cHg7d2lkdGg6IDIwMHB4OyBoZWlnaHQ6MzBweH1cclxuLmFjdGlvbl9idXR0b25fbm86aG92ZXJ7Y29sb3I6ICMwMDA7IC0tYmFja2dyb3VuZC1ob3ZlcjogI2RkZDt9XHJcblxyXG4uYWN0aW9uX2J1dHRvbl95ZXN7IGNvbG9yOiAjZmZmOyAtLWJhY2tncm91bmQ6ICMyOGFlYmI7Zm9udC1zaXplOiAxOHB4Oy0tYm9yZGVyLXJhZGl1czogNnB4O3dpZHRoOiAyMDBweDsgaGVpZ2h0OjMwcHh9XHJcbi5hY3Rpb25fYnV0dG9uX3llczpob3Zlcntjb2xvcjogI2ZmZjsgLS1iYWNrZ3JvdW5kLWhvdmVyOiAjMjhhZWJiO31cclxuLnBfdGl0bGV7d2lkdGg6IDEwMCU7IHRleHQtYWxpZ246IGNlbnRlcjsgZGlzcGxheTogYmxvY2s7Y29sb3I6IHJnYig4NSwgODMsIDgzKTsgbWFyZ2luOiA1cHggMHB4OyBmb250LXdlaWdodDogNjAwO2ZvbnQtZmFtaWx5OiBQb3BwaW5zLU1lZGlhbSFpbXBvcnRhbnQ7fVxyXG4ucF9zdWJ7d2lkdGg6IDEwMCU7IHRleHQtYWxpZ246IGNlbnRlcjsgZGlzcGxheTogYmxvY2s7Y29sb3I6IHJnYig4NSwgODMsIDgzKTtmb250LXNpemU6IDE0cHg7IG1hcmdpbi1ib3R0b206IDEwcHg7Zm9udC1mYW1pbHk6IFBvcHBpbnMtTWVkaWFtIWltcG9ydGFudDt9Il19 */");

/***/ }),

/***/ 5145:
/*!*******************************************************!*\
  !*** ./src/app/Pages/vouchers/vouchers.component.css ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".header_banner{width: 100%;height: 130px; background:url('banner-bg.jpg');--background-repeat: no-repeat;\r\n    --background-size: cover;  background-size: cover;}\r\n  .header_overlay{background:#20978f69;height: 130px;}\r\n  .icon_conatiner{padding-top: 10px;}\r\n  ion-back-button{\r\n    --color: white;\r\n  }\r\n  .header_title{color: #fff;text-align: center;width: 100%;font-family:Poppins-Medium !important;font-size: 18px;;}\r\n  ._menu_icon{color: #fff;margin: 0px 0px;font-size: 30px;}\r\n  ._cart_icon{color: #fff;margin: 8px 0px;font-size: 26px;margin-left: 10px;}\r\n  .right_logo{width: 30px;height: 35px;float: right;margin-top: -19px;margin-right: 15px;}\r\n  .list_container{margin: 20px;}\r\n  .list_row{margin: 10px 5px 10px 5px; box-shadow: 0 0px 4px 1px #ddd;border-radius: 5px;}\r\n  .img_icon{width: 100px;height: 100px;margin-top: 20px;margin-left: 5px;}\r\n  .rating_conainer{margin-left: 5px;}\r\n  .card_cantainer\r\n{\r\n \r\n    display: block;\r\n    margin: 0px;\r\n    border-radius: 0px;\r\n    margin-top: 20px;\r\n\r\n}\r\n  .container {    \r\n    height: 125px;\r\n    width: 125px;\r\n}\r\n  .overlay\r\n{\r\n    background-color: #00000052;\r\n    width: 100%;\r\n    height: 100%;\r\n}\r\n  .class_sliders{padding-left: 15px;}\r\n  .card_lable\r\n{\r\n    color: #fff;\r\n    width: 100%;\r\n    margin: 0px auto;\r\n    margin-top: 46px;\r\n    width: 70px;\r\n    font-weight: 700;\r\n    display: block;\r\n    text-align: center;\r\n}\r\n  .item_container\r\n{\r\n   \r\n   background: url('offer_bg.png');\r\n   background-position: center center;\r\n   height: 160px;\r\n   background-size: cover;\r\n   border-radius: 25px;\r\n   background-repeat: no-repeat;\r\n   box-shadow: 0px 2px 4px #a09a9a;\r\n}\r\n  .section\r\n{\r\n    height: 80px;\r\n    padding-top: 10px;\r\n}\r\n  .dotted_line{\r\n    border-top: 1px dashed #000;\r\n    display: block;\r\n}\r\n  .dot {\r\n    position: absolute;\r\n    top: 75px;\r\n    left: 2px;\r\n    transform: translate(-50%, -50%);\r\n    height: 20px;\r\n    width: 20px;\r\n    border-radius: 150px 150px 0 0;\r\n\r\n    background-color: #fff;\r\n    transform: rotate(90deg);\r\n\r\n}\r\n  .dot1 {\r\n    position: absolute;\r\n    top: 75px;\r\n    right: 2px;\r\n    transform: translate(-50%, -50%);\r\n    height: 20px;\r\n    width: 20px;\r\n    border-radius: 150px 150px 0 0;\r\n    background-color: #fff;\r\n  \r\n    transform: rotate(-90deg);\r\n  \r\n}\r\n  .discount_price{    \r\n    font-family: Poppins-Medium !important;\r\n    font-size: 25px;\r\n    margin-left: 46px;\r\n    text-align: left;\r\n    width: 100%;\r\n    margin-top: 25px;\r\n    font-weight: bold;}\r\n  .offer_title\r\n    {\r\n        font-family: Poppins-Medium !important;\r\n        margin-left: 46px;\r\n        text-align: left;\r\n        margin-top: 20px;\r\n        color: #504e4e;\r\n        width: 100%;\r\n        font-size: 14px;\r\n \r\n\r\n    }\r\n  .offer_title_date\r\n    {\r\n        font-family: Poppins-Medium !important;\r\n        margin-left: 46px;\r\n        text-align: left;\r\n        margin-top: 5px;\r\n        color: #504e4e;\r\n        width: 100%;\r\n        font-size: 12px;\r\n \r\n\r\n    }\r\n  .offer_title span{color: #000;}\r\n  .promotion{  --background-size: cover;background-size: cover;height: 100px;padding: 0px;margin: 0px;}\r\n  .black_layer{height: 100px;    padding: 10px;}\r\n  .card_lable_2{    color: #fff;font-family: Poppins-Mediam!important;font-size: 18px;position: relative;font-weight: bolder;top: 20px;width: 100px;}\r\n  .voucher_lable{    position: absolute;\r\n        left: 22px;\r\n        font-size: 12px;\r\n        font-family: Poppins-Mediam!important;\r\n        top: 20px;} \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInZvdWNoZXJzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZUFBZSxXQUFXLENBQUMsYUFBYSxFQUFFLCtCQUE2QyxDQUFDLDhCQUE4QjtJQUNsSCx3QkFBd0IsR0FBRyxzQkFBc0IsQ0FBQztFQUNwRCxnQkFBZ0Isb0JBQW9CLENBQUMsYUFBYSxDQUFDO0VBQ25ELGdCQUFnQixpQkFBaUIsQ0FBQztFQUNsQztJQUNFLGNBQWM7RUFDaEI7RUFDQSxjQUFjLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMscUNBQXFDLENBQUMsZUFBZSxFQUFFO0VBQ2hILFlBQVksV0FBVyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUM7RUFDeEQsWUFBWSxXQUFXLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxpQkFBaUIsQ0FBQztFQUMxRSxZQUFZLFdBQVcsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLGtCQUFrQixDQUFDO0VBQ3ZGLGdCQUFnQixZQUFZLENBQUM7RUFDL0IsVUFBVSx5QkFBeUIsRUFBRSw4QkFBOEIsQ0FBQyxrQkFBa0IsQ0FBQztFQUN2RixVQUFVLFlBQVksQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUM7RUFHbkUsaUJBQWlCLGdCQUFnQixDQUFDO0VBQ2xDOzs7SUFHQSxjQUFjO0lBQ2QsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixnQkFBZ0I7O0FBRXBCO0VBQ0E7SUFDSSxhQUFhO0lBQ2IsWUFBWTtBQUNoQjtFQUNBOztJQUVJLDJCQUEyQjtJQUMzQixXQUFXO0lBQ1gsWUFBWTtBQUNoQjtFQUNBLGVBQWUsa0JBQWtCLENBQUM7RUFDbEM7O0lBRUksV0FBVztJQUNYLFdBQVc7SUFDWCxnQkFBZ0I7SUFDaEIsZ0JBQWdCO0lBQ2hCLFdBQVc7SUFDWCxnQkFBZ0I7SUFDaEIsY0FBYztJQUNkLGtCQUFrQjtBQUN0QjtFQUVBOzs7R0FHRywrQkFBNkM7R0FDN0Msa0NBQWtDO0dBQ2xDLGFBQWE7R0FDYixzQkFBc0I7R0FDdEIsbUJBQW1CO0dBQ25CLDRCQUE0QjtHQUM1QiwrQkFBK0I7QUFDbEM7RUFDQTs7SUFFSSxZQUFZO0lBQ1osaUJBQWlCO0FBQ3JCO0VBQ0E7SUFDSSwyQkFBMkI7SUFDM0IsY0FBYztBQUNsQjtFQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFNBQVM7SUFDVCxTQUFTO0lBQ1QsZ0NBQWdDO0lBQ2hDLFlBQVk7SUFDWixXQUFXO0lBQ1gsOEJBQThCOztJQUU5QixzQkFBc0I7SUFDdEIsd0JBQXdCOztBQUU1QjtFQUNBO0lBQ0ksa0JBQWtCO0lBQ2xCLFNBQVM7SUFDVCxVQUFVO0lBQ1YsZ0NBQWdDO0lBQ2hDLFlBQVk7SUFDWixXQUFXO0lBQ1gsOEJBQThCO0lBQzlCLHNCQUFzQjs7SUFFdEIseUJBQXlCOztBQUU3QjtFQUNBO0lBQ0ksc0NBQXNDO0lBQ3RDLGVBQWU7SUFDZixpQkFBaUI7SUFDakIsZ0JBQWdCO0lBQ2hCLFdBQVc7SUFDWCxnQkFBZ0I7SUFDaEIsaUJBQWlCLENBQUM7RUFDbEI7O1FBRUksc0NBQXNDO1FBQ3RDLGlCQUFpQjtRQUNqQixnQkFBZ0I7UUFDaEIsZ0JBQWdCO1FBQ2hCLGNBQWM7UUFDZCxXQUFXO1FBQ1gsZUFBZTs7O0lBR25CO0VBQ0E7O1FBRUksc0NBQXNDO1FBQ3RDLGlCQUFpQjtRQUNqQixnQkFBZ0I7UUFDaEIsZUFBZTtRQUNmLGNBQWM7UUFDZCxXQUFXO1FBQ1gsZUFBZTs7O0lBR25CO0VBQ0Esa0JBQWtCLFdBQVcsQ0FBQztFQUU5QixhQUFhLHdCQUF3QixDQUFDLHNCQUFzQixDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDO0VBQ3BHLGFBQWEsYUFBYSxLQUFLLGFBQWEsQ0FBQztFQUM3QyxrQkFBa0IsV0FBVyxDQUFDLHFDQUFxQyxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDO0VBQ2xKLG1CQUFtQixrQkFBa0I7UUFDakMsVUFBVTtRQUNWLGVBQWU7UUFDZixxQ0FBcUM7UUFDckMsU0FBUyxDQUFDIiwiZmlsZSI6InZvdWNoZXJzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyX2Jhbm5lcnt3aWR0aDogMTAwJTtoZWlnaHQ6IDEzMHB4OyBiYWNrZ3JvdW5kOnVybCguLi8uLi8uLi9hc3NldHMvYmFubmVyLWJnLmpwZyk7LS1iYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgLS1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyOyAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjt9XHJcbiAgLmhlYWRlcl9vdmVybGF5e2JhY2tncm91bmQ6IzIwOTc4ZjY5O2hlaWdodDogMTMwcHg7fVxyXG4gIC5pY29uX2NvbmF0aW5lcntwYWRkaW5nLXRvcDogMTBweDt9XHJcbiAgaW9uLWJhY2stYnV0dG9ue1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgfVxyXG4gIC5oZWFkZXJfdGl0bGV7Y29sb3I6ICNmZmY7dGV4dC1hbGlnbjogY2VudGVyO3dpZHRoOiAxMDAlO2ZvbnQtZmFtaWx5OlBvcHBpbnMtTWVkaXVtICFpbXBvcnRhbnQ7Zm9udC1zaXplOiAxOHB4Ozt9XHJcbiAgLl9tZW51X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiAwcHggMHB4O2ZvbnQtc2l6ZTogMzBweDt9ICAgXHJcbiAgLl9jYXJ0X2ljb257Y29sb3I6ICNmZmY7bWFyZ2luOiA4cHggMHB4O2ZvbnQtc2l6ZTogMjZweDttYXJnaW4tbGVmdDogMTBweDt9XHJcbiAgLnJpZ2h0X2xvZ297d2lkdGg6IDMwcHg7aGVpZ2h0OiAzNXB4O2Zsb2F0OiByaWdodDttYXJnaW4tdG9wOiAtMTlweDttYXJnaW4tcmlnaHQ6IDE1cHg7fVxyXG4gIC5saXN0X2NvbnRhaW5lcnttYXJnaW46IDIwcHg7fVxyXG4ubGlzdF9yb3d7bWFyZ2luOiAxMHB4IDVweCAxMHB4IDVweDsgYm94LXNoYWRvdzogMCAwcHggNHB4IDFweCAjZGRkO2JvcmRlci1yYWRpdXM6IDVweDt9XHJcbi5pbWdfaWNvbnt3aWR0aDogMTAwcHg7aGVpZ2h0OiAxMDBweDttYXJnaW4tdG9wOiAyMHB4O21hcmdpbi1sZWZ0OiA1cHg7fVxyXG5cclxuXHJcbiAgICAucmF0aW5nX2NvbmFpbmVye21hcmdpbi1sZWZ0OiA1cHg7fVxyXG4gICAgLmNhcmRfY2FudGFpbmVyXHJcbntcclxuIFxyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweDtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcblxyXG59XHJcbi5jb250YWluZXIgeyAgICBcclxuICAgIGhlaWdodDogMTI1cHg7XHJcbiAgICB3aWR0aDogMTI1cHg7XHJcbn1cclxuLm92ZXJsYXlcclxue1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzAwMDAwMDUyO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuLmNsYXNzX3NsaWRlcnN7cGFkZGluZy1sZWZ0OiAxNXB4O31cclxuLmNhcmRfbGFibGVcclxue1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG1hcmdpbjogMHB4IGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOiA0NnB4O1xyXG4gICAgd2lkdGg6IDcwcHg7XHJcbiAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5pdGVtX2NvbnRhaW5lclxyXG57XHJcbiAgIFxyXG4gICBiYWNrZ3JvdW5kOiB1cmwoLi4vLi4vLi4vYXNzZXRzL29mZmVyX2JnLnBuZyk7XHJcbiAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlciBjZW50ZXI7XHJcbiAgIGhlaWdodDogMTYwcHg7XHJcbiAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgIGJveC1zaGFkb3c6IDBweCAycHggNHB4ICNhMDlhOWE7XHJcbn1cclxuLnNlY3Rpb25cclxue1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbn1cclxuLmRvdHRlZF9saW5le1xyXG4gICAgYm9yZGVyLXRvcDogMXB4IGRhc2hlZCAjMDAwO1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbn1cclxuXHJcbi5kb3Qge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA3NXB4O1xyXG4gICAgbGVmdDogMnB4O1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbiAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICB3aWR0aDogMjBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1MHB4IDE1MHB4IDAgMDtcclxuXHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xyXG5cclxufVxyXG4uZG90MSB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDc1cHg7XHJcbiAgICByaWdodDogMnB4O1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbiAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICB3aWR0aDogMjBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1MHB4IDE1MHB4IDAgMDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgXHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgtOTBkZWcpO1xyXG4gIFxyXG59XHJcbi5kaXNjb3VudF9wcmljZXsgICAgXHJcbiAgICBmb250LWZhbWlseTogUG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA0NnB4O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgbWFyZ2luLXRvcDogMjVweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO31cclxuICAgIC5vZmZlcl90aXRsZVxyXG4gICAge1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiA0NnB4O1xyXG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgICAgICBjb2xvcjogIzUwNGU0ZTtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiBcclxuXHJcbiAgICB9XHJcbiAgICAub2ZmZXJfdGl0bGVfZGF0ZVxyXG4gICAge1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zLU1lZGl1bSAhaW1wb3J0YW50O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiA0NnB4O1xyXG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgICAgIGNvbG9yOiAjNTA0ZTRlO1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuIFxyXG5cclxuICAgIH1cclxuICAgIC5vZmZlcl90aXRsZSBzcGFue2NvbG9yOiAjMDAwO31cclxuXHJcbiAgICAucHJvbW90aW9ueyAgLS1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyO2JhY2tncm91bmQtc2l6ZTogY292ZXI7aGVpZ2h0OiAxMDBweDtwYWRkaW5nOiAwcHg7bWFyZ2luOiAwcHg7fVxyXG4gICAgLmJsYWNrX2xheWVye2hlaWdodDogMTAwcHg7ICAgIHBhZGRpbmc6IDEwcHg7fVxyXG4gICAgLmNhcmRfbGFibGVfMnsgICAgY29sb3I6ICNmZmY7Zm9udC1mYW1pbHk6IFBvcHBpbnMtTWVkaWFtIWltcG9ydGFudDtmb250LXNpemU6IDE4cHg7cG9zaXRpb246IHJlbGF0aXZlO2ZvbnQtd2VpZ2h0OiBib2xkZXI7dG9wOiAyMHB4O3dpZHRoOiAxMDBweDt9XHJcbiAgICAudm91Y2hlcl9sYWJsZXsgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIGxlZnQ6IDIycHg7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBQb3BwaW5zLU1lZGlhbSFpbXBvcnRhbnQ7XHJcbiAgICAgICAgdG9wOiAyMHB4O30gIl19 */");

/***/ }),

/***/ 9361:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/vouchers/qr/qr.component.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content>\n    <ion-row class=\"img_\">\n        <ion-col >\n        <img class=\"qr_image\" src=\"{{this.qrImage}}\">\n        </ion-col>\n    </ion-row>\n\n    <ion-row class=\"button_container\">\n        <ion-buttons style=\"width: 80%;margin: 0px auto;\">\n          <ion-button class=\"action_button_yes\"(click)=\"cancel()\" >Back</ion-button>\n          <ion-button class=\"action_button_no\" (click)=\"cancel()\" >Cancel</ion-button>\n        </ion-buttons>\n     \n      </ion-row>\n   \n</ion-content>");

/***/ }),

/***/ 220:
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/vouchers/vouchers.component.html ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n  <ion-content [fullscreen]=\"true\">\n\n    <div class=\"header_banner\">\n      <div class=\"header_overlay\">\n         <div class=\"icon_conatiner\">\n\n          <ion-row>\n           <ion-col size=\"2\" ><ion-back-button defaultHref=\"tablinks\"></ion-back-button></ion-col>\n           <ion-col size=\"1\" offset=\"7\"><ion-icon  class=\"_cart_icon\" name=\"bag-handle-outline\"></ion-icon></ion-col>\n           <ion-col size=\"2\" ><ion-menu-button item-right class=\"_menu_icon\"></ion-menu-button></ion-col>\n          \n          </ion-row>\n          <ion-row><ion-label class=\"header_title\">My Vouchers</ion-label></ion-row>\n         </div>\n   \n      </div>\n    </div>\n    \n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"6\" (click)=\"opn_qr(card.qrCodeBase64)\" *ngFor=\"let card of vouchersList\">\n            <ion-card class=\"promotion\" >\n              <ion-card-content class=\"black_layer\"> \n                <img src=\"../../../assets/bgvouchers.png\">\n              <ion-label class=\"voucher_lable\">{{card.branchName}}</ion-label>\n              </ion-card-content></ion-card>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    \n     \n  \n\n      \n     \n  \n  \n  </ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_vouchers_vouchers_module_ts.js.map