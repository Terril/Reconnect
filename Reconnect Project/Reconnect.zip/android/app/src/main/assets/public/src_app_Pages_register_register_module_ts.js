(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_register_register_module_ts"],{

/***/ 4392:
/*!***********************************************************!*\
  !*** ./src/app/Pages/register/register-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterRoutingModule": () => (/* binding */ RegisterRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _register_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.component */ 2431);




const routes = [
    {
        path: "",
        component: _register_component__WEBPACK_IMPORTED_MODULE_0__.RegisterComponent
    }
];
let RegisterRoutingModule = class RegisterRoutingModule {
};
RegisterRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], RegisterRoutingModule);



/***/ }),

/***/ 2431:
/*!******************************************************!*\
  !*** ./src/app/Pages/register/register.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterComponent": () => (/* binding */ RegisterComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_register_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./register.component.html */ 2771);
/* harmony import */ var _register_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.component.css */ 4978);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage-angular */ 1628);
/* harmony import */ var _register_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./register.service */ 3970);









let RegisterComponent = class RegisterComponent {
    constructor(router, alertController, storage, loadingController, api) {
        this.router = router;
        this.alertController = alertController;
        this.storage = storage;
        this.loadingController = loadingController;
        this.api = api;
        this.password_type = 'password';
        this.email_type = 'text';
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.storage.create();
            this.loading = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: 'Please wait...',
                duration: 2000
            });
        });
    }
    togglePasswordMode() {
        this.password_type = this.password_type === 'text' ? 'password' : 'text';
    }
    register() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            if (this.user_email == null) {
                let alert = yield this.alertController.create({
                    cssClass: 'my-custom-class',
                    message: 'Please enter email / mobile number',
                    buttons: ['OK']
                });
                yield alert.present();
            }
            else if (this.user_name == null) {
                let alert = yield this.alertController.create({
                    cssClass: 'my-custom-class',
                    message: 'Please Enter Name',
                    buttons: ['OK']
                });
                yield alert.present();
            }
            else if (this.mailValidation(this.user_email)) {
                let alert = yield this.alertController.create({
                    cssClass: 'my-custom-class',
                    message: 'Please Valid Email',
                    buttons: ['OK']
                });
                yield alert.present();
            }
            else if (this.user_password == null) {
                let alert = yield this.alertController.create({
                    cssClass: 'my-custom-class',
                    message: 'Please enter password',
                    buttons: ['OK']
                });
                yield alert.present();
            }
            else {
                let param = { "name": this.user_name, "email": this.user_email, "password": this.user_password };
                this.api._register(param).subscribe((data) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
                    if (data == "Invalid") {
                        this.loading.dismiss();
                        let alert = yield this.alertController.create({
                            cssClass: 'my-custom-class',
                            message: 'Invalid Credentials',
                            buttons: ['OK']
                        });
                        yield alert.present();
                    }
                    else {
                        this.loading.dismiss();
                        this.storage.set("userdata", data);
                        this.router.navigate(['/tablinks']);
                    }
                }));
            }
        });
    }
    mailValidation(val) {
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (!expr.test(val)) {
            return true;
        }
    }
};
RegisterComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_6__.Storage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _register_service__WEBPACK_IMPORTED_MODULE_2__.RegisterService }
];
RegisterComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-register',
        template: _raw_loader_register_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_register_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], RegisterComponent);



/***/ }),

/***/ 5010:
/*!***************************************************!*\
  !*** ./src/app/Pages/register/register.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterModule": () => (/* binding */ RegisterModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 4392);
/* harmony import */ var _register_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.component */ 2431);







let RegisterModule = class RegisterModule {
};
RegisterModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        declarations: [_register_component__WEBPACK_IMPORTED_MODULE_1__.RegisterComponent],
        imports: [
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterRoutingModule
        ]
    })
], RegisterModule);



/***/ }),

/***/ 3970:
/*!****************************************************!*\
  !*** ./src/app/Pages/register/register.service.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterService": () => (/* binding */ RegisterService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 1841);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 205);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 5304);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);






let RegisterService = class RegisterService {
    constructor(httpClient) {
        this.httpClient = httpClient;
        this.REG_URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.url + "GuestRegistrationApi/userRegister";
        this.httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({ 'Content-Type': 'application/json' })
        };
    }
    _register(param) {
        return this.httpClient.post(`${this.REG_URL}`, param).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.catchError)(this.handleError));
        ;
    }
    handleError(error) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Error: ${error.error.message}`;
        }
        else {
            // server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }
        console.log(errorMessage);
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)(errorMessage);
    }
};
RegisterService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
RegisterService = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], RegisterService);



/***/ }),

/***/ 4978:
/*!*******************************************************!*\
  !*** ./src/app/Pages/register/register.component.css ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (".body_container{width: 100%; background:url('login-bg.png');height:  100%;--background-repeat: no-repeat ;--background-size: cover; }\r\n.logo{margin-top: 50px;}\r\n.logo_container{width: auto;margin: 0px auto;display: table;margin-top: 50px;}\r\n.body_overlay{background:#4c919c73;height: 100%;}\r\n.login_container{margin:40px 20px 10px 20px;;}\r\n.input_box{color: #20978F; background-color: white; margin-top: 5px; margin-bottom: 15px;box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);border-radius: 5px;}\r\n.input_lable{margin-top: 10px; color: #fff;font-family:Poppins-Light !important;}\r\n.input_icon{color: #20978F;font-size: 20px;padding: 8px 0px 5px 5px ;}\r\n.input_text{text-indent: 5px;}\r\n._button{ --background-activated:#20978F; width: 100%;margin: 0px auto;  --border-radius: 5px!important; box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);font-family:Poppins-Medium !important; margin-top: 29px; color: #fff; --background: #20978F;font-size: 18px;--border-radius: 6px;display: block;height: 50px;}\r\n._button:hover{--background-hover: #20978F;--background: #20978F;outline: none;}\r\n.forget_lable{font-family:Poppins-Light !important;color: #fff;margin-top: 15px;float: right;text-decoration: none;text-align: center;}\r\n.lower_content {font-family:Poppins-Light !important; padding-bottom: 0 !important;bottom:0px; padding: 5px;margin-top: 30px;  color: #fff;font-size: 14px;float: right;text-decoration: none;text-align: center;}\r\n.footer_pre{font-family:Poppins-Light !important;}\r\n.footer_text{ width: 100%;padding-bottom: 0 !important;position: fixed;bottom:0px; padding: 5px;margin-bottom: 30px; margin-top: 20px; font-family:Poppins-Light !important;color: #fff;font-weight: 500;font-size: 10px;text-align: center;float: right;}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCLFdBQVcsRUFBRSw4QkFBNEMsQ0FBQyxhQUFhLENBQUMsK0JBQStCLENBQUMsd0JBQXdCLEVBQUU7QUFDbEosTUFBTSxnQkFBZ0IsQ0FBQztBQUN2QixnQkFBZ0IsV0FBVyxDQUFDLGdCQUFnQixDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUM3RSxjQUFjLG9CQUFvQixDQUFDLFlBQVksQ0FBQztBQUNoRCxpQkFBaUIsMEJBQTBCLEVBQUU7QUFDN0MsV0FBVyxjQUFjLEVBQUUsdUJBQXVCLEVBQUUsZUFBZSxFQUFFLG1CQUFtQixDQUFDLHVDQUF1QyxDQUFDLGtCQUFrQixDQUFDO0FBQ3BKLGFBQWEsZ0JBQWdCLEVBQUUsV0FBVyxDQUFDLG9DQUFvQyxDQUFDO0FBQ2hGLFlBQVksY0FBYyxDQUFDLGVBQWUsQ0FBQyx5QkFBeUIsQ0FBQztBQUNyRSxZQUFZLGdCQUFnQixDQUFDO0FBQzdCLFVBQVUsOEJBQThCLEVBQUUsV0FBVyxDQUFDLGdCQUFnQixHQUFHLDhCQUE4QixFQUFFLHVDQUF1QyxDQUFDLHFDQUFxQyxFQUFFLGdCQUFnQixFQUFFLFdBQVcsRUFBRSxxQkFBcUIsQ0FBQyxlQUFlLENBQUMsb0JBQW9CLENBQUMsY0FBYyxDQUFDLFlBQVksQ0FBQztBQUM5UyxlQUFlLDJCQUEyQixDQUFDLHFCQUFxQixDQUFDLGFBQWEsQ0FBQztBQUMvRSxjQUFjLG9DQUFvQyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLENBQUM7QUFDdEksZ0JBQWdCLG9DQUFvQyxFQUFFLDRCQUE0QixDQUFDLFVBQVUsRUFBRSxZQUFZLENBQUMsZ0JBQWdCLEdBQUcsV0FBVyxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLENBQUM7QUFDak4sWUFBWSxvQ0FBb0MsQ0FBQztBQUNqRCxjQUFjLFdBQVcsQ0FBQyw0QkFBNEIsQ0FBQyxlQUFlLENBQUMsVUFBVSxFQUFFLFlBQVksQ0FBQyxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxvQ0FBb0MsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLGtCQUFrQixDQUFDLFlBQVksQ0FBQyIsImZpbGUiOiJyZWdpc3Rlci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJvZHlfY29udGFpbmVye3dpZHRoOiAxMDAlOyBiYWNrZ3JvdW5kOnVybCguLi8uLi8uLi9hc3NldHMvbG9naW4tYmcucG5nKTtoZWlnaHQ6ICAxMDAlOy0tYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdCA7LS1iYWNrZ3JvdW5kLXNpemU6IGNvdmVyOyB9XHJcbi5sb2dve21hcmdpbi10b3A6IDUwcHg7fVxyXG4ubG9nb19jb250YWluZXJ7d2lkdGg6IGF1dG87bWFyZ2luOiAwcHggYXV0bztkaXNwbGF5OiB0YWJsZTttYXJnaW4tdG9wOiA1MHB4O31cclxuLmJvZHlfb3ZlcmxheXtiYWNrZ3JvdW5kOiM0YzkxOWM3MztoZWlnaHQ6IDEwMCU7fVxyXG4ubG9naW5fY29udGFpbmVye21hcmdpbjo0MHB4IDIwcHggMTBweCAyMHB4Ozt9XHJcbi5pbnB1dF9ib3h7Y29sb3I6ICMyMDk3OEY7IGJhY2tncm91bmQtY29sb3I6IHdoaXRlOyBtYXJnaW4tdG9wOiA1cHg7IG1hcmdpbi1ib3R0b206IDE1cHg7Ym94LXNoYWRvdzogMCA0cHggOHB4IDAgcmdiYSgwLDAsMCwwLjIpO2JvcmRlci1yYWRpdXM6IDVweDt9XHJcbi5pbnB1dF9sYWJsZXttYXJnaW4tdG9wOiAxMHB4OyBjb2xvcjogI2ZmZjtmb250LWZhbWlseTpQb3BwaW5zLUxpZ2h0ICFpbXBvcnRhbnQ7fVxyXG4uaW5wdXRfaWNvbntjb2xvcjogIzIwOTc4Rjtmb250LXNpemU6IDIwcHg7cGFkZGluZzogOHB4IDBweCA1cHggNXB4IDt9XHJcbi5pbnB1dF90ZXh0e3RleHQtaW5kZW50OiA1cHg7fVxyXG4uX2J1dHRvbnsgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDojMjA5NzhGOyB3aWR0aDogMTAwJTttYXJnaW46IDBweCBhdXRvOyAgLS1ib3JkZXItcmFkaXVzOiA1cHghaW1wb3J0YW50OyBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDAsMCwwLDAuMik7Zm9udC1mYW1pbHk6UG9wcGlucy1NZWRpdW0gIWltcG9ydGFudDsgbWFyZ2luLXRvcDogMjlweDsgY29sb3I6ICNmZmY7IC0tYmFja2dyb3VuZDogIzIwOTc4Rjtmb250LXNpemU6IDE4cHg7LS1ib3JkZXItcmFkaXVzOiA2cHg7ZGlzcGxheTogYmxvY2s7aGVpZ2h0OiA1MHB4O31cclxuLl9idXR0b246aG92ZXJ7LS1iYWNrZ3JvdW5kLWhvdmVyOiAjMjA5NzhGOy0tYmFja2dyb3VuZDogIzIwOTc4RjtvdXRsaW5lOiBub25lO31cclxuLmZvcmdldF9sYWJsZXtmb250LWZhbWlseTpQb3BwaW5zLUxpZ2h0ICFpbXBvcnRhbnQ7Y29sb3I6ICNmZmY7bWFyZ2luLXRvcDogMTVweDtmbG9hdDogcmlnaHQ7dGV4dC1kZWNvcmF0aW9uOiBub25lO3RleHQtYWxpZ246IGNlbnRlcjt9XHJcbi5sb3dlcl9jb250ZW50IHtmb250LWZhbWlseTpQb3BwaW5zLUxpZ2h0ICFpbXBvcnRhbnQ7IHBhZGRpbmctYm90dG9tOiAwICFpbXBvcnRhbnQ7Ym90dG9tOjBweDsgcGFkZGluZzogNXB4O21hcmdpbi10b3A6IDMwcHg7ICBjb2xvcjogI2ZmZjtmb250LXNpemU6IDE0cHg7ZmxvYXQ6IHJpZ2h0O3RleHQtZGVjb3JhdGlvbjogbm9uZTt0ZXh0LWFsaWduOiBjZW50ZXI7fVxyXG4uZm9vdGVyX3ByZXtmb250LWZhbWlseTpQb3BwaW5zLUxpZ2h0ICFpbXBvcnRhbnQ7fVxyXG4uZm9vdGVyX3RleHR7IHdpZHRoOiAxMDAlO3BhZGRpbmctYm90dG9tOiAwICFpbXBvcnRhbnQ7cG9zaXRpb246IGZpeGVkO2JvdHRvbTowcHg7IHBhZGRpbmc6IDVweDttYXJnaW4tYm90dG9tOiAzMHB4OyBtYXJnaW4tdG9wOiAyMHB4OyBmb250LWZhbWlseTpQb3BwaW5zLUxpZ2h0ICFpbXBvcnRhbnQ7Y29sb3I6ICNmZmY7Zm9udC13ZWlnaHQ6IDUwMDtmb250LXNpemU6IDEwcHg7dGV4dC1hbGlnbjogY2VudGVyO2Zsb2F0OiByaWdodDt9XHJcbiJdfQ== */");

/***/ }),

/***/ 2771:
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/register/register.component.html ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<ion-content [fullscreen]=\"true\" >\n    <div class=\"body_container\">\n     <div class=\"body_overlay\">\n         <ion-row>\n             <ion-col size=\"4\" offset=\"4\">\n               <img class=\"logo_container\" src=\"../../../assets/second_logo.png\" alt=\"logo-image\"/>\n             </ion-col>\n        </ion-row>\n        <ion-grid class=\"login_container\">\n        <label class=\"input_lable\">Email</label>\n        <ion-row class=\"input_box\">\n         <ion-col  size=\"1\">\n             <ion-icon class=\"input_icon\" name=\"mail-outline\"></ion-icon>\n         </ion-col>\n         <ion-col size=\"9\">\n            <ion-input class=\"input_text\" [(ngModel)]=\"user_email\"  value=\"johndoe@gmail.com\" ></ion-input>\n           </ion-col>\n    </ion-row>\n \n    <label class=\"input_lable\">Name</label>\n    <ion-row class=\"input_box\">\n     <ion-col  size=\"1\">\n         <ion-icon  class=\"input_icon\" name=\"person\"></ion-icon>\n     </ion-col>\n     <ion-col size=\"8.9\">\n        <ion-input class=\"input_text\"  [(ngModel)]=\"user_name\"  ></ion-input>\n       </ion-col>\n       <ion-col  size=\"1\">\n        \n     </ion-col>\n      \n</ion-row>\n  \n<label class=\"input_lable\">Password</label>\n<ion-row class=\"input_box\">\n <ion-col  size=\"1\">\n     <ion-icon  class=\"input_icon\" name=\"lock-closed-outline\"></ion-icon>\n </ion-col>\n <ion-col size=\"8.9\">\n    <ion-input class=\"input_text\" [(ngModel)]=\"user_password\"  [type]=\"password_type\"></ion-input>\n   </ion-col>\n   <ion-col  size=\"1\">\n     <ion-icon name=\"eye\" class=\"input_icon\" item-right (click)=\"togglePasswordMode()\"></ion-icon>\n </ion-col>\n  \n</ion-row>\n\n \n   \n<ion-button class=\"_button\" (click)=\"register()\" >REGISTER</ion-button>\n    \n     \n     </ion-grid>\n   </div>\n \n </div>\n \n <div class=\"footer_text\"><span class=\"footer_pre\">ReConnect</span>@ is part of IFA Group.All Rights Reserved.</div>\n </ion-content>\n \n  ");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_register_register_module_ts.js.map