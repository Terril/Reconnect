(self["webpackChunkReconnect"] = self["webpackChunkReconnect"] || []).push([["src_app_Pages_tablinks_tablinks_module_ts"],{

/***/ 342:
/*!***********************************************************!*\
  !*** ./src/app/Pages/tablinks/tablinks-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TablinksPageRoutingModule": () => (/* binding */ TablinksPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _tablinks_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tablinks.component */ 2068);




const routes = [
    {
        path: 'tablinks',
        component: _tablinks_component__WEBPACK_IMPORTED_MODULE_0__.TablinksComponent,
        children: [
            {
                path: 'profile',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_Pages_profile_profile_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../profile/profile.module */ 824)).then(m => m.ProfilePageModule)
            },
            {
                path: 'dashboard',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_Pages_dashboard_dashboard_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../dashboard/dashboard.module */ 9702)).then(m => m.DashboardPageModule)
            },
            {
                path: 'search',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_Pages_search_search_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../search/search.module */ 4322)).then(m => m.SearchPageModule)
            },
            {
                path: 'wishlist',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_Pages_wishlist_wishlist_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../wishlist/wishlist.module */ 295)).then(m => m.WishlistPageModule)
            },
            {
                path: '',
                redirectTo: '/tablinks/dashboard',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: 'tablinks/dashboard',
        pathMatch: 'full'
    },
    {
        path: 'profile',
        redirectTo: 'tablinks/profile',
        pathMatch: 'full'
    },
    {
        path: 'search',
        redirectTo: 'tablinks/search',
        pathMatch: 'full'
    },
    {
        path: 'wishlist',
        redirectTo: 'tablinks/wishlist',
        pathMatch: 'full'
    }
];
let TablinksPageRoutingModule = class TablinksPageRoutingModule {
};
TablinksPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], TablinksPageRoutingModule);



/***/ }),

/***/ 2068:
/*!******************************************************!*\
  !*** ./src/app/Pages/tablinks/tablinks.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TablinksComponent": () => (/* binding */ TablinksComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_tablinks_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./tablinks.component.html */ 4585);
/* harmony import */ var _tablinks_component_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tablinks.component.css */ 8784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 476);






let TablinksComponent = class TablinksComponent {
    constructor(router, route, nav, menu) {
        this.router = router;
        this.route = route;
        this.nav = nav;
        this.menu = menu;
        this.tab_registry = {};
        this.tabs = [];
        this.navigate = (where) => {
            this.router.navigate([`/tablinks/${where}`]);
        };
    }
    ngOnInit() {
        this.menu.enable(false);
    }
};
TablinksComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.MenuController }
];
TablinksComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-tablinks',
        template: _raw_loader_tablinks_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_tablinks_component_css__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TablinksComponent);



/***/ }),

/***/ 1256:
/*!***************************************************!*\
  !*** ./src/app/Pages/tablinks/tablinks.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TablinksPageModule": () => (/* binding */ TablinksPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 6461);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _tablinks_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tablinks.component */ 2068);
/* harmony import */ var _tablinks_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tablinks-routing.module */ 342);







let TablinksPageModule = class TablinksPageModule {
};
TablinksPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule.forRoot({ navAnimation: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.iosTransitionAnimation }),
            _tablinks_routing_module__WEBPACK_IMPORTED_MODULE_1__.TablinksPageRoutingModule
        ],
        declarations: [_tablinks_component__WEBPACK_IMPORTED_MODULE_0__.TablinksComponent]
    })
], TablinksPageModule);



/***/ }),

/***/ 8784:
/*!*******************************************************!*\
  !*** ./src/app/Pages/tablinks/tablinks.component.css ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-tab-bar {\r\n    bottom: 20px;\r\n    position: fixed;\r\n    left: 10px;\r\n    right: 10px;\r\n    border-radius: 5px;\r\n    width:92%;\r\n    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);\r\n    transition: 0.3s;\r\n    margin: 0 auto;\r\n  }\r\n  \r\n  ion-tabs{\r\n    background: #20988f;\r\n    color: #fff;\r\n}\r\n  \r\n  ion-tab-bar  {\r\n    background: #20988f;\r\n    width: 90% !important;\r\n    max-width: 400px !important;\r\n    border-radius: 30px;\r\n    max-height: 56px;\r\n    height: 56px;\r\n}\r\n  \r\n  .tab-selected ion-icon{\r\n    color: rgb(70, 69, 69);\r\n    background: #fff;\r\n    border-radius: 30px;\r\n\r\n    padding: 8px;\r\n    display: block;\r\n    z-index: 9999;\r\n    transition: 0.255s;\r\n\r\n}\r\n  \r\n  .tab-selected ion-label{\r\n    width: 20px;\r\n    height: 6px;\r\n    border-radius: 4px;\r\n    background: #0000;\r\n    \r\n}\r\n  \r\n  .tab-selected, ion-tab-button{\r\n    background: #20988f;\r\n    color: white;\r\n    \r\n}\r\n  \r\n  ion-tab-button {\r\n    --color: var(--ion-color-medium);\r\n    --color-selected: var(--ion-color-primary);  }\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYmxpbmtzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxZQUFZO0lBQ1osZUFBZTtJQUNmLFVBQVU7SUFDVixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCLFNBQVM7SUFDVCx1Q0FBdUM7SUFDdkMsZ0JBQWdCO0lBQ2hCLGNBQWM7RUFDaEI7O0VBRUE7SUFDRSxtQkFBbUI7SUFDbkIsV0FBVztBQUNmOztFQUNBO0lBQ0ksbUJBQW1CO0lBQ25CLHFCQUFxQjtJQUNyQiwyQkFBMkI7SUFDM0IsbUJBQW1CO0lBQ25CLGdCQUFnQjtJQUNoQixZQUFZO0FBQ2hCOztFQUNBO0lBQ0ksc0JBQXNCO0lBQ3RCLGdCQUFnQjtJQUNoQixtQkFBbUI7O0lBRW5CLFlBQVk7SUFDWixjQUFjO0lBQ2QsYUFBYTtJQUNiLGtCQUFrQjs7QUFFdEI7O0VBQ0E7SUFDSSxXQUFXO0lBQ1gsV0FBVztJQUNYLGtCQUFrQjtJQUNsQixpQkFBaUI7O0FBRXJCOztFQUdBO0lBQ0ksbUJBQW1CO0lBQ25CLFlBQVk7O0FBRWhCOztFQUNFO0lBQ0UsZ0NBQWdDO0lBQ2hDLDBDQUEwQyxHQUFHIiwiZmlsZSI6InRhYmxpbmtzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdGFiLWJhciB7XHJcbiAgICBib3R0b206IDIwcHg7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBsZWZ0OiAxMHB4O1xyXG4gICAgcmlnaHQ6IDEwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICB3aWR0aDo5MiU7XHJcbiAgICBib3gtc2hhZG93OiAwIDRweCA4cHggMCByZ2JhKDAsMCwwLDAuMik7XHJcbiAgICB0cmFuc2l0aW9uOiAwLjNzO1xyXG4gICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi10YWJze1xyXG4gICAgYmFja2dyb3VuZDogIzIwOTg4ZjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcbmlvbi10YWItYmFyICB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMjA5ODhmO1xyXG4gICAgd2lkdGg6IDkwJSAhaW1wb3J0YW50O1xyXG4gICAgbWF4LXdpZHRoOiA0MDBweCAhaW1wb3J0YW50O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIG1heC1oZWlnaHQ6IDU2cHg7XHJcbiAgICBoZWlnaHQ6IDU2cHg7XHJcbn1cclxuLnRhYi1zZWxlY3RlZCBpb24taWNvbntcclxuICAgIGNvbG9yOiByZ2IoNzAsIDY5LCA2OSk7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuXHJcbiAgICBwYWRkaW5nOiA4cHg7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHotaW5kZXg6IDk5OTk7XHJcbiAgICB0cmFuc2l0aW9uOiAwLjI1NXM7XHJcblxyXG59XHJcbi50YWItc2VsZWN0ZWQgaW9uLWxhYmVse1xyXG4gICAgd2lkdGg6IDIwcHg7XHJcbiAgICBoZWlnaHQ6IDZweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICAgIGJhY2tncm91bmQ6ICMwMDAwO1xyXG4gICAgXHJcbn1cclxuXHJcblxyXG4udGFiLXNlbGVjdGVkLCBpb24tdGFiLWJ1dHRvbntcclxuICAgIGJhY2tncm91bmQ6ICMyMDk4OGY7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBcclxufVxyXG4gIGlvbi10YWItYnV0dG9uIHtcclxuICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgLS1jb2xvci1zZWxlY3RlZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpOyAgfSJdfQ== */");

/***/ }),

/***/ 4585:
/*!**********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/Pages/tablinks/tablinks.component.html ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n\n    <ion-tabs>\n      <ion-tab-bar slot=\"bottom\">\n        <ion-tab-button tab=\"dashboard\">\n            <ion-icon name=\"home-outline\"></ion-icon>\n         \n        </ion-tab-button>\n  \n        <ion-tab-button tab=\"search\">\n            <ion-icon name=\"search-outline\"></ion-icon>\n         \n        </ion-tab-button>\n\n        <ion-tab-button tab=\"wishlist\">\n            <ion-icon name=\"heart-outline\"></ion-icon>\n        \n          </ion-tab-button>\n\n          <ion-tab-button tab=\"profile\">\n            <ion-icon name=\"person-outline\"></ion-icon>\n          \n          </ion-tab-button>\n      </ion-tab-bar>\n    </ion-tabs>\n  \n ");

/***/ })

}]);
//# sourceMappingURL=src_app_Pages_tablinks_tablinks_module_ts.js.map